﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Xml.Linq;

namespace FormUI
{
    // ========== ボタンの単独パブリック用 ==========
    public interface IExButtonPublic
    {
        // コントロールの紐づけ
        ExButtonElement Element { get; set; }

        int X { get; }
        int Y { get; }

        // 名前
        string Name { get; set; }

        // テキスト
        string Text { get; set; }

        // フォント
        Font Font { get; set; }

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }


        // ========== ボタン固有処理 ==========

        // テキストの位置
        ContentAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();

        // クリックイベント
        EventHandler ClickEvent { get; set; }
        void RemoveClickEvent();
    }

    // ========== ボタンのの単独インターナル用 ==========
    internal interface IExButtonInternal : IExButtonPublic
    {
        // 有効・無効
        bool Enabled { get; set; }
        bool EnabledCell { get; set; }

        // 表示・非表示
        bool Visible { get; set; }
        bool VisibleCell { get; set; }
    }
}