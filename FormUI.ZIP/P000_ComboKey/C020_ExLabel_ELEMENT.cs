﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FormUI
{
    public class ExLabelElement : Label
    {
        // ========== コンストラクタ ==========
        internal ExLabelElement(Form parent) => Initialize(parent);

        private void Initialize(Form parent)
        {
            Parent = parent;
 
            BorderStyle = BorderStyle.FixedSingle;
            TextAlign = ContentAlignment.MiddleCenter;

            ChangeEnabled();
            ChangeVisible();
        }

        // 位置
        public int X
        {
            get => Location.X;
            set => Location = new Point(value, Location.Y);
        }
        public int Y
        {
            get => Location.Y;
            set => Location = new Point(Location.X, value);
        }

        // 有効・無効
        private bool _enabledElement = true;
        private bool _enabledCell = true;
        internal bool EnabledElement
        {
            get => _enabledElement;
            set
            {
                _enabledElement = value;
                ChangeEnabled();
            }
        }
        internal bool EnabledCell
        {
            get => _enabledCell;
            set
            {
                _enabledCell = value;
                ChangeEnabled();
            }
        }
        private void ChangeEnabled() => Enabled = _enabledElement && _enabledCell;

        // 表示・非表示
        private bool _visibleElement = true;
        private bool _visibleCell = true;
        internal bool VisibleElement
        {
            get => _visibleElement;
            set
            {
                _visibleElement = value;
                ChangeVisible();
            }
        }
        internal bool VisibleCell
        {
            get => _visibleCell;
            set
            {
                _visibleCell = value;
                ChangeVisible();
            }
        }
        private void ChangeVisible() => Visible = _visibleElement && _visibleCell;



        // ========== ラベル固有処理 ==========


        // クリックイベント
        private EventHandler _eh = null;
        public EventHandler ClickEvent
        {
            get => _eh;
            set
            {
                Click -= _eh;
                _eh = value;
                Click += _eh;
                ChangeEnabled();
            }
        }
    }
}
