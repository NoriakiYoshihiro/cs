﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FormUI
{
    // ========== ラベルの単独パブリック用 ==========
    public interface IExLabelPublic
    {
        // コントロールの紐づけ
        ExLabelElement Element { get; set; }

        // 名前
        string Name { get; set; }

        // テキスト
        string Text { get; set; }

        // フォント
        Font Font { get; set; }

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }

        // ========== ラベル固有処理 ==========

        // 境界線
        BorderStyle BorderStyle { get; set; }

        // テキストの位置
        ContentAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();

        // クリックイベント
        EventHandler ClickEvent { get; set; }
        void RemoveClickEvent();
    }



    // ========== ラベルの単独インターナル用 ==========
    internal interface IExLabelInternal : IExLabelPublic
    {
        // 有効・無効
        bool Enabled { get; set; }
        bool EnabledCell { get; set; }

        // 表示・非表示
        bool Visible { get; set; }
        bool VisibleCell { get; set; }
    }
}