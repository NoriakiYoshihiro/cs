﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.Remoting.Messaging;

namespace FormUI
{
    internal class ExTextBoxFull : IExTextBoxPublic, IExTextBoxInternal
    {
        // ========== コンストラクタ ==========
        public ExTextBoxFull(ExTextBoxElement element) => Initialize(element);


        private void Initialize(ExTextBoxElement element)
        {
            Element = element;
        }

        // コントロールの紐づけ
        public ExTextBoxElement Element { get; set; }

        // 位置
        public int X
        {
            get => Element.X;
            set => Element.X = value;
        }
        public int Y
        {
            get => Element.Y;
            set => Element.Y = value;
        }
        public Point Location
        {
            get => Element.Location;
            set => Element.Location = value;
        }

        // サイズ
        public int Width
        {
            get => Element.Width;
            set => Element.Width = value;
        }
        public int Height
        {
            get => Element.Height;
            set => Element.Height = value;
        }
        public Size Size
        {
            get => Element.Size;
            set => Element.Size = value;
        }

        // 名前
        public string Name
        {
            get => Element.Name;
            set => Element.Name = value;
        }

        // テキスト
        public string Text
        {
            get => Element.Text;
            set => Element.Text = value;
        }

        // フォント
        public Font Font
        {
            get => Element.Font;
            set => Element.Font = value;
        }

        // カラー
        public Color ForeColor
        {
            get => Element.ForeColor;
            set => Element.ForeColor = value;
        }
        public Color BackColor
        {
            get => Element.BackColor;
            set => Element.BackColor = value;
        }

        // タブインデックス
        public int TabIndex
        {
            get => Element.TabIndex;
            set => Element.TabIndex = value;
        }

        // 有効・無効
        public bool Enabled
        {
            get => Element.EnabledElement;
            set => Element.EnabledElement = value;
        }
        public bool EnabledCell
        {
            get => Element.EnabledCell;
            set => Element.EnabledCell = value;
        }

        // 表示・非表示
        public bool Visible
        {
            get => Element.VisibleElement;
            set => Element.VisibleElement = value;
        }
        public bool VisibleCell
        {
            get => Element.VisibleCell;
            set => Element.VisibleCell = value;
        }


        // ========== テキストボックス固有処理 ==========

        // 境界線
        public BorderStyle BorderStyle
        {
            get => Element.BorderStyle;
            set => Element.BorderStyle = value;
        }

        // マルチライン
        public bool Multiline
        {
            get => Element.Multiline;
            set => Element.Multiline = value;
        }

        // テキストの位置
        public HorizontalAlignment TextAlign
        {
            get => Element.TextAlign;
            set => Element.TextAlign = value;
        }
        public void SetTextAlignMiddleCenter() => TextAlign = HorizontalAlignment.Center;
        public void SetTextAlignTopLeft() => TextAlign = HorizontalAlignment.Left;
    }
}
