﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FormUI
{
    // ========== テキストボックスの単独パブリック用 ==========
    public interface IExTextBoxPublic
    {
        // コントロールの紐づけ
        ExTextBoxElement Element { get; set; }

        // 名前
        string Name { get; set; }

        // テキスト
        string Text { get; set; }

        // フォント
        Font Font { get; set; }

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }


        // ========== ボタン固有処理 ==========

        // 境界線
        BorderStyle BorderStyle { get; set; }

        // テキストの位置
        HorizontalAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();
    }



    // ========== テキストボックスの単独インターナル用 ==========
    internal interface IExTextBoxInternal : IExTextBoxPublic
    {
        // 有効・無効
        bool Enabled { get; set; }
        bool EnabledCell { get; set; }

        // 表示・非表示
        bool Visible { get; set; }
        bool VisibleCell { get; set; }
    }
}
