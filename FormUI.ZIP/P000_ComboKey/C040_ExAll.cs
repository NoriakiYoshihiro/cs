﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class ExAll
    {
        // ======== コンストラクタ ========
        internal ExAll(ExButtonElement exButton, ExLabelElement exLabel, ExTextBoxElement exTextBox) => Initialize(exButton, exLabel, exTextBox);

        private void Initialize(ExButtonElement exButton, ExLabelElement exLabel, ExTextBoxElement exTextBox)
        {
            _exButton = exButton;
            _exLabel = exLabel;
            _exTextBox = exTextBox;
        }

        private ExButtonElement _exButton;
        private ExLabelElement _exLabel;
        private ExTextBoxElement _exTextBox;


        // ======== コンボキーの3つの要素に対し全て同じ処理を行う ========

        // 位置
        internal int X
        {
            set
            {
                _exButton.X = value;
                _exLabel.X = value;
                _exTextBox.X = value;
            }
        }
        internal int Y
        {
            set
            {
                _exButton.Y = value;
                _exLabel.Y = value;
                _exTextBox.Y = value;
            }
        }
        internal Point Location
        {
            set
            {
                _exButton.Location = value;
                _exLabel.Location = value;
                _exTextBox.Location = value;
            }
        }

        // サイズ
        internal int Width
        {
            set
            {
                _exButton.Width = value;
                _exLabel.Width = value;
                _exTextBox.Width = value;

            }
        }
        internal int Height
        {
            set
            {
                _exButton.Height = value;
                _exLabel.Height = value;
                _exTextBox.Height = value;
            }
        }
        internal Size Size
        {
            set
            {
                _exButton.Size = value;
                _exLabel.Size = value;
                _exTextBox.Size = value;
            }
        }

        // タブインデックス
        private int tabIndex = 0;
        internal int TabIndex
        {
            get => tabIndex;
            set
            {
                tabIndex = value;
                _exButton.TabIndex = value;
                _exLabel.TabIndex = value;
                _exTextBox.TabIndex = value;
            }
        }

        // 有効・無効
        public bool EnabledElement
        {
            set
            {
                _exButton.EnabledElement = value;
                _exLabel.EnabledElement = value;
                _exTextBox.EnabledElement = value;
            }
        }

        // 表示・非表示
        public bool VisibleElement
        {
            set
            {
                _exButton.VisibleElement = value;
                _exLabel.VisibleElement = value;
                _exTextBox.VisibleElement = value;
            }
        }
    }
}
