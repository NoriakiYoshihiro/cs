﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.Remoting.Messaging;

namespace FormUI
{
    // この静的関数はボタン、ラベル、テキストボックスで共有
    public enum ComboType { None = 0, Button = 1, Label = 2, TextBox = 3 }

    public class ComboKeyCell
    {
        // ========== コンストラクタ ==========
        public ComboKeyCell(Form parent) => Initialize(parent);

        // 生成時のみ
        private void Initialize(Form parent)
        {
            // 共有エレメント
            ExButtonElement = new ExButtonElement(parent);
            ExLabelElement = new ExLabelElement(parent);
            ExTextBoxElement = new ExTextBoxElement(parent);

            // 内部単独制御用
            ExButtonInternal = new ExButtonFull(ExButtonElement);
            ExLabelInternal = new ExLabelFull(ExLabelElement);
            ExTextBoxInternal = new ExTextBoxFull(ExTextBoxElement);

            // 外部単独制御用(パブリック)
            ExButton = new ExButtonFull(ExButtonElement);
            ExLabel = new ExLabelFull(ExLabelElement);
            ExTextBox = new ExTextBoxFull(ExTextBoxElement);
            ExAll = new ExAll(ExButtonElement, ExLabelElement, ExTextBoxElement);

            Type = ComboType.Button;
            Location = new Point (0, 0);
            Size = new Size(120, 80);
            TabIndex = 0;

            PageIndex = 0;
        }


        // 3つの拡張エレメント (基礎)
        private ExButtonElement ExButtonElement { get; set; }
        private ExLabelElement ExLabelElement { get; set; }
        private ExTextBoxElement ExTextBoxElement { get; set; }

        // インターナル用 (プログラムがクラス内で利用(internalと同じ)、外から利用不可)
        private IExButtonInternal ExButtonInternal { get; set; }
        private IExLabelInternal ExLabelInternal { get; set; }
        private IExTextBoxInternal ExTextBoxInternal { get; set; }

        // パブリック用 (外からエレメント単位で操作可能)
        public IExButtonPublic ExButton { get; private set; }
        public IExLabelPublic ExLabel { get; private set; }
        public IExTextBoxPublic ExTextBox { get; private set; }
        public ExAll ExAll { get; private set; }




        // ======== 選択中の要素で行う ========

        // ページインデックス
        public int PageIndex { get; set; }

        // 選択タイプ
        private ComboType _type;
        public ComboType Type
        {
            get => _type;
            set
            {
                if (value == ComboType.None) return;
                _type = value;
                ChangeEnabled();
                ChangeVisible();
            }
        }

        public string Text
        {
            get
            {
                switch (Type)
                {
                    case ComboType.Button: return ExButton.Text;
                    case ComboType.Label: return ExLabel.Text;
                    case ComboType.TextBox: return ExTextBox.Text;
                }
                return "";
            }
            set
            {
                switch (Type)
                {
                    case ComboType.Button: ExButton.Text = value; break;
                    case ComboType.Label: ExLabel.Text = value; break;
                    case ComboType.TextBox: ExTextBox.Text = value; break;
                }
            }
        }

        public EventHandler ClickEvent
        {
            set
            {
                switch (Type)
                {
                    case ComboType.Button: ExButton.ClickEvent = value; break;
                    case ComboType.Label: ExLabel.ClickEvent = value; break;
                }
            }
        }

        // ======== 3つの要素で同じ処理を行う ========

        // 位置
        public int X
        {
            get => ExButton.X;
            set => ExAll.X = value;
        }
        public int Y
        {
            get => ExButton.Y;
            set => ExAll.Y = value;
        }
        public Point Location
        {
            set => ExAll.Location = value;
        }

        // サイズ
        public int Width
        {
            set => ExAll.Width = value;
        }
        public int Height
        {
            set => ExAll.Height = value;
        }
        public Size Size
        {
            set => ExAll.Size = value;
        }

        // タブインデックス
        public int TabIndex
        {
            get => ExAll.TabIndex;
            set => ExAll.TabIndex = value;
        }

        // コンボキーの有効・無効
        private bool _enabled = true;
        private bool _enabledArray = true;
        public bool Enabled
        {
            get => _enabled;
            set
            {
                _enabled = value;
                ChangeEnabled();
            }
        }
        public bool EnabledArray
        {
            get => _enabledArray;
            set
            {
                _enabledArray = value;
                ChangeEnabled();
            }
        }
        private void ChangeEnabled()
        {
            ExButtonInternal.EnabledCell = Enabled && EnabledArray && _type == ComboType.Button;
            ExLabelInternal.EnabledCell = Enabled && EnabledArray && _type == ComboType.Label;
            ExTextBoxInternal.EnabledCell = Enabled && EnabledArray && _type == ComboType.TextBox;
        }

        // コンボキーの表示・非表示
        private bool visible = true;
        private bool visibleArray = true;
        public bool Visible
        {
            get => visible;
            set
            {
                visible = value;
                ChangeVisible();
            }
        }
        public bool VisibleArray
        {
            get => visibleArray;
            set
            {
                visibleArray = value;
                ChangeVisible();
            }
        }
        private void ChangeVisible()
        {
            ExButtonInternal.VisibleCell = Visible && VisibleArray && _type == ComboType.Button;
            ExLabelInternal.VisibleCell = Visible && VisibleArray && _type == ComboType.Label;
            ExTextBoxInternal.VisibleCell =Visible && VisibleArray && _type == ComboType.TextBox;
        }
    }
}