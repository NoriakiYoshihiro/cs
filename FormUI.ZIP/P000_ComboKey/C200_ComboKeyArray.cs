﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FormUI.AreaEvenDivider;
using System.Security.Cryptography.X509Certificates;

namespace FormUI
{
    public class ComboKeyArray
    {

        // ======== コンストラクタ ========
        // 親コンテナーの設定はコンストラクタでのみ可能
        public ComboKeyArray(Form parent) => Initialize(parent);
        public ComboKeyArray(Form parent, int arraySize)
        {
            Initialize(parent);
            ArraySize = arraySize;
        }

        // ======== コンボキー配列 ========
        public ComboKeyCell[] Cell { get; private set; }


        // 初期化
        // 親コンテナー設定、AreaEvenDividerのインスタンス生成
        public void Initialize(Form parent)
        {
            Parent = parent;
            AreaEvenDivider = new AreaEvenDivider(this);
        }

        // 親コンテナー
        public Form Parent { get; private set; }

        // Cell配列サイズ、setではインスタンス生成も実行
        public int ArraySize
        {
            get => Cell.Length;
            set => CreateArray(value);
        }

        // ここでCellをインスタンス生成し初期設定する
        protected void CreateArray(int arraySize)
        {
            Cell = new ComboKeyCell[arraySize];
            OperateOnArray(x => Cell[x] = new ComboKeyCell(Parent));
            OperateOnArray(x => Cell[x].PageIndex = 0);
            OperateOnArray(x => Cell[x].TabIndex = x);
        }


        // エリア均等分割クラス
        public AreaEvenDivider AreaEvenDivider { get; set; }



        // ======== ページ番号 ========
        protected int page;
        // ページは何ページに変更でも受け付ける
        // Cell[].PageIndexと一致するページだけ表示する
        public int Page
        {
            get => page;
            set
            {
                this.page = value;
                ShowPage();
            }
        }


        // Cell[].PageIndexと一致するページだけ表示する→private検討
        public void ShowPage() => ChangeVisible();




        // ======== プロパティ・メソッド ========
        private bool _enabled = true;
        private void ChangeEnabled()
        {
            OperateOnArray(x => Cell[x].EnabledArray = Enabled);
        }
        public bool Enabled
        {
            get => _enabled;
            set
            {
                _enabled = value;
                ChangeEnabled();
            }
        }

        private bool _visible = true;
        private void ChangeVisible() // ページの影響を受ける
        {
            OperateOnArray(x => Cell[x].VisibleArray = Visible && Cell[x].PageIndex == Page);
        }
        public bool Visible
        {
            get => _visible;
            set
            {
                _visible = value;
                ChangeVisible();
            }
        }


        // Cell全要素に作用させるメソッド
        protected void OperateOnArray(Action<int> action)
        {
            for (var i = 0; i < Cell.Length; i++) action(i);
        }
    }
}
