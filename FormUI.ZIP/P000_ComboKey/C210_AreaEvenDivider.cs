﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace FormUI
{
    public class AreaEvenDivider
    {
        // ======== コントラクタ ========
        internal AreaEvenDivider(ComboKeyArray comboKeyArray)
        {
            ComboKeyArray = comboKeyArray;
        }

        private ComboKeyArray ComboKeyArray { get; set; }

        // エリアロケーション
        public Area Area = new Area();

        // 1ページのキーの数
        public NumOfKey NumOfKey = new NumOfKey();

        // 縦横のスペース
        public Space Space = new Space();

        public void DivideArea()
        {
            var WidthOfKey = (Area.Width - (NumOfKey.X - 1) * Space.H) / NumOfKey.X;
            var HeightOfKey = (Area.Height - (NumOfKey.Y - 1) * Space.H) / NumOfKey.Y;
            var PitchX = WidthOfKey + Space.H;
            var PitchY = HeightOfKey + Space.V;

            for (var i = 0; i < ComboKeyArray.ArraySize; i++)
            {
                var x = Area.X0 + PitchX * (i % NumOfKey.X);
                var y = Area.Y0 + PitchY * (i % NumOfKey.Page / NumOfKey.X);
                var p = i / NumOfKey.Page;
                ComboKeyArray.Cell[i].Location = new Point(x, y);
                ComboKeyArray.Cell[i].Size = new Size(WidthOfKey, HeightOfKey);
                ComboKeyArray.Cell[i].PageIndex = p;
            }
        }
    }

    public class Area
    {
        public int X0 { get; set; }
        public int Y0 { get; set; }
        public int X1 { get; set; }
        public int Y1 { get; set; }

        public int Width => X1 - X0;
        public int Height => Y1 - Y0;

        public void Set(int x0, int y0, int x1, int y1)
        {
            X0 = x0;
            Y0 = y0;
            X1 = x1;
            Y1 = y1;
        }
    }

    public class NumOfKey
    {
        public int X { get; set; } = 5;
        public int Y { get; set; } = 1;
        public int Page => X * Y;
        public void Set(int x, int y)
        {
            X = x;
            Y = y;
        }
    }

    public class Space
    {
        public int H { get; set; } = 5;
        public int V { get; set; } = 5;
        public void Set (int h, int v)
        {
            H = h;
            V = v;
        }
    }
}
