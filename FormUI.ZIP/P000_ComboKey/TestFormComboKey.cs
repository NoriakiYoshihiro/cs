﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Windows.Forms;


namespace FormUI
{
    internal partial class TestFormComboKey : Form
    {
        public TestFormComboKey()
        {
            InitializeComponent();
        }

        public ComboKeyArray ComboKeyArray { get; set; }

        public void DoTest(Form formCommon)
        {
            ComboKeyArray = new ComboKeyArray(formCommon);

            {
                var ck = ComboKeyArray;

                ck.ArraySize=24;
                ck.AreaEvenDivider.NumOfKey.Set(6, 2);
                ck.AreaEvenDivider.Area.Set(20, 480, 800, 660);
                ck.AreaEvenDivider.DivideArea();


                ck.Cell[0].Text = "Button 01の\r\nテキスト→OK";
                ck.Cell[0].ClickEvent = (sender, e) =>
                {
                    ck.Cell[1].Text = "OK";
                    ck.Cell[1].Enabled = true;
                };
                ck.Cell[1].Text = "ファイル\n読み込み";
                ck.Cell[1].ClickEvent = (sender, e) =>
                {
                    var fileName = "";
                    using (var sr = new OpenFileDialog())
                    {
                        sr.ShowDialog();
                        fileName = sr.FileName;
                    }
                    using (var sr = new StreamReader(fileName)) textBoxFileContents.Text = sr.ReadToEnd();
                };

                ck.Cell[2].Text = "Page 1";
                ck.Cell[2].ClickEvent = (sender, e) => ck.Page = 1;


                Action act1 = () => { ck.Cell[3].Text = "Hide Button 1"; ck.Cell[1].VisibleArray = true; };
                Action act2 = () => { ck.Cell[3].Text = "Show Button 1"; ck.Cell[1].VisibleArray = false; };
                EventHandler eh = (sender, e) => (ck.Cell[1].VisibleArray ? act2 : act1)();

                act1();
                ck.Cell[3].ClickEvent = eh;

                ck.Cell[4].Type = ComboType.Label;
                ck.Cell[4].Text = "Greeting\n\"Hello!\"";
                ck.Cell[4].ClickEvent = (sender, e) => MessageBox.Show("Hello!");

                ck.Cell[5].Type = ComboType.TextBox;
                ck.Cell[5].Text = "テキストボックス";

                ck.Cell[7].Text = "終了";
                ck.Cell[7].ClickEvent = (sender, e) => this.Dispose();

                ck.Cell[10].Text = "テキストクリア";
                ck.Cell[10].ClickEvent = (sender, e) => textBoxFileContents.Text = "";

                ck.Cell[15].Text = "Page 3";
                ck.Cell[15].ClickEvent = (sender, e) => ck.Page = 4;

                ck.Cell[18].Type = ComboType.Label;
                ck.Cell[18].Text = "Label";

                ck.Cell[21].Type = ComboType.TextBox;
                ck.Cell[21].Text = "TextBox";

                ck.Cell[23].Text = "Page 0";
                ck.Cell[23].ClickEvent = (sender, e) => ck.Page = 0;
            }
        }
    }
}
