﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FormUI
{
    public class ExButtonCommon : IExButtonForPublic, IExButtonForSolo, IExButtonForAll, IExButtonFull
    {
        // ========== コンストラクタ ==========
        public ExButtonCommon() { }
        public ExButtonCommon(Button obj)
        {
            Initialize(obj);
        }

        private void Initialize(Button obj)
        {
            Object=obj;
            EnabledSelf = true;
            EnabledSuper= true;
            VisibleSelf = true;
            ClickEvent = null;

            TextAlign = ContentAlignment.MiddleCenter;
        }

        // コントロールの紐づけ
        private Button obj;
        public Button Object
        {
            get => obj;
            set => obj = value;
        }

        // 親コンテナー
        public Form Parent
        {
            get => (Form)obj.Parent;
            set => obj.Parent = value;
        }

        // 位置
        public int X
        {
            get => obj.Location.X;
            set => obj.Location = new Point(value, obj.Location.Y);
        }
        public int Y
        {
            get => obj.Location.Y;
            set => obj.Location = new Point(obj.Location.X, value);
        }
        public Point Location
        {
            get => obj.Location;
            set => obj.Location = value;
        }

        // サイズ
        public int Width
        {
            get => obj.Width;
            set => obj.Width = value;
        }
        public int Height
        {
            get => obj.Height;
            set => obj.Height = value;
        }
        public Size Size
        {
            get => obj.Size;
            set => obj.Size = value;
        }

        // 名前
        public string Name
        {
            get => obj.Name;
            set => obj.Name = value;
        }
        public void SetNameSuffix(int fig, int num, string suffix)
        {
            obj.Name = MakeName.Button(fig, num, suffix);
        }

        // テキスト
        public string Text
        {
            get => obj.Text;
            set => obj.Text = value;
        }
        public void SetTextSuffix(int fig, int num, string suffix)
        {
            obj.Text = MakeName.Button(fig, num, suffix);
        }
        public void ResetText() => obj.Text = string.Empty;

        // カラー
        public Color ForeColor
        {
            get => obj.ForeColor;
            set => obj.ForeColor = value;
        }
        public Color BackColor
        {
            get => obj.BackColor;
            set => obj.BackColor = value;
        }

        // タブインデックス
        public int TabIndex
        {
            get => obj.TabIndex;
            set => obj.TabIndex = value;
        }

        // 有効・無効
        private bool enabledSelf;
        private bool enabledSuper;
        public bool EnabledSelf
        {
            get => enabledSelf;
            set
            {
                enabledSelf = value;
                ChangeEnabled();
            }
        }
        public bool EnabledSuper
        {
            get => enabledSuper;
            set
            {
                enabledSuper = value;
                ChangeEnabled();
            }
        }
        private void ChangeEnabled() => obj.Enabled = enabledSelf && enabledSuper && (eh != null); // 最後の(eh!=null)はボタン固有
        public void Activate() => EnabledSelf = true;
        public void Deactivate() => EnabledSelf = false;

        // 表示・非表示
        private bool visibleSelf;
        private bool visibleSuper;
        public bool VisibleSelf
        {
            get => visibleSelf;
            set
            {
                visibleSelf = value;
                ChangeVisible();
            }
        }
        public bool VisibleSuper
        {
            get => visibleSuper;
            set
            {
                visibleSuper = value;
                ChangeVisible();
            }
        }
        private void ChangeVisible() => obj.Visible = visibleSelf && visibleSuper;
        public void Show() => VisibleSelf = true;
        public void Hide() => VisibleSelf = false;


        // ========== ボタン固有処理 ==========

        // テキストの位置
        public ContentAlignment TextAlign
        {
            get => obj.TextAlign;
            set => obj.TextAlign = value;
        }
        public void SetTextAlignMiddleCenter() => TextAlign = ContentAlignment.MiddleCenter;
        public void SetTextAlignTopLeft() => TextAlign = ContentAlignment.TopLeft;

        // クリックイベント
        private EventHandler eh;
        public EventHandler ClickEvent
        {
            get => eh;
            set
            {
                obj.Click -= eh;
                eh = value;
                obj.Click += eh;
                ChangeEnabled();
            }
        }
        public Action ClickEventNoArg
        {
            set => ClickEvent = (sender, e) => value();
        }
        public void ResetClickEvent() => ClickEvent = null;

        // テキストとクリックエベントの複合処理
        public void SetTextClickEvent(string text, EventHandler clickEvent)
        {
            Text = text;
            ClickEvent = clickEvent;
        }
        public void ResetTextClickEvent()
        {
            ResetText();
            ResetClickEvent();
        }
    }
}
