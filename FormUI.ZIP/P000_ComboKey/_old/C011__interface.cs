﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FormUI
{

    // ========== コンボキーのパブリック用 ==========
    public interface IExButtonForPublic
    {
        // コントロールの紐づけ
        Button Object { get; set; }

        // 名前
        string Name { get; set; }
        void SetNameSuffix(int fig, int num, string suffix);

        // テキスト
        string Text { get; set; }
        void SetTextSuffix(int fig, int num, string suffix);


        // ========== ボタン固有処理 ==========

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }

        // テキストの位置
        ContentAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();

        // クリックイベント
        EventHandler ClickEvent { get; set; }
        Action ClickEventNoArg { set; }
        void ResetClickEvent();

        // テキストとクリックエベントの複合処理
        void SetTextClickEvent(string text, EventHandler clickEvent);
        void ResetTextClickEvent();
    }


    // ========== コンボキーの内部単独用 ==========
    public interface IExButtonForSolo : IExButtonForPublic
    {
        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();
    }


    // ========== コンボキーの内部連動用 ==========
    public interface IExButtonForAll
    {
        // コントロールの紐づけ
        Button Object { get; set; }

        // 親コンテナー
        Form Parent { get; set; }

        // 位置
        int X { get; set; }
        int Y { get; set; }
        Point Location { get; set; }

        // サイズ
        int Width { get; set; }
        int Height { get; set; }
        Size Size { get; set; }

        // 名前
        void SetNameSuffix(int fig, int num, string suffix);

        // タブインデックス
        int TabIndex { get; set; }

        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();
    }


    // ========== 完全型インターフェース ==========
    public interface IExButtonFull
    {
        // コントロールの紐づけ
        Button Object { get; set; }

        // 親コンテナー
        Form Parent { get; set; }

        // 位置
        int X { get; set; }
        int Y { get; set; }
        Point Location { get; set; }

        // サイズ
        int Width { get; set; }
        int Height { get; set; }
        Size Size { get; set; }

        // 名前
        string Name { get; set; }
        void SetNameSuffix(int fig, int num, string suffix);

        // テキスト
        string Text { get; set; }
        void SetTextSuffix(int fig, int num, string suffix);

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }

        // テキストの位置
        ContentAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();

        // タブインデックス
        int TabIndex { get; set; }

        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate(); 
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();

        // クリックイベント
        EventHandler ClickEvent { get; set; }
        Action ClickEventNoArg { set; }
        void ResetClickEvent();

        // テキストとクリックエベントの複合処理
        void SetTextClickEvent(string text, EventHandler clickEvent);
        void ResetTextClickEvent();
    }
}
