﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FormUI
{
    // ========== コンボキーのパブリック用 ==========
    public interface IExLabelForPublic
    {

        // コントロールの紐づけ
        Label Object { get; set; }

        // 名前
        string Name { get; set; }
        void SetNameSuffix(int fig, int num, string suffix);

        // テキスト
        string Text { get; set; }
        void SetTextSuffix(int fig, int num, string suffix);

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }

        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();


        // ========== ボタン固有処理 ==========
        
        // 境界線
        BorderStyle BorderStyle { get; set; }

        // テキストの位置
        ContentAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();
    }

    // ========== コンボキーの内部単独用 ==========
    public interface IExLabelForSolo : IExLabelForPublic
    {
        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();
    }

    // ========== コンボキーの内部連動用 ==========
    public interface IExLabelForAll
    {
        // コントロールの紐づけ
        Label Object { get; set; }

        // 親コンテナー
        Form Parent { get; set; }

        // 位置
        int X { get; set; }
        int Y { get; set; }
        Point Location { get; set; }

        // サイズ
        int Width { get; set; }
        int Height { get; set; }
        Size Size { get; set; }

        // 名前
        void SetNameSuffix(int fig, int num, string suffix);

        // タブインデックス
        int TabIndex { get; set; }

        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();
    }


    // ========== 完全型インターフェース ==========
    public interface IExLabelFull
    {

        // コントロールの紐づけ
        Label Object { get; set; }

        // 親コンテナー
        Form Parent { get; set; }

        // 位置
        int X { get; set; }
        int Y { get; set; }
        Point Location { get; set; }

        // サイズ
        int Width { get; set; }
        int Height { get; set; }
        Size Size { get; set; }

        // 名前
        string Name { get; set; }
        void SetNameSuffix(int fig, int num, string suffix);

        // テキスト
        string Text { get; set; }
        void SetTextSuffix(int fig, int num, string suffix);

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }

        // 境界線
        BorderStyle BorderStyle { get; set; }

        // テキストの位置
        ContentAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();

        // タブインデックス
        int TabIndex { get; set; }

        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();

        // クリックイベント
        EventHandler ClickEvent { get; set; }
        Action ClickEventNoArg { set; }
        void ResetClickEvent();

        // テキストとクリックエベントの複合処理
        void SetTextClickEvent(string text, EventHandler clickEvent);
        void ResetTextClickEvent();
    }
}
