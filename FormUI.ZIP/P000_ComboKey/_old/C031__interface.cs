﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FormUI
{
    // ========== コンボキーのパブリック用 ==========
    public interface IExTextBoxForPublic
    {

        // コントロールの紐づけ
        TextBox Object { get; set; }

        // 名前
        string Name { get; set; }
        void SetNameSuffix(int fig, int num, string suffix);

        // テキスト
        string Text { get; set; }
        void SetTextSuffix(int fig, int num, string suffix);

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }


        // ========== ボタン固有処理 ==========

        // 境界線
        BorderStyle BorderStyle { get; set; }

        // テキストの位置
        HorizontalAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();
    }

    // ========== コンボキーの内部単独用 ==========
    public interface IExTextBoxForSolo : IExTextBoxForPublic
    {
        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();
    }


    // ========== コンボキーの内部連動用 ==========
    public interface IExTextBoxForAll
    {
        // コントロールの紐づけ
        TextBox Object { get; set; }

        // 親コンテナー
        Form Parent { get; set; }

        // 位置
        int X { get; set; }
        int Y { get; set; }
        Point Location { get; set; }

        // サイズ
        int Width { get; set; }
        int Height { get; set; }
        Size Size { get; set; }

        // 名前
        void SetNameSuffix(int fig, int num, string suffix);

        // タブインデックス
        int TabIndex { get; set; }

        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();
    }


    // ========== 完全型インターフェース ==========
    public interface IExTextBoxFull
    {
        // コントロールの紐づけ
        TextBox Object { get; set; }

        // 親コンテナー
        Form Parent { get; set; }

        // 位置
        int X { get; set; }
        int Y { get; set;  }
        Point Location { get; set; }

        // サイズ
        int Width { get; set; }
        int Height { get; set; }
        Size Size { get; set; }

        // 名前
        string Name { get; set; }
        void SetNameSuffix(int fig, int num, string suffix);

        // テキスト
        string Text { get; set; }
        void SetTextSuffix(int fig, int num, string suffix);

        // カラー
        Color ForeColor { get; set; }
        Color BackColor { get; set; }

        // 境界線
        BorderStyle BorderStyle { get; set; }

        // マルチライン
        bool Multiline { get; set; }

        // テキストの位置
        HorizontalAlignment TextAlign { get; set; }
        void SetTextAlignMiddleCenter();
        void SetTextAlignTopLeft();

        // タブインデックス
        int TabIndex { get; set; }

        // 有効・無効
        bool EnabledSelf { get; set; }
        bool EnabledSuper { get; set; }
        void Activate();
        void Deactivate();

        // 表示・非表示
        bool VisibleSelf { get; set; }
        bool VisibleSuper { get; set; }
        void Show();
        void Hide();
    }
}
