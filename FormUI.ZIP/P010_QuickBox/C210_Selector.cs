﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public class Selector : ComboKeyArray
    {
        // Step 0. Parent = 親コンテナーはコンストラクタでのみ決定可能
        // Step 1. ArraySize = ComboKey配列生成 + 配列要素のComboKeyインスタンス生成

        public Selector(Form parent) : base(parent) { }
        public Selector(Form parent, int arraySize) : base(parent, arraySize) { }
    }
}