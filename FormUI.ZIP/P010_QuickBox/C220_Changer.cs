﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public enum ChangerLayout { None = -1, Horizontal2 = 0, Horizontal4 = 1, Square4 = 2 }

    public class Changer : ComboKeyArray
    {
        // ======== コンストラクタ ========
        public Changer(Form parent) : base(parent) { }

        // ==== PageManagerインスタンスを必ず受け取ること ====
        private PageManager PageManager { get; set; }
        public void SetPageManager(PageManager pageManager) => PageManager = pageManager;

        // レイアウト
        private ChangerLayout _layout = ChangerLayout.Horizontal4;
        public ChangerLayout Layout
        {
            get => _layout;
            set
            {
                _layout = value;
                SetLayoutNumbers();
            }
        }

        private void SetLayoutNumbers()
        {
            if (Layout == ChangerLayout.None)
            {
                CreateArray(0);
                return;
            }
            // レイアウト別　表示できる数
            NumOfKeyOnX = new int[] { 2, 4, 2 }[(int)Layout];
            NumOfKeyOnY = new int[] { 1, 1, 2 }[(int)Layout];
            NumOfKey = NumOfKeyOnX * NumOfKeyOnY;

            // 各配列の役割
            IndexOfTop = new int[] { -1, 0, 2 }[(int)Layout];
            IndexOfBack = new int[] { 0, 1, 0 }[(int)Layout];
            IndexOfNext = new int[] { 1, 2, 1 }[(int)Layout];
            IndexOfLast = new int[] { -1, 3, 3 }[(int)Layout];

            // Length(配列サイズ)の決定とインスタンス生成
            ArraySize = NumOfKey;
            //OperateOnArray(x => { Cell[x] = new ComboKeyCell(Parent); });


            AreaEvenDivider.NumOfKey.Set(NumOfKeyOnX, NumOfKeyOnY);
            AreaEvenDivider.DivideArea();
            SetDefaultText();
        }

        new public int ArraySize
        {
            get => Cell.Length;
            private set => CreateArray(value);
        }


        // レイアウト別　表示できる数
        private int NumOfKeyOnX;
        private int NumOfKeyOnY;
        private int NumOfKey;

        // 各配列の役割
        public int IndexOfTop;
        public int IndexOfBack;
        public int IndexOfNext;
        public int IndexOfLast;


        public void Show() => OperateOnArray(x => Cell[x].Visible = true);
        public void Hide() => OperateOnArray(x => Cell[x].Visible = false);


        // 生成されるときに
        public void SetDefaultText()
        {
            if (Layout == ChangerLayout.None) return;
            if (IndexOfTop > -1) Cell[IndexOfTop].Text = "|＜＜";
            Cell[IndexOfBack].Text = "＜";
            Cell[IndexOfNext].Text = "＞";
            if (IndexOfLast > -1) Cell[IndexOfLast].Text = "＞＞|";
        }

        // チェンジャのクリックイベント
        public void SetClickEvent()
        {
            if (Layout == ChangerLayout.None) return;

            var ce = PageManager.ChangingEvent;
            if (IndexOfTop > -1) Cell[IndexOfTop].ClickEvent = ce.Top;
            Cell[IndexOfBack].ClickEvent = ce.Back;
            Cell[IndexOfNext].ClickEvent = ce.Next;
            if (IndexOfLast > -1) Cell[IndexOfLast].ClickEvent = ce.Last;
        }

        // ページが変わる毎に
        public void ChangeEnabled()
        {
            if (Layout == ChangerLayout.None) return;

            var intp = PageManager.IsNotTopPage;
            var inlp = PageManager.IsNotLastPage;
            if (IndexOfTop > -1) Cell[IndexOfTop].EnabledArray = intp;
            Cell[IndexOfBack].EnabledArray = intp;
            Cell[IndexOfNext].EnabledArray = inlp;
            if (IndexOfLast > -1) Cell[IndexOfLast].EnabledArray = inlp;
        }
    }
}
