﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public class PageManager
    {
        // ======== コンストラクタ ========
        public PageManager(Selector selector, Changer changer)
        {
            Selector = selector;
            Changer = changer;
        }

        // Selectorの紐づけ用
        private Selector Selector { get; set; }
        // Changerの紐づけ用
        private Changer Changer { get; set; }


        public int Page
        {
            get => Selector.Page;
            set
            {
                Selector.Page = value;
                Changer.ChangeEnabled();
            }
        }

        // ユニットの所属するページのトップラスト
        public (int Top, int Last) PageRange
        {
            get
            {
                int top = Selector.Cell[0].PageIndex;
                int last = top;
                foreach (var u in Selector.Cell)
                {
                    var p = u.PageIndex;
                    if (p < top) top = p; else if (p > last) last = p;
                }
                return (top, last);
            }
        }
        public int TopPage => PageRange.Top;
        public int LastPage => PageRange.Last;
        // 今がページのトップラストか
        public (bool Top, bool last) IsNotTopLastPage => (IsNotTopPage, IsNotLastPage);
        public bool IsNotTopPage => Page > PageRange.Top;
        public bool IsNotLastPage => Page < PageRange.Last;

        public (EventHandler Top, EventHandler Back, EventHandler Next, EventHandler Last) ChangingEvent
        => ((sender, e) => Page = TopPage,
            (sender, e) => Page--,
            (sender, e) => Page++,
            (sender, e) => Page = LastPage);
    }
}
