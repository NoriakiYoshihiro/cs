﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Channels;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing;

namespace FormUI
{
    public class QuickBox
    {
        public Selector Selector { get; set; }
        public Changer Changer { get; set; }
        public PageManager PageManager { get; set; }

        // ======== コンストラクタ ========
        private Form Parent { get; set; }
        public QuickBox(Form parent)
        {
            Parent = parent;
            Selector = new Selector(parent);
            Changer = new Changer(parent);
            PageManager = new PageManager(Selector, Changer);
            Changer.SetPageManager(PageManager);
        }


        // 配置のデフォルト
        public void SetAreaDefault1(int arraySize, int numOfKeyOnX, int numOfKeyOnY, ChangerLayout layout)
        {
            var widthParent = Parent.Width;
            var heightParent = Parent.Height;
            var widthChanger = layout == ChangerLayout.Horizontal4 ? 340 : 160;

            Selector.ArraySize = arraySize;
            Selector.AreaEvenDivider.NumOfKey.Set(numOfKeyOnX, numOfKeyOnY);
            {
                var left = 20;
                var top = heightParent - 100 * numOfKeyOnY - 25;
                var right = widthParent - widthChanger - 60;
                var bottom = heightParent - 50;
                Selector.AreaEvenDivider.Area.Set(left, top, right, bottom);
                //Selector.AreaEvenDivider.Area.Set(20, heightParent - 125, widthParent - 440, heightParent - 50);
            }
            Selector.AreaEvenDivider.DivideArea();

            Changer.Layout = layout;
            {
                var left = widthParent - widthChanger - 40;
                var top = heightParent - 125;
                var right = widthParent - 20;
                var bottom = heightParent - 50;
                Changer.AreaEvenDivider.Area.Set(left, top, right, bottom);
                //Changer.AreaEvenDivider.Area.Set(widthParent - 400, heightParent - 125, widthParent - 20, heightParent - 50);
            }
            Changer.AreaEvenDivider.DivideArea();

            Selector.ShowPage();
            Changer.SetClickEvent();
            Changer.ChangeEnabled();
        }

        public void SetAreaDefault2(int arraySize, int numOfKeyOnX, int numOfKeyOnY)
        {
            var widthParent = Parent.Width;
            var heightParent = Parent.Height;

            Selector.ArraySize = arraySize;
            Selector.AreaEvenDivider.NumOfKey.Set(numOfKeyOnX, numOfKeyOnY);
            {
                var left = 20;
                var top = heightParent - 100 * numOfKeyOnY - 25;
                var right = widthParent - 20;
                var bottom = heightParent - 50;
                Selector.AreaEvenDivider.Area.Set(left, top, right, bottom);
            }
            Selector.AreaEvenDivider.DivideArea();

            Changer.Layout = ChangerLayout.None;

            Selector.ShowPage();
            Changer.Enabled = false;
            Changer.Visible = false;
        }
    }
}
