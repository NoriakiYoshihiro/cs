﻿namespace FormUI
{
    partial class TestFormQuickBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxFileContents = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBoxFileContents
            // 
            this.textBoxFileContents.Location = new System.Drawing.Point(40, 32);
            this.textBoxFileContents.Multiline = true;
            this.textBoxFileContents.Name = "textBoxFileContents";
            this.textBoxFileContents.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxFileContents.Size = new System.Drawing.Size(625, 416);
            this.textBoxFileContents.TabIndex = 0;
            // 
            // FormComboKey
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1265, 682);
            this.Controls.Add(this.textBoxFileContents);
            this.Font = new System.Drawing.Font("Meiryo UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormComboKey";
            this.Text = "FormUI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxFileContents;
    }
}