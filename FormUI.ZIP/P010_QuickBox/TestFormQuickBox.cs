﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Windows.Forms;


namespace FormUI
{
    internal partial class TestFormQuickBox : Form
    {
        public TestFormQuickBox()
        {
            InitializeComponent();
        }

        public QuickBox Q { get; set; }

        public void DoTest(Form formCommon)
        {
            Q = new QuickBox(formCommon);

            {
                var qs = Q.Selector;
                var qc = Q.Changer;
                var qp = Q.PageManager;


                Q.SetAreaDefault1(24, 6, 1, ChangerLayout.Horizontal2);
                //Q.SetAreaDefault2(24, 6, 1);
                /*
                qs.ArraySize = 24;
                qs.AreaEvenDivider.SetNumOfKey(6, 2);
                qs.AreaEvenDivider.SetArea(20,480,800,660);
                qs.AreaEvenDivider.SetEven();

                qc.Layout=ChangerLayout.Horizontal4;
                qc.AreaEvenDivider.SetArea(820, 600, 1240, 660);
                qc.AreaEvenDivider.SetEven();

                qc.SetClickEvent();
                qc.ChangeEnabled();
                */


                qs.Cell[0].Text = "Button 01の\r\nテキスト→OK";
                qs.Cell[0].ClickEvent = (sender, e) =>
                {
                    qs.Cell[1].Text = "OK";
                    qs.Cell[1].Enabled = true;
                };

                qs.Cell[1].Text = "ファイル\n読み込み";
                qs.Cell[1].ClickEvent = (sender, e) =>
                {
                    var fileName = "";
                    using (var sr = new OpenFileDialog())
                    {
                        sr.ShowDialog();
                        fileName = sr.FileName;
                    }
                    using (var sr = new StreamReader(fileName)) textBoxFileContents.Text = sr.ReadToEnd();
                };

                qs.Cell[2].Text = "Page 1";
                qs.Cell[2].ClickEvent = (sender, e) => qp.Page = 1;


                Action act1 = () => { qs.Cell[3].Text = "Hide Button 1"; qs.Cell[1].Visible = true; };
                Action act2 = () => { qs.Cell[3].Text = "Show Button 1"; qs.Cell[1].Visible = false; };
                EventHandler eh = (sender, e) => (qs.Cell[1].Visible ? act2 : act1)();

                act1();
                qs.Cell[3].ClickEvent = eh;

                qs.Cell[4].Type = ComboType.Label;
                qs.Cell[4].Text = "Greeting\n\"Hello!\"";
                qs.Cell[4].ClickEvent = (sender, e) => MessageBox.Show("Hello!");

                qs.Cell[5].Type = ComboType.TextBox;
                qs.Cell[5].Text = "テキストボックス";

                qs.Cell[7].Text = "終了";
                qs.Cell[7].ClickEvent = (sender, e) => this.Dispose();

                qs.Cell[10].Text = "テキストクリア";
                qs.Cell[10].ClickEvent = (sender, e) => textBoxFileContents.Text = "";

                qs.Cell[15].Text = "Page 3";
                qs.Cell[15].ClickEvent = (sender, e) => qp.Page = 4;

                qs.Cell[18].Type = ComboType.Label;
                qs.Cell[18].Text = "Label";

                qs.Cell[21].Type = ComboType.TextBox;
                qs.Cell[21].Text = "TextBox";

                qs.Cell[23].Text = "Page 0";
                qs.Cell[23].ClickEvent = (sender, e) => qp.Page = 0;
            }
        }
    }
}
