﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class FormQuickBox : Form
    {
        // ======== コンストラクタ ========
        public FormQuickBox()
        {
            InitializeComponent();
            Size = new Size(1280, 720);
            QuickBox = new QuickBox(this);
        }

        public QuickBox QuickBox { get; set; }
    }
}
