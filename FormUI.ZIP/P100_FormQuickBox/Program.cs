﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    internal static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var formQB = new FormQuickBox();

            var fq = formQB.QuickBox;
            var fs = formQB.QuickBox.Selector;
            var fcell = formQB.QuickBox.Selector.Cell;

            var mode = 0;

            if (mode == 0)
            {
                fq.SetAreaDefault2(24, 8, 1);
                //fq.SetAreaDefault1(24, 6, 1,ChangerLayout.Horizontal4);
            } else if (mode == 1)
            {
                fs.ArraySize = 8;
                fs.AreaEvenDivider.Area.Set(formQB.Width - 200, 40, formQB.Width - 40, formQB.Height - 50);
                fs.AreaEvenDivider.NumOfKey.Set(1, 8);
                fs.AreaEvenDivider.DivideArea();
                fq.Changer.Layout = ChangerLayout.None;
            }



            for (var i = 0; i < fq.Selector.ArraySize; i++)
            {
                fs.Cell[i].Text = "Button" + i.ToString();
                fs.Cell[i].Enabled = true;
            }

            fs.Cell[0].Text = "生データ\nファイル読み込み";
            fs.Cell[0].ClickEvent = (sender, e) => fs.Page++;

            fs.Cell[1].Text = "生データ\nファイル保存";
            fs.Cell[1].ClickEvent = (sender, e) => fs.Page++;

            fs.Cell[2].Text = "生データ\nデフォルト設定";
            fs.Cell[2].ClickEvent = (sender, e) => fs.Page++;

            fs.Cell[3].Visible = false;

            fs.Cell[4].Text = "解読パターンファイル\n読み込み";
            fs.Cell[4].ClickEvent = (sender, e) => fs.Page++;

            fs.Cell[5].Text = "解読実行";
            fs.Cell[5].ClickEvent = (sender, e) => fs.Cell[7].Enabled = true;

            fs.Cell[6].Text = "ページ";
            fs.Cell[6].ClickEvent = (sender, e) => fs.Page++;

            fs.Cell[7].Text = "解読データ\nファイル保存";
            fs.Cell[7].ExButton.ForeColor = System.Drawing.Color.Red;
            fs.Cell[7].Enabled = false;
            fs.Cell[7].ClickEvent = (sender, e) => fs.Page++;

            formQB.ShowDialog();
        }
    }
}
