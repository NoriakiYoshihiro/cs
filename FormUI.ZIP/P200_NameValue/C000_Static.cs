﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    internal static class Static
    {
        internal static int Larger(int val1, int val2) => val1 >= val2 ? val1 : val2;
        internal static int Smaller(int val1, int val2) => val1 <= val2 ? val1 : val2;
    }
}
