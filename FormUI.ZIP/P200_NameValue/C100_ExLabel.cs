﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FormUI
{
    public class ExLabel
    {
        // ======== コンストラクタ ========
        public ExLabel(Form parent)
        {
            _label = new Label();
            _label.Parent = parent;
            SetAlignMiddleLeft();
        }

        // ======== プライベートメンバー ========
        private Label _label;

        // ======== プロパティ ========

        // テキスト
        public string Text
        {
            get => _label.Text;
            set => _label.Text = value;
        }

        // フォント
        public string FontFamily { set => _label.Font = new Font(value, _label.Font.Size); }

        // フォントサイズ
        public int FontSize { set => _label.Font = new Font(_label.Font.FontFamily, value); }

        // サイズ
        public (int Width, int Height) Size
        {
            get => (_label.Size.Width, _label.Size.Height);
            set => _label.Size = new Size(value.Width, value.Height);
        }

        // 有効・無効
        public bool Enabled { get => _label.Enabled; set => _label.Enabled = value; }

        // 表示・非表示
        public bool Visible { get => _label.Visible; set => _label.Visible = value; }

        // アライメント
        public ContentAlignment TextAlign { get => _label.TextAlign; set => _label.TextAlign = value; }

        // 位置
        private (int X, int Y) _parentLocation;
        internal (int X, int Y) ParentLocation
        {
            get => _parentLocation;
            set
            {
                _parentLocation = value;
                CalculateLocation();
            }
        }

        private (int X, int Y) _localLocation;
        public (int X, int Y) LocalLocation
        {
            get => _localLocation;
            set
            {
                _localLocation = value;
                CalculateLocation();
            }
        }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area
        {
            get
            {
                var top = ParentLocation.Y + LocalLocation.Y;
                var left = ParentLocation.X + LocalLocation.X;
                var bottom = top + Size.Height;
                var right = left + Size.Width;
                return (top, left, bottom, right);
            }
        }


        // ======== メソッド ========
        public void SetAlignTopLeft() => _label.TextAlign = ContentAlignment.TopLeft;
        public void SetAlignMiddleLeft() => _label.TextAlign = ContentAlignment.MiddleLeft;
        public void SetAlignMiddleCenter() => _label.TextAlign = ContentAlignment.MiddleCenter;
        public void SetAlignMiddleRight() => _label.TextAlign = ContentAlignment.MiddleRight;


        // 完全プライベート
        private void CalculateLocation()
        {
            _label.Location = new Point(ParentLocation.X + LocalLocation.X, ParentLocation.Y + LocalLocation.Y);
        }
    }
}
