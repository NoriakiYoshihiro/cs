﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Drawing;
using System.Xml.Linq;
using System.Reflection.Emit;
using System.Windows.Forms.VisualStyles;

namespace FormUI
{
    public partial class ExTextBoxArray
    {
        // ======== ======== エレメント ======== ========
        public class ExTextBoxElement
        {
            // ======== コンストラクタ ========
            internal ExTextBoxElement(Form parent)
            {
                _textBox = new TextBox();
                _textBox.Parent = parent;
                SetAlignRight();
            }

            // ======== プライベートメンバー ========
            private TextBox _textBox;


            // ======== プロパティ ========
            // テキスト
            public string Text { get => _textBox.Text; set => _textBox.Text = value; }

            // フォント
            public string FontFamily { set => _textBox.Font = new Font(value, _textBox.Font.Size); }

            // フォントサイズ
            public int FontSize { set => _textBox.Font = new Font(_textBox.Font.FontFamily, value); }

            // サイズ
            public (int Width, int Height) Size
            {
                get => (_textBox.Size.Width, _textBox.Size.Height);
                set => _textBox.Size = new Size(value.Width, value.Height);
            }

            // 有効・無効
            public bool Enabled { get => _textBox.Enabled; set => _textBox.Enabled = value; }

            // 表示・非表示
            public bool Visible { get => _textBox.Visible; set => _textBox.Visible = value; }

            // リードオンリー
            public bool ReadOnly { get => _textBox.ReadOnly; set => _textBox.ReadOnly = value; }

            // マルチライン
            public bool Multiline { get => _textBox.Multiline; set => _textBox.Multiline = value; }

            // アライメント
            public HorizontalAlignment TextAlign { get => _textBox.TextAlign; set => _textBox.TextAlign = value; }

            // スクロールバー
            public ScrollBars ScrollBars { get => _textBox.ScrollBars; set => _textBox.ScrollBars = value; }

            // 位置
            private (int X, int Y) _parentLocation;
            internal (int X, int Y) ParentLocation
            {
                get => _parentLocation;
                set
                {
                    _parentLocation = value;
                    Relocate();
                }
            }
            private (int X, int Y) _localLocation;
            public (int X, int Y) LocalLocation
            {
                get => _localLocation;
                set
                {
                    _localLocation = value;
                    Relocate();
                }
            }

            // エリア
            public (int Top, int Left, int Bottom, int Right) Area
            {
                get
                {
                    var top = ParentLocation.Y + LocalLocation.Y;
                    var left = ParentLocation.X + LocalLocation.X;
                    var bottom = top + Size.Height;
                    var right = left + Size.Width;
                    return (top, left, bottom, right);
                }
            }


            // ======== メソッド ========
            public void SetAlignLeft() => _textBox.TextAlign = HorizontalAlignment.Left;
            public void SetAlignCenter() => _textBox.TextAlign = HorizontalAlignment.Center;
            public void SetAlignRight() => _textBox.TextAlign = HorizontalAlignment.Right;

            public void SetScrollBarsNone() => _textBox.ScrollBars = ScrollBars.None;
            public void SetScrollBarsHorizontal() => _textBox.ScrollBars = ScrollBars.Horizontal;
            public void SetScrollBarsVertical() => _textBox.ScrollBars = ScrollBars.Vertical;
            public void SetScrollBarsBoth() => _textBox.ScrollBars = ScrollBars.Both;



            // ======== 内部処理用 ========
            private void Relocate()
            {
                _textBox.Location = new Point(ParentLocation.X + LocalLocation.X, ParentLocation.Y + LocalLocation.Y);
            }
        }
    }
}
