﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Drawing;
using System.Xml.Linq;
using System.Reflection.Emit;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FormUI
{
    public partial class ExTextBoxArray
    {
        // ======== ======== 全エレメント ======== ========
        public class ExTextBoxAll
        {
            // ======== コンストラクタ ========
            internal ExTextBoxAll(ExTextBoxElement[] array) => _array = array;


            // ======== プライベートメンバー ========
            private ExTextBoxElement[] _array;


            // ======== プロパティ ========

            // テキスト
            public string Text { set => ExecuteAll(x => _array[x].Text = value); }

            // フォント
            public string FontFamily { set => ExecuteAll(x => _array[x].FontFamily = value); }

            // フォントサイズ
            public int FontSize { set => ExecuteAll(x => _array[x].FontSize = value); }

            // サイズ
            public (int width, int height) Size { set => ExecuteAll(x => _array[x].Size = value); }

            // 有効・無効
            public bool Enabled { set => ExecuteAll(x => _array[x].Enabled = value); }

            // 表示・非表示
            public bool Visible { set => ExecuteAll(x => _array[x].Visible = value); }

            // リードオンリー
            public bool ReadOnly { set => ExecuteAll(x => _array[x].ReadOnly= value); }

            // マルチライン
            public bool Multiline { set => ExecuteAll(x => _array[x].Multiline = value); }

            // アライメント
            public HorizontalAlignment TextAlign { set => ExecuteAll(x => _array[x].TextAlign = value); }

            // スクロールバー
            public ScrollBars ScrollBar { set => ExecuteAll(x => _array[x].ScrollBars = value); }

            // 位置
            internal (int X, int Y) ParentLocation { set => ExecuteAll(x => _array[x].ParentLocation = value); }


            // ======== メソッド ========
            public void SetAlignLeft() => ExecuteAll(x => _array[x].SetAlignLeft());
            public void SetAlignCenter() => ExecuteAll(x => _array[x].SetAlignCenter());
            public void SetAlignRight() => ExecuteAll(x => _array[x].SetAlignRight());

            public void SetScrollBarsNone() => ExecuteAll(x => _array[x].SetScrollBarsNone());
            public void SetScrollBarsHorizontal() => ExecuteAll(x => _array[x].SetScrollBarsHorizontal());
            public void SetScrollBarsVertical() => ExecuteAll(x => _array[x].SetScrollBarsVertical());
            public void SetScrollBarsBoth() => ExecuteAll(x => _array[x].SetScrollBarsBoth());



            // ======== 内部処理用 ========
            private void ExecuteAll(Action<int> action)
            {
                for (int i = 0; i < _array.Length; i++) action(i);
            }
        }
    }
}
