﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Drawing;
using System.Xml.Linq;

using static FormUI.Static;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FormUI
{
    public partial class ExTextBoxArray
    {
        // Step 1. コンストラクタでparentを確定 (ここでしか確定できない)
        // Step 2. Createの引数で配列サイズを指定(省略した場合は1)
        // Indexが配列番号指定を変更・保持
        // 例 Text -> Array[index].Text
        //    All.Text -> 全配列のText


        // ======== コンストラクタ ========
        public ExTextBoxArray(Form parent) => _parent = parent;

        // ======== 初期設定 ========
        public void Create() => Create(1);
        public void Create(int numOfTextBox)
        {
            Array = new ExTextBoxElement[numOfTextBox];
            for (var i = 0; i < Length; i++)
            {
                Array[i] = new ExTextBoxElement(_parent);
            }
            All = new ExTextBoxAll(Array);
            Index = 0;
        }

        // ======== プライベート ========
        private Form _parent;

        // ======== プロパティ ========

        public ExTextBoxElement[] Array { get; set; }
        public ExTextBoxAll All { get; set; }

        public int Length { get => Array.Length; }

        private int _index = 0;
        public int Index
        {
            get => _index;
            set => _index = value < 0 ? 0 : value >= Length ? Length - 1 : value;
        }

        private ExTextBoxElement Target { get => Array[Index]; }

        // テキスト
        public string Text { get => Target.Text; set => Target.Text = value; }

        // フォント
        public string FontFamily { set => Target.FontFamily = value; }

        // フォントサイズ
        public int FontSize { set => Target.FontSize = value; }

        // サイズ
        public (int width, int height) Size
        {
            get => Target.Size;
            set => Target.Size = value;
        }

        // 有効・無効
        public bool Enabled { get => Target.Enabled; set => Target.Enabled = value; }

        // 表示・非表示
        public bool Visible { get => Target.Visible; set => Target.Visible = value; }

        // リードオンリー
        public bool ReadOnly { get => Target.ReadOnly; set => Target.ReadOnly = value; }

        // マルチライン
        public bool Multiline { get => Target.Multiline; set => Target.Multiline = value; }

        // アライメント
        public HorizontalAlignment TextAlign { get => Target.TextAlign; set => Target.TextAlign = value; }

        // スクロールバー
        public ScrollBars ScrollBar { get => Target.ScrollBars; set => Target.ScrollBars = value; }

        // 位置
        public (int X, int Y) ParentLocation
        {
            get => Target.ParentLocation;
            set => Target.ParentLocation = value;

        }
        public (int X, int Y) LocalLocation
        {
            get => Target.LocalLocation;
            set => Target.LocalLocation = value;
        }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area
        {
            get
            {
                var area0 = Array[0].Area;
                var top = area0.Top;
                var left = area0.Left;
                var bottom = area0.Bottom;
                var right = area0.Right;

                for (var i = 1; i < Length; i++)
                {
                    var area = Array[i].Area;
                    top = Smaller(top, area.Top);
                    left = Smaller(left, area.Left);
                    bottom = Larger(bottom, area.Bottom);
                    right = Larger(right, area.Right);
                }
                return (top, left, bottom, right);
            }
        }


        // ======== メソッド ========
        public void SetAlignLeft() => Target.SetAlignLeft();
        public void SetAlignCenter() => Target.SetAlignLeft();
        public void SetAlignRight() => Target.SetAlignLeft();

        public void SetScrollBarsNone() => Target.SetScrollBarsNone();
        public void SetScrollBarsHorizontal() => Target.SetScrollBarsHorizontal();
        public void SetScrollBarsVertical() => Target.SetScrollBarsVertical();
        public void SetScrollBarsBoth() => Target.SetScrollBarsBoth();


        // LocalLocation を (X,Y)から配列番号順に水平方向に並べていく
        public void SetLocalLocationSequent(int X, int Y) => SetLocalLocationSequent(X, Y, 120, 40, 10);
        public void SetLocalLocationSequent(int X, int Y, int width, int height, int spaceWidth)
        {
            for (int i = 0; i < Length; i++)
            {
                var x = X + i * (width + spaceWidth);
                var y = Y;
                Array[i].Size = (width, height);
                Array[i].LocalLocation = (x, y);
            }
        }

    }
}
