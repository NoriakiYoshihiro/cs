﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FormUI.Static;

namespace FormUI
{
    public class NameValue
    {
        // ======== コンストラクタ ========
        public NameValue(Form parent) => _parent = parent;

        // 初期化
        public void Create() => Create(1);
        public void Create(int numOfTextBox)
        {
            ExLabel = new ExLabel(_parent);
            ExTextBox = new ExTextBoxArray(_parent);
            ExTextBox.Create(numOfTextBox);
        }

        // ======== プライベート ========
        private Form _parent;

        public string Key { get; set; } = "";
        public ExLabel ExLabel { get; set; }
        public ExTextBoxArray ExTextBox;

        public (int X, int Y) ParentLocation
        {
            set
            {
                ExLabel.ParentLocation = value;
                ExTextBox.All.ParentLocation = value;
            }
        }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area
        {
            get
            {
                var labelArea = ExLabel.Area;
                var textBoxArea = ExTextBox.Area;
                var top = Smaller(labelArea.Top,textBoxArea.Top);
                var left = Smaller(labelArea.Left, textBoxArea.Left);
                var bottom = Larger(labelArea.Bottom, textBoxArea.Bottom);
                var right = Larger(labelArea.Right, textBoxArea.Right);
                return (top, left, bottom, right);
            }
        }
    }
}
