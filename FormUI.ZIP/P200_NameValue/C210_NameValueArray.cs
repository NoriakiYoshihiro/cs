﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FormUI.Static;

namespace FormUI
{
    public class NameValueArray
    {
        // Step 1. コンストラクタでparentを確定 (ここでしか確定できない)
        // Step 2. Createの引数で配列サイズを指定(省略した場合は1)
        // 配列全てにExTextBox.Createでテキストボックス数を指定
        // 例 Text -> Array[index].Text
        //    All.Text -> 全配列のText


        // ======== コンストラクタ ========
        public NameValueArray(Form parent) => _parent = parent;

        // ======== 初期設定 ========
        public void Create() => Create(1);
        public void Create(int sizeOfArray)
        {
            NameValue = new NameValue[sizeOfArray];
            for (int i = 0; i < Length; i++)
            {
                NameValue[i] = new NameValue(_parent);
            }
            Index = 0;
        }

        // ======== プライベート ========
        private Form _parent;

        // ======== プロパティ ========
        public NameValue[] NameValue { get; set; }

        public NameValue Target { get => NameValue[Index]; set => NameValue[Index] = value; }

        public ExLabel ExLabel { get => Target.ExLabel; private set => Target.ExLabel = value; }
        public ExTextBoxArray ExTextBox { get => Target.ExTextBox; private set => Target.ExTextBox = value; }

        public int Length { get => NameValue.Length; }

        private int _index = 0;
        public int Index
        {
            get => _index;
            set
            {
                _index = value < 0 ? 0 : value >= Length ? Length - 1 : value;
            }
        }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area
        {
            get
            {
                var area0 = NameValue[0].Area;
                var top = area0.Top;
                var left = area0.Left;
                var bottom = area0.Bottom;
                var right = area0.Right;

                for (var i = 1; i < Length; i++)
                {
                    var area = NameValue[i].Area;
                    top = Smaller(top, area.Top);
                    left = Smaller(left, area.Left);
                    bottom = Larger(bottom, area.Bottom);
                    right = Larger(right, area.Right);
                }
                return (top, left, bottom, right);
            }
        }

        // ======== メソッド ========

        public void CreateSameNumOfTextBox(int sizeOfTextBox)
        {
            for (int i = 0; i < Length; i++)
            {

                NameValue[i].Create(sizeOfTextBox);
            }
        }

        public void SetKeyByIndex()
        {
            for (var i = 0; i < Length; i++)
            {
                NameValue[i].Key = String.Format("Key_{0:D3}", i);
            }
        }

        public bool SearchKeyIndex(string key)
        {
            for (var i = 0; i < Length; i++)
            {
                if (NameValue[i].Key == key)
                {
                    Index = i;
                    return true;
                }
            }
            return false;
        }


    }
}
