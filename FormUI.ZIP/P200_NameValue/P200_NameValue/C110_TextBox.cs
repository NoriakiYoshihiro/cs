﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public class UniqueTextBox
    {
        public UniqueTextBox(Form parent)
        {
            Text = "";
            ParentLocation = (0, 0);
            LocalLocation = (0, 0);
            Size = (120, 40);
            Body.Parent = parent;
        }

        internal TextBox Body { get; set; } = new TextBox();
        private (int X, int Y) parentLocation;
        private (int X, int Y) localLocation;

        public string Text
        {
            get => Body.Text;
            set => Body.Text = value;
        }

        public (int X, int Y) LocalLocation
        {
            get => localLocation;
            set
            {
                localLocation = value;
                CalculateLocation();
            }
        }

        public (int Width, int Height) Size
        {
            get => (Body.Size.Width, Body.Size.Height);
            set => Body.Size = new Size(value.Width, value.Height);
        }

        public (int Top, int Left, int Bottom, int Right) Area
        {
            get
            {
                var Top = Body.Location.Y;
                var Left = Body.Location.X;
                var Bottom = Body.Location.Y + Body.Size.Height;
                var Right = Body.Location.X + Body.Size.Width;
                return (Top, Left, Bottom, Right);
            }
        }

        public int FontSize
        {
            set => Body.Font = new Font(Body.Font.FontFamily, value);
        }

        public bool Multiline
        {
            set => Body.Multiline = value;
        }

        public bool ReadOnly
        {
            set => Body.ReadOnly = value;
        }

        public void SetAlignLeft() => Body.TextAlign = HorizontalAlignment.Left;
        public void SetAlignCenter() => Body.TextAlign = HorizontalAlignment.Center;
        public void SetAlignRight() => Body.TextAlign = HorizontalAlignment.Right;

        public void SetScrollBarsNone() => Body.ScrollBars = System.Windows.Forms.ScrollBars.None;
        public void SetScrollBarsHorizontal() => Body.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
        public void SetScrollBarsVertical() => Body.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
        public void SetScrollBarsBoth() => Body.ScrollBars = System.Windows.Forms.ScrollBars.Both;


        // 親コンテナからのみ
        internal (int X, int Y) ParentLocation
        {
            get => parentLocation;
            set
            {
                parentLocation = value;
                CalculateLocation();
            }
        }

        // 完全プライベート
        private void CalculateLocation()
        {
            Body.Location = new Point(ParentLocation.X + LocalLocation.X, ParentLocation.Y + LocalLocation.Y);
        }
    }

}
