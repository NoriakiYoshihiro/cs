﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Drawing;
using System.Xml.Linq;
using System.Reflection.Emit;
using System.Windows.Forms.VisualStyles;

namespace FormUI
{
    public partial class ExTextBox
    {
        // ======== ======== エレメント ======== ========
        public class TextBoxElement
        {
            // ======== コンストラクタ ========
            internal TextBoxElement(Form parent)
            {
                _textBox = new TextBox();
                _textBox.Parent = parent;
            }

            // ======== プライベートメンバー ========
            private TextBox _textBox;


            // ======== プロパティ ========
            // テキスト
            public string Text { get => _textBox.Text; set => _textBox.Text = value; }

            // フォント
            public string FontFamily { set => _textBox.Font = new Font(value, _textBox.Font.Size); }

            // フォントサイズ
            public int FontSize { set => _textBox.Font = new Font(_textBox.Font.FontFamily, value); }

            // サイズ
            public (int width, int height) Size
            {
                get => (_textBox.Size.Width, _textBox.Size.Height);
                set => _textBox.Size = new Size(value.width, value.height);
            }

            // 位置
            private (int X, int Y) _parentLocation;
            internal (int X, int Y) ParentLocation
            {
                get => _parentLocation;
                set
                {
                    _parentLocation = value;
                    Relocate();
                }
            }
            private (int X, int Y) _localLocation;
            public (int X, int Y) LocalLocation
            {
                get => _localLocation;
                set
                {
                    _localLocation = value;
                    Relocate();
                }
            }

            // ======== メソッド ========
            public void SetAlignLeft() => _textBox.TextAlign = HorizontalAlignment.Left; 
            public void SetAlignCenter() => _textBox.TextAlign = HorizontalAlignment.Center; 
            public void SetAlignRight() => _textBox.TextAlign = HorizontalAlignment.Right;

            // ======== 内部処理用 ========
            private void Relocate()
            {
                _textBox.Location = new Point(ParentLocation.X + LocalLocation.X, ParentLocation.Y + LocalLocation.Y);
            }
        }




        // ======== ======== 全エレメント ======== ========
        public class TextBoxAll
        {
            // ======== コンストラクタ ========
            internal TextBoxAll(TextBoxElement[] array) => _array = array;


            // ======== プライベートメンバー ========
            private TextBoxElement[] _array;


            // ======== プロパティ ========
            // テキスト
            public string Text { set => ExecuteAll(x => _array[x].Text = value); }

            // フォント
            public string FontFamily { set => ExecuteAll(x => _array[x].FontFamily = value); }

            // フォントサイズ
            public int FontSize { set => ExecuteAll(x => _array[x].FontSize = value); }

            // サイズ
            public (int width, int height) Size { set => ExecuteAll(x => _array[x].Size = value); }

            // 位置
            internal (int X, int Y) ParentLocation { set => ExecuteAll(x => _array[x].ParentLocation = value); }


            // ======== 内部処理用 ========
            private void ExecuteAll(Action<int> action)
            {
                for (int i = 0; i < _array.Length; i++) action(i);
            }
        }
    }
}
