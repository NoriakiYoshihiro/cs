﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Drawing;
using System.Xml.Linq;

namespace FormUI
{
    public partial class ExTextBox
    {
        // Step 1. コンストラクタでparentを確定 (ここでしか確定できない)
        // Step 2. Createの引数で配列サイズを指定(省略した場合は1)
        // Indexが配列番号指定を変更・保持
        // 例 Text -> Array[index].Text
        //    All.Text -> 全配列のText


        // ======== コンストラクタ ========
        public ExTextBox(Form parent) => _parent = parent;

        // ======== プライベート ========
        private Form _parent;

        // ======== プロパティ ========

        public TextBoxElement[] Array { get; set; }
        public TextBoxAll All { get; set; }
        public TextBoxElement Target
        {
            get => Array[Index];
            set => Array[Index] = value;
        }

        public int Length { get => Array.Length; }

        private int _index = 0;
        public int Index
        {
            get => _index;
            set => _index = value < 0 ? 0 : value >= Length ? Length - 1 : value;
        }


        // テキスト
        public string Text { get => Target.Text; set => Target.Text = value; }

        // フォント
        public string FontFamily { set => Target.FontFamily = value; }

        // フォントサイズ
        public int FontSize { set => Target.FontSize = value; }

        // サイズ
        public (int width, int height) Size
        {
            get => Target.Size;
            set => Target.Size = value;
        }

        // 位置
        public (int X, int Y) ParentLocation
        {
            get => Target.ParentLocation;
            set => Target.ParentLocation = value;

        }
        public (int X, int Y) LocalLocation
        {
            get => Target.LocalLocation;
            set => Target.LocalLocation = value;
        }


        // ======== メソッド ========
        public void Create() => Create(1);
        public void Create(int sizeOfArray)
        {
            Array = new TextBoxElement[sizeOfArray];
            for (int i = 0; i < Length; i++)
            {
                Array[i] = new TextBoxElement(_parent);
            }
            All = new TextBoxAll(Array);
            Index = 0;
        }

        // LocalLocation を (X,Y)から配列番号順に水平方向に並べていく
        public void SetAllLocalLocation(int X, int Y) => SetAllLocalLocation(X, Y, 120, 40, 10);
        public void SetAllLocalLocation(int X, int Y, int width, int height, int spaceWidth)
        {
            for (int i = 0; i < Length; i++)
            {
                var x = X + i * (width + spaceWidth);
                var y = Y;
                Array[i].Size = (width, height);
                Array[i].LocalLocation = (x, y);
            }
        }

    }
}
