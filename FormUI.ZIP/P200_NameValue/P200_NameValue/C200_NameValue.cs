﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FormUI.Static;

namespace FormUI
{
    public class NameValue
    {
        // コンストラクタ
        public NameValue(Form parent) => _parent = parent;

        // 初期化
        public void Create() => Create(1);
        public void Create(int sizeOfTextBoxArray)
        {
            Label = new ExLabel(_parent);
            TextBox = new ExTextBox(_parent);
            TextBox.Create(sizeOfTextBoxArray);
        }

        private Form _parent;

        public string Key { get; set; } = "";
        public ExLabel Label { get; set; }
        public ExTextBox TextBox { get; set; }

        public (int X, int Y) ParentLocation
        {
            set
            {
                Label.ParentLocation = value;
                TextBox.All.ParentLocation = value;
            }
        }
    }
}
