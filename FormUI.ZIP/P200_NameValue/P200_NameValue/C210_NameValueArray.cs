﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FormUI.Static;

namespace FormUI
{
    public class NameValueArray
    {
        // Step 1. コンストラクタでparentを確定 (ここでしか確定できない)
        // Step 2. Createの引数で配列サイズを指定(省略した場合は1)
        // 配列全てにExTextBox.Createでテキストボックス数を指定
        // 例 Text -> Array[index].Text
        //    All.Text -> 全配列のText


        // ======== コンストラクタ ========
        public NameValueArray(Form parent) => _parent = parent;

        // ======== プライベート ========
        private Form _parent;

        // ======== プロパティ ========
        public NameValue[] Array { get; set; }

        public NameValue Target { get => Array[Index]; set => Array[Index] = value; }

        public ExLabel Label { get => Target.Label; private set => Target.Label = value; }
        public ExTextBox TextBox { get => Target.TextBox; private set => Target.TextBox = value; }

        public int Length { get => Array.Length; }

        private int _index = 0;
        public int Index
        {
            get => _index;
            set
            {
                _index = value < 0 ? 0 : value >= Length ? Length - 1 : value;
            }
        }



        // ======== メソッド ========
        public void Create() => Create(1);
        public void Create(int sizeOfArray)
        {
            Array = new NameValue[sizeOfArray];
            for (int i = 0; i < Length; i++)
            {
                Array[i] = new NameValue(_parent);
            }
            Index = 0;
        }

        public void CreateSameSizeOfTextBox(int sizeOfTextBox)
        {
            for (int i = 0; i < Length; i++)
            {

                Array[i].Create(sizeOfTextBox);
            }
        }

        public void SetKeyByIndex()
        {
            for (var i = 0; i < Length; i++)
            {
                Array[i].Key = String.Format("Key_{0:D3}", i);
            }
        }

        public bool SearchKeyIndex(string key)
        {
            for (var i = 0; i < Length; i++)
            {
                if (Array[i].Key == key)
                {
                    Index = i;
                    return true;
                }
            }
            return false;
        }


    }
}
