﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class TestFormNameValue : Form
    {
        public NameValueArray NV;

        public TestFormNameValue()
        {
            InitializeComponent();
            SetNameValue();
        }

        public void SetNameValue()
        {
            NV = new NameValueArray(this);
            NV.Create(10);
            NV.CreateSameSizeOfTextBox(2);
            NV.SetKeyByIndex();

            for (var i = 0; i < NV.Length; i++)
            {
                NV.Index = i;
                var n = NV.Target;
                n.ParentLocation = (20, 20 + i * 45);


                n.Label.Text = "項目****" + i.ToString();
                n.Label.LocalLocation = (0, 0);
                n.Label.Size = (150, 30);
                n.Label.SetAlignMiddleRight();

                n.TextBox.SetAllLocalLocation(160, 4,120,30,10);

                n.TextBox.Index = 0;
                n.TextBox.Text = i.ToString() + ".00000";
  
                n.TextBox.Index = 1;
                n.TextBox.Text = n.Key;// "-" + i.ToString() + ".00000";
              }

            NV.Array[0].Label.Text = "歯数";
            NV.Array[1].Label.Text = "歯直角モジュール";
            NV.Array[2].Label.Text = "歯直角圧力角";
            NV.Array[3].Label.Text = "ねじれ角";

        }

        public void ShowMes()
        {
            var mes = "";
            mes += "NV.Length = " + NV.Length.ToString() + "\r\n";
            mes += "NV.Array[0].TextBox.Length = " + NV.Array[0].TextBox.Length.ToString();
            MessageBox.Show(mes);
        }
    }
}
