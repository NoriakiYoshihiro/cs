﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class TestFormNameValue : Form
    {
        public NameValueArray NV;

        public TestFormNameValue()
        {
            InitializeComponent();
            SetNameValue();
        }

        public void SetNameValue()
        {
            NV = new NameValueArray(this);
            NV.Create(10);
            NV.CreateSameNumOfTextBox(2);
            NV.SetKeyByIndex();

            for (var i = 0; i < NV.Length; i++)
            {
                NV.Index = i;
                var n = NV.Target;
                n.ParentLocation = (20, 20 + i * 45);


                n.ExLabel.Text = "項目****" + i.ToString();
                n.ExLabel.LocalLocation = (0, 0);
                n.ExLabel.Size = (150, 30);
                n.ExLabel.SetAlignMiddleRight();

                n.ExTextBox.SetLocalLocationSequent(160, 4,120,30,10);

                n.ExTextBox.Index = 0;
                n.ExTextBox.Text = i.ToString() + ".00000";
  
                n.ExTextBox.Index = 1;
                n.ExTextBox.Text = n.Key;// "-" + i.ToString() + ".00000";
              }

            NV.NameValue[0].ExLabel.Text = "歯数";
            NV.NameValue[1].ExLabel.Text = "歯直角モジュール";
            NV.NameValue[2].ExLabel.Text = "歯直角圧力角";
            NV.NameValue[3].ExLabel.Text = "ねじれ角";
        }

        public void ShowMes()
        {
            var mes = "";
            mes += "NV.Length = " + NV.Length.ToString() + "\r\n";
            mes += "NV.Array[0].TextBox.Length = " + NV.NameValue[0].ExTextBox.Length.ToString();
            MessageBox.Show(mes);
        }
    }
}
