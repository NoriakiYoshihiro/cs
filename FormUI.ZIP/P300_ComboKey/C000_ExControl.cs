﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace FormUI
{
    public enum ElementType { Null = 0, Label = 1, TextBox = 2, Button = 3, RadioButton = 4, CheckBox = 5, GroupBox = 6, Panel = 7 }
    public enum SelectType { Null = 0, Element = 1, Array = 2 }

    public static class IsElementType
    {
        public static bool Null(ElementType elementType) => elementType == ElementType.Null;
        public static bool Label(ElementType elementType) => elementType == ElementType.Label;
        public static bool TextBox(ElementType elementType) => elementType == ElementType.TextBox;
        public static bool Button(ElementType elementType) => elementType == ElementType.Button;
        public static bool RadioButton(ElementType elementType) => elementType == ElementType.RadioButton;
        public static bool CheckBox(ElementType elementType) => elementType == ElementType.CheckBox;
        public static bool GroupBox(ElementType elementType) => elementType == ElementType.GroupBox;
        public static bool Panel(ElementType elementType) => elementType == ElementType.Panel;

        public static bool Clickable(ElementType elementType)
        {
            ElementType[] clickable = new ElementType[] { ElementType.Label, ElementType.Button };
            foreach (var element in clickable)
            {
                if (elementType == element) return true;
            }
            return false;
        }
    }

    public static class A
    {
        public static Control CreateElement(ElementType elementType)
        {
            switch (elementType)
            {
                case ElementType.Label: return new Label();
                case ElementType.TextBox: return new TextBox();
                case ElementType.Button: return new Button();
                case ElementType.RadioButton: return new RadioButton();
                case ElementType.CheckBox: return new CheckBox();
                case ElementType.GroupBox: return new GroupBox();
                case ElementType.Panel: return new Panel();
                default: return null;
            }
        }
    }


    public class ExControl
    {
        public Label Label { get; protected set; }
        public TextBox TextBox { get; protected set; }
        public Button Button { get; protected set; }
        public RadioButton RadioButton { get; protected set; }
        public CheckBox CheckBox { get; protected set; }
        public GroupBox GroupBox { get; protected set; }
        public Panel Panel { get; protected set; }

        public Control Element { get; protected set; }

        public ExControl() { }
        public ExControl(ElementType elementType) => Create(elementType);

        public void Create(ElementType elementType)
        {
            Label = null;
            TextBox = null;
            Button = null;
            RadioButton = null;
            CheckBox = null;
            GroupBox = null;
            Panel = null;

            switch (elementType)
            {
                case ElementType.Label: Label = new Label(); Element = Label; break;
                case ElementType.TextBox: TextBox = new TextBox(); Element = TextBox; break;
                case ElementType.Button: Button = new Button(); Element = Button; break;
                case ElementType.RadioButton: RadioButton = new RadioButton(); Element = RadioButton; break;
                case ElementType.CheckBox: CheckBox = new CheckBox(); Element = CheckBox; break;
                case ElementType.GroupBox: GroupBox = new GroupBox(); Element = GroupBox; break;
                case ElementType.Panel: Panel = new Panel(); Element = Panel; break;
            }
        }

        // ID
        public string Id { get; set; }

        // 名前
        protected string _name;
        public string Name
        {
            get => Element.Name;
            set
            {
                Element.Name = value;
                _name = value;
            }
        }

        // ペアレント
        protected Control _parent;
        public Control Parent
        {
            get => Element.Parent;
            set
            {
                Element.Parent = value;
                _parent = value;
            }
        }

        // 位置
        public (int X, int Y) Location
        {
            get => (X, Y);
            set => Element.Location = new Point(X, Y);
        }
        public int X
        {
            get => Element.Location.X;
            set => Element.Location = new Point(value, Y);
        }
        public int Y
        {
            get => Element.Location.Y;
            set => Element.Location = new Point(X, value);
        }

        // サイズ
        public (int Width, int Height) Size
        {
            get => (Width, Height);
            set => Element.Size = new Size(value.Width, value.Height);
        }
        public int Width
        {
            get => Element.Width;
            set => Element.Width = value;
        }
        public int Height
        {
            get => Element.Height;
            set => Element.Height = value;
        }

        // フォント
        public Font Font
        {
            get => Element.Font;
            set => Element.Font = value;
        }

        // テキスト
        public string Text
        {
            get => Element.Text;
            set => Element.Text = value;
        }

        // 前景色・背景色
        public Color ForeColor
        {
            get => Element.ForeColor;
            set => Element.ForeColor = value;
        }
        public Color BackColor
        {
            get => Element.BackColor;
            set => Element.BackColor = value;
        }

        // 有効・無効
        public bool Enabled
        {
            get => Element.Enabled;
            set => Element.Enabled = value;
        }

        // 表示・非表示
        public bool Visible
        {
            get => Element.Visible;
            set => Element.Visible = value;
        }

        // クリック
        protected EventHandler _eh;
        public EventHandler Click
        {
            get => _eh;
            set
            {
                if (_eh != null) Element.Click -= _eh;
                Element.Click += value;
                _eh = value;
            }
        }
    }
}


