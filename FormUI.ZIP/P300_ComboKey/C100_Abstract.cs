﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Drawing;
using System.Dynamic;

namespace FormUI
{
    public abstract class ComboFull
    {
        public abstract SelectType SelectType { get; protected set; }

        public virtual void CreateElement(ElementType elementType) => throw new NotImplementedException();
        public virtual void SetElement(ExControl element) => throw new NotImplementedException();
        public virtual void CreateArray(int x) => throw new NotImplementedException();
        public virtual void SetArray(ComboFull[] array) => throw new NotImplementedException();

        // ID
        public string Id { get; set; }
        public abstract void ChangeId();

        // 位置
        protected int _xUpper, _yUpper;
        protected int _xSelf, _ySelf;
        public (int X, int Y) LocationUpper
        {
            get => (_xUpper, _yUpper);
            set
            {
                _xUpper = value.X;
                _yUpper = value.Y;
            }
        }
        public int XUpper
        {
            get => _xUpper;
            set
            {
                _xUpper = value;
                ChangeLocation();
            }
        }
        public int YUpper
        {
            get => _yUpper;
            set
            {
                _yUpper = value;
                ChangeLocation();
            }
        }
        public (int X, int Y) LocationSelf
        {
            get => (_xSelf, _ySelf);
            set
            {
                _xSelf = value.X;
                _ySelf = value.Y;
            }
        }
        public int XSelf
        {
            get => _xSelf;
            set
            {
                _xSelf = value;
                ChangeLocation();
            }
        }
        public int YSelf
        {
            get => _ySelf;
            set
            {
                _ySelf = value;
                ChangeLocation();
            }
        }
        public (int X, int Y) Location => (X, Y);
        public int X => _xUpper + _xSelf;
        public int Y => _yUpper + _ySelf;
        public abstract void ChangeLocation();

        // 有効・無効
        protected bool _enabledUpper;
        protected bool _enabledSelf;
        public bool EnabledUpper
        {
            get => _enabledUpper;
            set
            {
                _enabledUpper = value;
                ChangeEnabled();
            }
        }
        public bool EnabledSelf
        {
            get => _enabledSelf;
            set
            {
                _enabledSelf = value;
                ChangeEnabled();
            }
        }
        public bool Enabled => _enabledUpper && _enabledSelf;
        public abstract void ChangeEnabled();


        // 表示・非表示
        protected bool _visibleUpper;
        protected bool _visibleSelf;
        public bool VisibleUpper
        {
            get => _visibleUpper;
            set
            {
                _visibleUpper = value;
                ChangeVisible();
            }
        }
        public bool VisibleSelf
        {
            get => _visibleSelf;
            set
            {
                _visibleSelf = value;
                ChangeVisible();
            }
        }
        public bool Visible => _visibleUpper && _visibleSelf;
        public abstract void ChangeVisible();
    }
}
