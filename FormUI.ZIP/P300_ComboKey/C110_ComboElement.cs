﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Drawing;
using System.Security.Authentication.ExtendedProtection.Configuration;

namespace FormUI
{
    public class ComboElement : ComboFull
    {
        public ExControl Element { get; protected set; }
        public ElementType ElementType { get; protected set; } = ElementType.Null;

        public override SelectType SelectType { get; protected set; } = SelectType.Element;

        public override void CreateElement(ElementType elementType) =>Element.Create(elementType);
        public override void SetElement(ExControl element) => Element = element;


        // ID
        public override void ChangeId() { }

        // 位置
        public override void ChangeLocation() => Element.Location = Location;

        // 有効・無効
        public override void ChangeEnabled() => Element.Enabled = Enabled;

        // 表示・非表示
        public override void ChangeVisible() => Element.Visible = Visible;

    }
}
