﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Drawing;

namespace FormUI
{
    public class ComboArray : ComboFull
    {
        public ComboFull[] Array { get; protected set; }
        public override SelectType SelectType { get; protected set; } = SelectType.Array;


        public int Length => Array.Length;

        public override void CreateArray(int x) => Array = new ComboFull[x];


        // ID
        public override void ChangeId() { }

        // 位置
        public override void ChangeLocation() => ActOnAll(x => Array[x].LocationUpper = Location);

        // 有効・無効
        public override void ChangeEnabled() => ActOnAll(x => Array[x].EnabledUpper = Enabled);

        // 有効・無効
        public override void ChangeVisible() => ActOnAll(x => Array[x].VisibleUpper = Visible);



        protected void ActOnAll(Action<int> action)
        {
            for (var i = 0; i < Length; i++) action(i);
        }
    }
}
