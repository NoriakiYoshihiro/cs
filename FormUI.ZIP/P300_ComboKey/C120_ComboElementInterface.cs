﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public interface IComboElementUser
    {
        SelectType SelectType { get; }

        void CreateElement(ElementType elementType);
        void SetElement(ExControl element);

        // ID
        string Id { get; set; }
        void ChangeId();

        // 位置
        (int X, int Y) LocationUpper { get; set; }
        int XUpper { get; set; }
        int YUpper { get; set; }
        (int X, int Y) LocationSelf { get; set; }
        int XSelf { get; set; }
        int YSelf { get; set; }
        (int X, int Y) Location { get; set; }
        int X { get; set; }
        void ChangeLocation();

        // 有効・無効
        bool EnabledUpper { get; set; }

        bool EnabledSelf { get; set; }
        bool Enabled { get; }
        void ChangeEnabled();

        // 表示・非表示
        bool VisibleUpper { get; set; }
        bool VisibleSelf { get; set; }
        bool Visible { get; }
        void ChangeVisible();
    }
}
