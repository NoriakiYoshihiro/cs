﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FormUI.FastCalculator;

namespace FormUI
{
    public static class FastCalculator
    {
        public static int CutMinMax(int min, int max, int v) => v < min ? min : v > max ? max : v;
        public static int CutMin(int min, int v) => GetMax(min, v);
        public static int CutMax(int max, int v) => GetMin(max, v);
        public static int GetMin(params int[] args)
        {
            var min = args[0];
            foreach (var e in args) if (e < min) min = e;
            return min;
        }
        public static int GetMax(params int[] args)
        {
            var max = args[0];
            foreach (var e in args) if (e > max) max = e;
            return max;
        }
    }


    public class Element { }

    public abstract class CommonInterface //: ICommonElement, ICommonArray
    {
        // 有効・無効
        protected bool _enabledUpper;
        protected bool _enabledSelf;
        public bool EnabledUpper
        {
            get => _enabledUpper;
            set
            {
                _enabledUpper = value;
                ChangeEnabled();
            }
        }
        public bool EnabledSelf
        {
            get => _enabledSelf;
            set
            {
                _enabledSelf = value;
                ChangeEnabled();
            }
        }
        public bool Enabled => _enabledUpper && _enabledSelf;
        public abstract void ChangeEnabled();
    }

    public class CommonElement
    {
        public Element Element { get; set; }
        public override void ChangeEnabled() => Element.Enabled=
    }
    //public interface ICommonElement { }
    //public interface ICommonArray { }

    public class Combo
    {
        public Element Element { get => ElementArray[ElementPointer]; }
        public Element[] ElementArray { get; protected set; }
        public Combo[] ComboArray { get; protected set; }
        public ICommonElement ICommonElement { get; protected set; }
        public ICommonArray ICommonArray { get; protected set; }
        public CommonInterface CommonInterface { get; protected set; }

        protected int _elementPointer = 0;
        public int ElementPointer
        {
            get => _elementPointer;
            set => CutMinMax(0, ElementPointer - 1, value);
        }
        public int LengthGiven { get; protected set; } = 0;

        // エレメント式の手配
        public void UseElementMode()
        {
            Create(1);

            ICommonElement = new CommonInterface();
            CommonInterface = (CommonInterface)ICommonElement;
        }

        // アレイ式の手配
        public void UseArrayMode(int length)
        {
            Create(CutMin(1, length));

            ElementArray[0] = new Element();
            ComboArray[0] = null;
        }

        protected void Create(int length)
        {
            LengthGiven = length;
            ElementArray = new Element[length];
            ComboArray = new Combo[length];
            ElementPointer = 0;
        }




        /*
        public abstract string Name { get; }    

        public Control Element;
        public CommonFull[] Array;

        // 有効・無効
        protected bool _enabledUpper;
        protected bool _enabledSelf;
        public bool EnabledUpper
        {
            get => _enabledUpper;
            set
            {
                _enabledUpper = value;
                ChangeEnabled();
            }
        }
        public bool EnabledSelf
        {
            get => _enabledSelf;
            set
            {
                _enabledSelf = value;
                ChangeEnabled();
            }
        }
        public bool Enabled => _enabledUpper && _enabledSelf;
        public abstract void ChangeEnabled();

        // 表示・非表示
        protected bool _visibleUpper;
        protected bool _visibleSelf;
        public bool VisibleUpper
        {
            get => _visibleUpper;
            set
            {
                _visibleUpper = value;
                ChangeVisible();
            }
        }
        public bool VisibleSelf
        {
            get => _visibleSelf;
            set
            {
                _visibleSelf = value;
                ChangeVisible();
            }
        }
        public bool Visible => _visibleUpper && _visibleSelf;
        public abstract void ChangeVisible();
    }

    public class CommonFull : CommonAbstract
    {
        public override void ChangeEnabled() { }
        public override void ChangeVisible() { }
    }


    public class Common : CommonFull
    {
        public override void ChangeEnabled() { }
        public override void ChangeVisible() { }

    }
        */

    }
