﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public interface IComboInterface
    {
        bool EnabledUpper { get; set; }
        bool EnabledSelf { get; set; }
        bool Enabled { get; }
        bool VisibleUpper { get; set; }
        bool VisibleSelf { get; set; }
        bool Visible { get; }
    }

    public abstract class ComboBase : IComboInterface
    {
        // 有効・無効
        protected bool _enabledUpper;
        protected bool _enabledSelf;
        public bool EnabledUpper
        {
            get => _enabledUpper;
            set
            {
                _enabledUpper = value;
                ChangeEnabled();
            }
        }
        public bool EnabledSelf
        {
            get => _enabledSelf;
            set
            {
                _enabledSelf = value;
                ChangeEnabled();
            }
        }
        public bool Enabled => _enabledUpper && _enabledSelf;
        public abstract void ChangeEnabled();


        // 表示・非表示
        protected bool _visibleUpper;
        protected bool _visibleSelf;
        public bool VisibleUpper
        {
            get => _visibleUpper;
            set
            {
                _visibleUpper = value;
                ChangeVisible();
            }
        }
        public bool VisibleSelf
        {
            get => _visibleSelf;
            set
            {
                _visibleSelf = value;
                ChangeVisible();
            }
        }
        public bool Visible => _visibleUpper && _visibleSelf;
        public abstract void ChangeVisible();
    }

    public class ComboLabel : ComboBase, IComboUser
    {
        public Label Label { get; set; }

        public override void ChangeEnabled() { }
        public override void ChangeVisible() { }
    }

    public interface IComboUser
    {
        bool EnabledSelf { get; set; }
    }
    public interface 



    public class Container
    {
        public Label Label { get; set; }
        public ComboLabel CFull;


        


        public override void ChangeEnabled() { }
        public override void ChangeVisible() { }
    }

}
