﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Test();
        }

        public ComboElement e;
        public ComboArray a;

        public void Test()
        {
            e = new ComboElement();
            a = new ComboArray();
            a.Array[0] = new ComboElement();
            a.Array[1] = new ComboArray();

            e.LocationSelf = (0, 0);
            a.Array[0].LocationSelf = (10, 10);
        }

    }
}

