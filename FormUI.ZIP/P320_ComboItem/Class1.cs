﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Drawing;

namespace FormUI
{
    public enum CellType { Null = 0, Element = 1, Array = 2 }
    public enum ElementType { Null = 0, Label = 1, TextBox = 2, Button = 3 }

    public abstract class ClassAbstract
    {
        public ClassAbstract[] Array { get; set; }

        public CellType CellType { get; protected set; } = CellType.Null;

        // クリエイト
        public virtual void CreateArray(int length) => throw new Exception();
        public virtual void CreateElementInArray(int n, ElementType elementType) => throw new Exception();
        public virtual void CreateArrayInArray(int n, int length) => throw new Exception();

        // ペアレント
        protected Control _parent;
        public Control Parent
        {
            get => _parent;
            set
            {
                _parent = value;
                ChangeParent();
            }
        }
        public abstract void ChangeParent();

        // 位置
        protected int _xUpper, _yUpper;
        protected int _xSelf, _ySelf;
        public (int X, int Y) LocationUpper
        {
            get => (_xUpper, _yUpper);
            set
            {
                _xUpper = value.X;
                _yUpper = value.Y;
                ChangeLocation();
            }
        }
        public int XUpper
        {
            get => _xUpper;
            set
            {
                _xUpper = value;
                ChangeLocation();
            }
        }
        public int YUpper
        {
            get => _yUpper;
            set
            {
                _yUpper = value;
                ChangeLocation();
            }
        }
        public (int X, int Y) LocationSelf
        {
            get => (_xSelf, _ySelf);
            set
            {
                _xSelf = value.X;
                _ySelf = value.Y;
                ChangeLocation();
            }
        }
        public int XSelf
        {
            get => _xSelf;
            set
            {
                _xSelf = value;
                ChangeLocation();
            }
        }
        public int YSelf
        {
            get => _ySelf;
            set
            {
                _ySelf = value;
                ChangeLocation();
            }
        }
        public (int X, int Y) Location => (X, Y);
        public int X => _xUpper + _xSelf;
        public int Y => _yUpper + _ySelf;
        public abstract void ChangeLocation();

        // サイズ
        public abstract (int Width, int Height) Size { get; set; }
        public abstract int Width { get; set; }
        public abstract int Height { get; set; }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => (Top, Left, Bottom, Right);
        public abstract int Top { get; }
        public abstract int Left { get; }
        public abstract int Bottom { get; }
        public abstract int Right { get; }

        public virtual string Text { get => throw new Exception(); set => throw new Exception(); }

        // 有効・無効
        protected bool _enabledUpper;
        protected bool _enabledSelf;
        public bool EnabledUpper
        {
            get => _enabledUpper;
            set
            {
                _enabledUpper = value;
                ChangeEnabled();
            }
        }
        public bool EnabledSelf
        {
            get => _enabledSelf;
            set
            {
                _enabledSelf = value;
                ChangeEnabled();
            }
        }
        public bool Enabled => _enabledUpper && _enabledSelf;
        public abstract void ChangeEnabled();

        // 表示・非表示
        protected bool _visibleUpper;
        protected bool _visibleSelf;
        public bool VisibleUpper
        {
            get => _visibleUpper;
            set
            {
                _visibleUpper = value;
                ChangeVisible();
            }
        }
        public bool VisibleSelf
        {
            get => _visibleSelf;
            set
            {
                _visibleSelf = value;
                ChangeVisible();
            }
        }
        public bool Visible => _visibleUpper && _visibleSelf;
        public abstract void ChangeVisible();
    }

    public class ClassElement : ClassAbstract
    {
        public ElementType ElementType { get; protected set; }
        public Label Label { get; protected set; }
        public TextBox TextBox { get; protected set; }
        public Button Button { get; protected set; }
        public Control Element { get; protected set; }

        // ======== コンストラクタ ========
        public ClassElement() { }
        public ClassElement(ElementType elementType) => CreateElement(elementType);

        // クリエイト
        public void CreateElement(ElementType elementType)
        {
            ElementType = elementType;
            switch (ElementType)
            {
                case ElementType.Label:
                    Label = new Label();
                    Element = Label;
                    break;
                case ElementType.TextBox:
                    TextBox = new TextBox();
                    Element = TextBox;
                    break;
                case ElementType.Button:
                    Button = new Button();
                    Element = Button;
                    break;
                default: break;
            }
        }

        // ペアレント
        public override void ChangeParent() => Element.Parent = Parent;

        // 位置
        public override void ChangeLocation() => Element.Location = new Point(X, Y);

        // サイズ
        public override (int Width, int Height) Size { get; set; }
        public override int Width
        {
            get => Element.Width;
            set => Element.Width = value;
        }
        public override int Height
        {
            get => Element.Height;
            set => Element.Height = value;
        }

        // エリア
        public override int Top => Y;
        public override int Left => X;
        public override int Bottom => Y + Height;
        public override int Right => X + Width;

        // 有効・無効
        public override void ChangeEnabled() => Element.Enabled = Enabled;
        // 表示・非表示
        public override void ChangeVisible() => Element.Visible = Enabled;


        // 名前
        public string Name
        {
            get => Element.Name;
            set => Element.Name = value;
        }

        // タブインデックス
        protected int _tabIndex;
        public int TabIndex
        {
            get => Element.TabIndex;
            set
            {
                _tabIndex = value;
                Element.TabIndex = value;
            }
        }

        // テキスト
        public override string Text
        {
            get => Element.Text;
            set => Element.Text = value;
        }

        // フォント
        public Font Font
        {
            get => Element.Font;
            set => Element.Font = value;
        }

        // 前景色・背景色
        public Color ForeColor
        {
            get => Element.ForeColor;
            set => Element.ForeColor = value;
        }
        public Color BackColor
        {
            get => Element.BackColor;
            set => Element.BackColor = value;
        }

        protected EventHandler _eh;
        public EventHandler Click
        {
            get => _eh;
            set
            {
                if (_eh != null) Element.Click -= _eh;
                _eh = value;
                Element.Click += _eh;
            }
        }

    }


    public class ClassCommon : ClassAbstract
    {
        // ======== コンストラクタ ========
        public ClassCommon() { }
        public ClassCommon(int length) => CreateArray(length);

        // クリエイト
        public override void CreateArray(int length) => Array = new ClassAbstract[length];

        // レンクス
        public int Length => Array.Length;

        public override void CreateElementInArray(int n, ElementType elementType) => Array[n] = new ClassElement(elementType);
        public override void CreateArrayInArray(int n, int length) => Array[n] = new ClassCommon(length);

        // ペアレント
        public override void ChangeParent() => ActOnAll(x => Array[x].Parent = Parent);

        // 位置
        public override void ChangeLocation() => ActOnAll(x => Array[x].LocationUpper = Location);

        // サイズ
        public override (int Width, int Height) Size
        {
            get => (Width, Height);
            set => throw new Exception();
        }
        public override int Width
        {
            get => Right - Left;
            set => throw new Exception();
        }
        public override int Height
        {
            get => Bottom - Top;
            set => throw new Exception();
        }

        // エリア
        public override int Top => SearchAreaCorner(x => Array[x].Top, 1);
        public override int Left => SearchAreaCorner(x => Array[x].Left, 1);
        public override int Bottom => SearchAreaCorner(x => Array[x].Bottom, -1);
        public override int Right => SearchAreaCorner(x => Array[x].Right, -1);
        protected int SearchAreaCorner(Func<int, int> func, int sign)
        {
            var ret = func(0);
            for (var i = 1; i < Length; i++) if (sign * func(0) < sign * ret) ret = func(0);
            return ret;
        }

        // 有効・無効
        public override void ChangeEnabled() => ActOnAll(x => Array[x].EnabledUpper = Enabled);
        // 表示・非表示
        public override void ChangeVisible() => ActOnAll(x => Array[x].VisibleUpper = Visible);


        public void ActOnAll(Action<int> action)
        {
            for (var i = 0; i < Array.Length; i++) action(i);
        }

    }
}
