﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    internal static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());

            var f = new Form();
            var c = new ClassCommon();
            c.CreateArray(5);
            c.CreateElementInArray(0, ElementType.Label);
            c.CreateArrayInArray(1, 5);
            c.Array[0].Text = "Hello";
            MessageBox.Show(c.Array[0].Text);
            var c2 = c.Array[1];
            c2.CreateArray(7);
            c2.CreateElementInArray(4, ElementType.Label);
            c2.Array[4].Text = "Great!!";
            MessageBox.Show(c.Array[1].Array[4].Text);

            Button button1 = new Button();
            Button button2 = new Button();

            f.Size = new System.Drawing.Size(500, 500);

            button1.Parent = f;
            button1.Location = new System.Drawing.Point(100, 100);
            button1.Size = new System.Drawing.Size(160, 60);
            button1.Text="button1";
            button1.Anchor = AnchorStyles.Bottom;

            button2.Parent = f;
            button2.Location = new System.Drawing.Point(100, 200);
            button2.Size = new System.Drawing.Size(160, 60);
            button2.Text = "button2";
      

            f.ShowDialog();

        }
    }
}
