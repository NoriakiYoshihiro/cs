﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;


namespace FormUI
{
    public enum ObjectType { Null = 0, Label = 1, TextBox = 2, Button = 3, RadioButton = 4, CheckBox = 5, GroupBox = 6, Panel = 7 }

    public abstract class FlexTableAbstract
    {
        // ペアレント
        protected Control _parent;
        public virtual Control Parent
        {
            get => _parent;
            set
            {
                _parent = value;
                ReflectParent();
            }
        }
        public abstract void ReflectParent();

        // 位置
        protected int _xUpper, _yUpper;
        protected int _xSelf, _ySelf;
        public virtual (int X, int Y) LocationUpper
        {
            get => (_xUpper, _yUpper);
            set
            {
                _xUpper = value.X;
                _yUpper = value.Y;
                ReflectLocation();
            }
        }
        public virtual int XUpper
        {
            get => _xUpper;
            set
            {
                _xUpper = value;
                ReflectLocation();
            }
        }
        public virtual int YUpper
        {
            get => _yUpper;
            set
            {
                _yUpper = value;
                ReflectLocation();
            }
        }
        public virtual (int X, int Y) LocationSelf
        {
            get => (_xSelf, _ySelf);
            set
            {
                _xSelf = value.X;
                _ySelf = value.Y;
                ReflectLocation();
            }
        }
        public virtual int XSelf
        {
            get => _xSelf;
            set
            {
                _xSelf = value;
                ReflectLocation();
            }
        }
        public virtual int YSelf
        {
            get => _ySelf;
            set
            {
                _ySelf = value;
                ReflectLocation();
            }
        }
        public virtual (int X, int Y) Location => (X, Y);
        public virtual int X => _xUpper + _xSelf;
        public virtual int Y => _yUpper + _ySelf;
        public abstract void ReflectLocation();

        // サイズ
        public abstract (int Width, int Height) Size { get; set; }
        public abstract int Width { get; set; }
        public abstract int Height { get; set; }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => (Top, Left, Bottom, Right);
        public abstract int Top { get; }
        public abstract int Left { get; }
        public abstract int Bottom { get; }
        public abstract int Right { get; }

        // 有効・無効
        protected bool _enabledUpper = true;
        protected bool _enabledSelf = true;
        public virtual bool EnabledUpper
        {
            get => _enabledUpper;
            set
            {
                _enabledUpper = value;
                ReflectEnabled();
            }
        }
        public virtual bool EnabledSelf
        {
            get => _enabledSelf;
            set
            {
                _enabledSelf = value;
                ReflectEnabled();
            }
        }
        public virtual bool Enabled => _enabledUpper && _enabledSelf;
        public abstract void ReflectEnabled();

        // 表示・非表示
        protected bool _visibleUpper = true;
        protected bool _visibleSelf = true;
        public virtual bool VisibleUpper
        {
            get => _visibleUpper;
            set
            {
                _visibleUpper = value;
                ReflectVisible();
            }
        }
        public virtual bool VisibleSelf
        {
            get => _visibleSelf;
            set
            {
                _visibleSelf = value;
                ReflectVisible();
            }
        }
        public virtual bool Visible => _visibleUpper && _visibleSelf;
        public abstract void ReflectVisible();
    }

}
