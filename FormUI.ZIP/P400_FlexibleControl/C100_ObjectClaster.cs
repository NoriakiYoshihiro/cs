﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using System.Net.Http.Headers;

namespace FormUI
{
    // オブジェクト
    public class Object : FlexTableAbstract
    {
        public Label Label { get; protected set; }
        public TextBox TextBox { get; protected set; }
        public Button Button { get; protected set; }
        public RadioButton RadioButton { get; protected set; }
        public CheckBox CheckBox { get; protected set; }
        public GroupBox GroupBox { get; protected set; }
        public Panel Panel { get; protected set; }

        protected Control _body;
        public Control Body
        {
            get => _body;
            protected set
            {
                _body = value;
                InheritFormer();
            }
        }

        public bool IsNull => Body != null;
        public bool IsLabel => Label != null;
        public bool IsTextBox => TextBox != null;
        public bool IsButton => Button != null;
        public bool IsRadioButton => RadioButton != null;
        public bool IsCheckBox => CheckBox != null;
        public bool IsGroupBox => GroupBox != null;
        public bool IsPanel => Panel != null;

        // インスタンスのリセット
        public void Reset()
        {
            if (Body == null) return;
            Body.Dispose();

            Label?.Dispose();
            TextBox?.Dispose();
            Button?.Dispose();
            RadioButton?.Dispose();
            CheckBox?.Dispose();
            GroupBox?.Dispose();
            Panel?.Dispose();
        }

        // インスタンスの生成
        public void Create(ObjectType elementType)
        {
            Reset();

            switch (elementType)
            {
                case ObjectType.Label: Label = new Label(); Body = Label; break;
                case ObjectType.TextBox: TextBox = new TextBox(); Body = TextBox; break;
                case ObjectType.Button: Button = new Button(); Body = Button; break;
                case ObjectType.RadioButton: RadioButton = new RadioButton(); Body = RadioButton; break;
                case ObjectType.CheckBox: CheckBox = new CheckBox(); Body = CheckBox; break;
                case ObjectType.GroupBox: GroupBox = new GroupBox(); Body = GroupBox; break;
                case ObjectType.Panel: Panel = new Panel(); Body = Panel; break;
                default: return;
            }
        }


        // インスタンスの受取
        public void Set(Label label) => SetSub(() => Label = label);
        public void Set(TextBox textBox) => SetSub(() => TextBox = textBox);
        public void Set(Button button) => SetSub(() => Button = button);
        public void Set(RadioButton radioButton) => SetSub(() => RadioButton = radioButton);
        public void Set(CheckBox checkBox) => SetSub(() => CheckBox = checkBox);
        public void Set(GroupBox groupBox) => SetSub(() => GroupBox = groupBox);
        public void Set(Panel panel) => SetSub(() => Panel = panel);
        protected void SetSub(Action action) { Reset(); action(); InheritFormer(); }

        // 前インスタンスの継承
        protected void InheritFormer()
        {
            if (Body == null) return;
            ReflectParent();
            ReflectLocation();
            ReflectSize();
            ReflectEnabled();
            ReflectVisible();
            ReflectName();
            ReflectTabIndex();
        }

        // ペアレント
        public override void ReflectParent() => Body.Parent = Parent;

        // 位置
        public override void ReflectLocation() => Body.Location = new Point(X, Y);

        // サイズ
        protected int _width, _height;
        public override (int Width, int Height) Size
        {
            get => (Width, Height);
            set
            {
                _width = value.Width;
                _height = value.Height;
                ReflectSize();
            }
        }
        public override int Width
        {
            get => _width;
            set
            {
                _width = value;
                ReflectSize();
            }
        }
        public override int Height
        {
            get => _height;
            set
            {
                _height = value;
                ReflectSize();
            }
        }
        public void ReflectSize() => Body.Size = new Size(Width, Height);

        // エリア
        public override int Top => Y;
        public override int Left => X;
        public override int Bottom => Y + Height;
        public override int Right => X + Width;

        // 有効・無効
        public override void ReflectEnabled() => Body.Enabled = Enabled;
        // 表示・非表示
        public override void ReflectVisible() => Body.Visible = Enabled;

        // 名前
        public string _name;
        public string Name
        {
            get => Body.Name;
            set
            {
                _name = value;
                ReflectName();
            }
        }
        public void ReflectName() => Body.Name = Name;

        // タブインデックス
        protected int _tabIndex;
        public int TabIndex
        {
            get => Body.TabIndex;
            set
            {
                _tabIndex = value;
                ReflectTabIndex();
            }
        }
        public void ReflectTabIndex() => Body.TabIndex = TabIndex;

        // テキスト
        public string Text
        {
            get => Body.Text;
            set => Body.Text = value;
        }

        // フォント
        public Font Font
        {
            get => Body.Font;
            set => Body.Font = value;
        }

        // 前景色・背景色
        public Color ForeColor
        {
            get => Body.ForeColor;
            set => Body.ForeColor = value;
        }
        public Color BackColor
        {
            get => Body.BackColor;
            set => Body.BackColor = value;
        }

        protected EventHandler _eh;
        public EventHandler Click
        {
            get => _eh;
            set
            {
                if (_eh != null) Body.Click -= _eh;
                _eh = value;
                Body.Click += _eh;
            }
        }
    }
}
