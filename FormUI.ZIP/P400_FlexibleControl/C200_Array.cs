﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Xml.Linq;
namespace FormUI
{
    // 配列
    public class FlexTableArray : FlexTableAbstract
    {
        public Object[][] Array { get; protected set; }
        public Object[] Thread { get; protected set; }

        public void CreateArray(int row, int col)
        {
            LengthOfRow = row;
            LengthOfCol = col;
            Func<int, int> Row = x => x / LengthOfCol;
            Func<int, int> Col = x => x % LengthOfCol;

            CreateActualThread();

            Array = new Object[LengthOfRow][];
            for (var i = 0; i < LengthOfRow; i++) Array[i] = new Object[col];
            ActOnAll(x => Array[Row(x)][Col(x)] = Thread[x]);
        }
        public void CreateThread(int length)
        {
            LengthOfRow = 1;
            LengthOfCol = length;
            Array = null;
            CreateActualThread();
        }
        protected void CreateActualThread()
        {
            Thread = new Object[Length];
            ActOnAll(x => Thread[x] = new Object());
        }

        public int LengthOfRow { get; protected set; }
        public int LengthOfCol { get; protected set; }
        public int Length => LengthOfRow * LengthOfCol;

        // ペアレント
        public override void ReflectParent() => ActOnAll(x => Thread[x].Parent = Parent);

        // 位置
        public override void ReflectLocation() => ActOnAll(x => Thread[x].LocationUpper = Location);

        // サイズ
        public override (int Width, int Height) Size
        {
            get => (Width, Height);
            set => throw new Exception();
        }
        public override int Width
        {
            get => Right - Left;
            set => throw new Exception();
        }
        public override int Height
        {
            get => Bottom - Top;
            set => throw new Exception();
        }

        // エリア
        public override int Top => SearchAreaCorner(x => Thread[x].Top, 1);
        public override int Left => SearchAreaCorner(x => Thread[x].Left, 1);
        public override int Bottom => SearchAreaCorner(x => Thread[x].Bottom, -1);
        public override int Right => SearchAreaCorner(x => Thread[x].Right, -1);
        protected int SearchAreaCorner(Func<int, int> func, int sign)
        {
            var ret = func(0);
            for (var i = 1; i < Length; i++)
                if (sign * func(i) < sign * ret) ret = func(i);
            return ret;
        }

        // 有効・無効
        public override void ReflectEnabled() => ActOnAll(x => Thread[x].EnabledUpper = Enabled);
        // 表示・非表示
        public override void ReflectVisible() => ActOnAll(x => Thread[x].VisibleUpper = Visible);


        protected void ActOnAll(Action<int> action)
        {
            for (var i = 0; i < Length; i++) action(i);
        }
    }

    public class Test
    {
        public Object exControl = new Object();
        public FlexTableArray exArray = new FlexTableArray();
        public FlexTableAbstract exArrayAbstract = new FlexTableArray();

        public void SubTest()
        {


        }
    }
}
