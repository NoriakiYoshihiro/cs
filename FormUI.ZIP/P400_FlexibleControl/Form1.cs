﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DoFirst();
        }

        public void DoFirst()
        {
            var o1 = new Object();
            o1.Create(ObjectType.Label);
            o1.Parent = this;
            o1.LocationSelf = (10, 10);
            o1.Size = (300, 80);
            o1.Text = "TEST OBJECT";
            //o1.VisibleSelf = true;

            var o2 = new Object();
            o2.Create(ObjectType.Button);
            o2.Parent = this;
            o2.LocationSelf = (10, 100);
            o2.Size = (300, 80);
            o2.Text = "Change Label";
            o2.Click = (s, e) =>{ o1.Create(ObjectType.TextBox); o1.Text = "Changed!"; o1.ForeColor = Color.Red; };
            //o1.VisibleSelf = true;

            var o3= new Object();
            o3.Create(ObjectType.GroupBox);
            o3.Parent = this;
            o3.LocationSelf = (10, 240);
            o3.Size = (300, 300);

            var o4=new Object();
            o4.Create(ObjectType.RadioButton);
            o4.Parent = o3.Body;
            o4.LocationSelf = (25, 25);
            o4.Size = (120, 20);
            o4.Text = "Test1";

            var o5 = new Object();
            o5.Create(ObjectType.RadioButton);
            o5.Parent = o3.Body;
            o5.LocationSelf = (25, o4.Bottom);
            o5.Size = (120, 30);
            o5.Text = "Test2";
            o5.Click = (s, e) => MessageBox.Show("Click Test2 RadioButton");
        }
    }
}
