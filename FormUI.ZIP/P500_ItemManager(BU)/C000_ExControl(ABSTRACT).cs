﻿using System;
using System.Drawing;
using System.Windows.Forms;


namespace FormUI
{
    public abstract class ExControl
    {
        // 実体
        public Control Body { get; protected set; }

        // 廃棄
        public void Dispose() => Body?.Dispose();

        // ペアレント
        public Control Parent
        {
            get => Body.Parent;
            set => Body.Parent = value;
        }

        // 位置
        public (int X, int Y) Location
        {
            get => (X, Y);
            set => Body.Location = new Point(value.X, value.Y);
        }
        public int X
        {
            get => Body.Location.X;
            set => Body.Location = new Point(value, Y);
        }
        public int Y
        {
            get => Body.Location.Y;
            set => Body.Location = new Point(X, value);
        }

        // サイズ
        public (int Width, int Height) Size
        {
            get => (Width, Height);
            set => Body.Size = new Size(value.Width, value.Height);
        }
        public int Width
        {
            get => Body.Width;
            set => Body.Width = value;
        }
        public int Height
        {
            get => Body.Height;
            set => Body.Height = value;
        }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => (Top, Left, Bottom, Right);
        public int Top => Y;
        public int Left => X;
        public int Bottom => Y + Height;
        public int Right => X + Width;

        // 有効・無効
        public bool Enabled
        {
            get => Body.Enabled;
            set => Body.Enabled = value;
        }

        // 表示・非表示
        public bool Visible
        {
            get => Body.Visible;
            set => Body.Visible = value;
        }

        // 名前
        public string Name
        {
            get => Body.Name;
            set => Body.Name = value;
        }

        // タブインデックス
        public int TabIndex
        {
            get => Body.TabIndex;
            set => Body.TabIndex = value;
        }

        // テキスト
        public string Text
        {
            get => Body.Text;
            set => Body.Text = value;
        }

        // フォント
        public Font Font
        {
            get => Body.Font;
            set => Body.Font = value;
        }

        // 前景色・背景色
        public Color ForeColor
        {
            get => Body.ForeColor;
            set => Body.ForeColor = value;
        }
        public Color BackColor
        {
            get => Body.BackColor;
            set => Body.BackColor = value;
        }

        // クリックイベント
        protected EventHandler _eh;
        public EventHandler Click
        {
            get => _eh;
            set
            {
                if (_eh != null) Body.Click -= _eh;
                _eh = value;
                Body.Click += _eh;
            }
        }
    }
}
