﻿namespace FormUI
{
    public enum ExControlType
    {
        Null = 0,
        ExLabel = 1,
        ExTextBox = 2,
        ExButton = 3,
        ExRadioButton = 4,
        ExCheckBox = 5,
        ExGroupBox = 6,
        ExPanel = 7,
        ExGroupBoxSp = 8,
        ExPanelSp = 9,
        ExAbstract =99
    }

    public class CreateExControl
    {
        ExLabel ExLabel { get; set; }
        ExTextBox ExTextBox { get; set; }
        ExButton ExButton { get; set; }
        ExRadioButton ExRadioButton { get; set; }
        ExCheckBox ExCheckBox { get; set; }
        ExGroupBox ExGroupBox { get; set; }
        ExPanel ExPanel { get; set; }
        ExGroupBoxSp ExGroupBoxSp { get; set; }
        ExPanelSp ExPanelSp { get; set; }
    }

}
