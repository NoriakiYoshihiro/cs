﻿using System;
using System.Windows.Forms;

namespace FormUI
{
    public class ExLabel : ExControl
    {
        private Label _body = new Label();
        public ExLabel() => Body = _body;
    }

    public class ExTextBox : ExControl
    {
        private TextBox _body = new TextBox();
        public ExTextBox() => Body = _body;
    }

    public class ExButton : ExControl
    {
        private Button _body = new Button();
        public ExButton() => Body = _body;
    }

    public class ExRadioButton : ExControl
    {
        private RadioButton _body = new RadioButton();
        public ExRadioButton() => Body = _body;
    }

    public class ExCheckBox : ExControl
    {
        private CheckBox _body = new CheckBox();
        public ExCheckBox() => Body = _body;
    }

    public class ExGroupBox : ExControl
    {
        private GroupBox _body = new GroupBox();
        public ExGroupBox() => Body = _body;
    }

    public class ExPanel : ExControl
    {
        private Panel _body = new Panel();
        public ExPanel() => Body = _body;
    }
}