﻿using System;
using System.Windows.Forms;

namespace FormUI
{
    public abstract class ExGroupBoxPanel : ExControl
    {
        public ExRadioButton[] ExRadioButtonArray { get; protected set; }
        public ExCheckBox[] ExCheckBoxArray { get; protected set; }
        public ExControlType ExArrayType { get; protected set; } = ExControlType.Null;
        public ExControl[] Item { get; protected set; }

        // ======== プロパティ ========

        public int Length
        {
            get
            {
                switch (ExArrayType)
                {
                    case ExControlType.ExRadioButton: Item = ExRadioButtonArray; return ExRadioButtonArray.Length;
                    case ExControlType.ExCheckBox: Item = ExCheckBoxArray; return ExCheckBoxArray.Length;
                    case ExControlType.Null: Item = null; return -1;
                    default: Item = null; throw new Exception();
                }
            }
        }


        // ======== メソッド ========

        // ExRadioButton、ExCheckBoxアレイの取り込み
        public void ImportArray(ExRadioButton[] array)
        {
            DisposeArray();
            ExRadioButtonArray = array;
            ExArrayType = ExControlType.ExRadioButton;
            ConnectParent();
        }

        public void ImportArray(ExCheckBox[] array)
        {
            DisposeArray();
            ExCheckBoxArray = array;
            ExArrayType = ExControlType.ExCheckBox;
            ConnectParent();
        }

        // ExRadioButton、ExCheckBoxアレイの創成
        public void CreateExRadioButtonArray(int length)
        {
            DisposeArray();
            ExRadioButtonArray = new ExRadioButton[length];
            ExArrayType = ExControlType.ExRadioButton;
            ActOnArray(x => ExRadioButtonArray[x] = new ExRadioButton());
            ConnectParent();
        }

        public void CreateExCheckBoxArray(int length)
        {
            DisposeArray();
            ExCheckBoxArray = new ExCheckBox[length];
            ExArrayType = ExControlType.ExCheckBox;
            ActOnArray(x => ExCheckBoxArray[x] = new ExCheckBox());
            ConnectParent();
        }


        // ======== プライベート、プロテクト ========

        protected void ConnectParent() => ActOnArray(x => Item[x].Parent = Body);

        protected void DisposeArray()
        {
            if (ExArrayType == ExControlType.ExRadioButton) ActOnArray(x => ExRadioButtonArray[x].Dispose());
            if (ExArrayType == ExControlType.ExCheckBox) ActOnArray(x => ExCheckBoxArray[x].Dispose());
            ExRadioButtonArray = null;
            ExCheckBoxArray = null;
            ExArrayType = ExControlType.Null;
        }

        protected void ActOnArray(Action<int> action)
        {
            if (Length < 0) return;
            for (var i = 0; i < Length; i++) action(i);
        }
    }

    public class ExGroupBoxSp : ExGroupBoxPanel
    {
        private GroupBox _body = new GroupBox();
        public ExGroupBoxSp() => Body = _body;
    }

    public class ExPanelSp : ExGroupBoxPanel
    {
        private Panel _body = new Panel();
        public ExPanelSp() => Body = _body;
    }
}
