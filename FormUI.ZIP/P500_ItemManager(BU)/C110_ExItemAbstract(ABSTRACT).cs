﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;


namespace FormUI
{
    public abstract class ExItemAbstract //: IExItem
    {
        // コントロール本体
        public ExControl Body { get; protected set; }

        // ペアレント
        protected Control _parent=null;
        public virtual Control Parent
        {
            get => _parent;
            set
            {
                _parent = value;
                ReflectParent();
            }
        }
        public abstract void ReflectParent();

        // 位置
        protected int _xUpper=0, _yUpper=0;
        protected int _xSelf = 0, _ySelf = 0;
        public virtual (int X, int Y) LocationUpper
        {
            get => (_xUpper, _yUpper);
            set
            {
                _xUpper = value.X;
                _yUpper = value.Y;
                ReflectLocation();
            }
        }
        public virtual int XUpper
        {
            get => _xUpper;
            set
            {
                _xUpper = value;
                ReflectLocation();
            }
        }
        public virtual int YUpper
        {
            get => _yUpper;
            set
            {
                _yUpper = value;
                ReflectLocation();
            }
        }
        public virtual (int X, int Y) LocationSelf
        {
            get => (_xSelf, _ySelf);
            set
            {
                _xSelf = value.X;
                _ySelf = value.Y;
                ReflectLocation();
            }
        }
        public virtual int XSelf
        {
            get => _xSelf;
            set
            {
                _xSelf = value;
                ReflectLocation();
            }
        }
        public virtual int YSelf
        {
            get => _ySelf;
            set
            {
                _ySelf = value;
                ReflectLocation();
            }
        }
        public virtual (int X, int Y) Location => (X, Y);
        public virtual int X => _xUpper + _xSelf;
        public virtual int Y => _yUpper + _ySelf;
        public abstract void ReflectLocation();

        // サイズ
        public abstract (int Width, int Height) Size { get; set; }
        public abstract int Width { get; set; }
        public abstract int Height { get; set; }
        public abstract void ReflectSize();

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => (Top, Left, Bottom, Right);
        public int Top => Y;
        public int Left => X;
        public int Bottom => Y + Height;
        public int Right => X + Width;

        // 有効・無効
        protected bool _enabledUpper = true;
        protected bool _enabledSelf = true;
        public virtual bool EnabledUpper
        {
            get => _enabledUpper;
            set
            {
                _enabledUpper = value;
                ReflectEnabled();
            }
        }
        public virtual bool EnabledSelf
        {
            get => _enabledSelf;
            set
            {
                _enabledSelf = value;
                ReflectEnabled();
            }
        }
        public virtual bool Enabled => _enabledUpper && _enabledSelf;
        public abstract void ReflectEnabled();

        // 表示・非表示
        protected bool _visibleUpper = true;
        protected bool _visibleSelf = true;
        public virtual bool VisibleUpper
        {
            get => _visibleUpper;
            set
            {
                _visibleUpper = value;
                ReflectVisible();
            }
        }
        public virtual bool VisibleSelf
        {
            get => _visibleSelf;
            set
            {
                _visibleSelf = value;
                ReflectVisible();
            }
        }
        public virtual bool Visible => _visibleUpper && _visibleSelf;
        public abstract void ReflectVisible();

        // 名前
        protected string _name="";
        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                ReflectName();
            }
        }
        public abstract void ReflectName();

        // タブインデックス
        protected int _tabIndex=0;
        public int TabIndex
        {
            get => _tabIndex;
            set
            {
                _tabIndex = value;
                ReflectTabIndex();
            }
        }
        public abstract void ReflectTabIndex();

        // テキスト
        public string Text
        {
            get => Body.Text;
            set => Body.Text = value;
        }

        // フォント
        public Font Font
        {
            get => Body.Font;
            set => Body.Font = value;
        }

        // 前景色・背景色
        public Color ForeColor
        {
            get => Body.ForeColor;
            set => Body.ForeColor = value;
        }
        public Color BackColor
        {
            get => Body.BackColor;
            set => Body.BackColor = value;
        }

        protected EventHandler _eh=null;
        public EventHandler Click
        {
            get => _eh;
            set
            {
                if (_eh != null) Body.Click -= _eh;
                _eh = value;
                Body.Click += _eh;
            }
        }
    }
}
