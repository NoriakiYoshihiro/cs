﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public class ExItem : ExItemAbstract
    {
        protected ExLabel ExLabel { get; set; }
        protected ExTextBox ExTextBox { get; set; }
        protected ExButton ExButton { get; set; }
        protected ExRadioButton ExRadioButton { get; set; }
        protected ExCheckBox ExCheckBox { get; set; }
        protected ExGroupBox ExGroupBox { get; set; }
        protected ExPanel ExPanel { get; set; }
        protected ExGroupBoxSp ExGroupBoxSp { get; set; }
        protected ExPanelSp ExPanelSp { get; set; }

        public ExControlType ExControlType { get; protected set; } = ExControlType.Null;

        public void CreateBody(ExControlType type)
        {
            switch (type)
            {
                case ExControlType.ExLabel: SetBody(new ExLabel()); break;
                case ExControlType.ExTextBox: SetBody(new ExTextBox()); break;
                case ExControlType.ExButton: SetBody(new ExButton()); break;
                case ExControlType.ExRadioButton: SetBody(new ExRadioButton()); break;
                case ExControlType.ExCheckBox: SetBody(new ExCheckBox()); break;
                case ExControlType.ExGroupBox: SetBody(new ExGroupBox()); break;
                case ExControlType.ExPanel: SetBody(new ExPanel()); break;
                case ExControlType.ExGroupBoxSp: SetBody(new ExGroupBoxSp()); break;
                case ExControlType.ExPanelSp: SetBody(new ExPanelSp()); break;
            }
        }

        public void ImportBody(ExLabel exLabel) => SetBody(exLabel);
        public void ImportBody(ExTextBox exTextBox) => SetBody(exTextBox);
        public void ImportBody(ExButton exButton) => SetBody(exButton);
        public void ImportBody(ExRadioButton exRadioButton) => SetBody(exRadioButton);
        public void ImportBody(ExCheckBox exCheckBox) => SetBody(exCheckBox);
        public void ImportBody(ExGroupBox exGroupBox) => SetBody(exGroupBox);
        public void ImportBody(ExPanel exPanel) => SetBody(exPanel);
        public void ImportBody(ExGroupBoxSp exGroupBoxSp) => SetBody(exGroupBoxSp);
        public void ImportBody(ExPanelSp exPanelSp) => SetBody(exPanelSp);
        public void ImportBody(ExControl exControl) => SetBody(exControl);

        protected void SetBody(ExLabel exLabel)
        {
            DisposeBody();
            ExLabel = exLabel;
            Body = ExLabel;
            ExControlType = ExControlType.ExLabel;
        }
        protected void SetBody(ExTextBox exTextBox)
        {
            DisposeBody();
            ExTextBox = exTextBox;
            Body = ExTextBox;
            ExControlType = ExControlType.ExTextBox;
        }
        protected void SetBody(ExButton exButton)
        {
            DisposeBody();
            ExButton = exButton;
            Body = ExButton;
            ExControlType = ExControlType.ExButton;
        }
        protected void SetBody(ExRadioButton exRadioButton)
        {
            DisposeBody();
            ExRadioButton = exRadioButton;
            Body = ExRadioButton;
            ExControlType = ExControlType.ExRadioButton;
        }
        protected void SetBody(ExCheckBox exCheckBox)
        {
            DisposeBody();
            ExCheckBox = exCheckBox;
            Body = ExCheckBox;
            ExControlType = ExControlType.ExCheckBox;
        }
        protected void SetBody(ExGroupBox exGroupBox)
        {
            DisposeBody();
            ExGroupBox = exGroupBox;
            Body = ExGroupBox;
            ExControlType = ExControlType.ExGroupBox;
        }
        protected void SetBody(ExPanel exPanel)
        {
            DisposeBody();
            ExPanel = exPanel;
            Body = ExPanel;
            ExControlType = ExControlType.ExPanel;
        }
        protected void SetBody(ExGroupBoxSp exGroupBoxSp)
        {
            DisposeBody();
            ExGroupBoxSp = exGroupBoxSp;
            Body = ExGroupBoxSp;
            ExControlType = ExControlType.ExGroupBoxSp;
        }
        protected void SetBody(ExPanelSp exPanelSp)
        {
            DisposeBody();
            ExPanelSp = exPanelSp;
            Body = ExGroupBoxSp;
            ExControlType = ExControlType.ExPanelSp;
        }
        protected void SetBody(ExControl exControl)
        {
            DisposeBody();
            Body = exControl;
            ExControlType = ExControlType.ExAbstract;
        }


        protected void DisposeBody()
        {
            ExLabel?.Dispose();
            ExTextBox?.Dispose();
            ExButton?.Dispose();
            ExRadioButton?.Dispose();
            ExCheckBox?.Dispose();
            ExGroupBox?.Dispose();
            ExPanel?.Dispose();
            ExGroupBoxSp?.Dispose();
            ExPanelSp?.Dispose();
            Body?.Dispose();
            ExControlType = ExControlType.Null;
        }

        public override void ReflectParent() => Body.Parent = Parent;

        public override void ReflectLocation() => Body.Location = Location;

        public override (int Width, int Height) Size
        {
            get => Body.Size;
            set => Body.Size = value;
        }
        public override int Width
        {
            get => Body.Width;
            set => Body.Width = value;
        }
        public override int Height
        {
            get => Body.Height;
            set => Body.Height = value;
        }
        public override void ReflectSize() { }

        public override void ReflectEnabled() => Body.Enabled = Enabled;

        public override void ReflectVisible() => Body.Visible = Visible;

        public override void ReflectName() => Body.Name = Name;

        public override void ReflectTabIndex() => Body.TabIndex = TabIndex;
    }
}
