﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public abstract class ExItemArrayAbstract
    {
        // ペアレント
        public Control Parent
        {
            set => ActOnArray(x => x.Parent = value);
        }

        // 位置
        public (int X, int Y) Location => (X, Y);
        public int X => Left;
        public int Y => Top;

        // サイズ
        public virtual (int Width, int Height) Size { set => ActOnArray(x => x.Size = value); }
        public virtual int Width { set => ActOnArray(x => x.Width = value); }
        public virtual int Height { set => ActOnArray(x => x.Height = value); }

        // エリア
        public (int Top, int Left, int Bottom, int Right, int Width, int Height) Area => (Top, Left, Bottom, Right, AreaWidth, AreaHeight);
        public int Top => SearchAreaCorner(x => x.Top, 1);
        public int Left => SearchAreaCorner(x => x.Left, 1);
        public int Bottom => SearchAreaCorner(x => x.Bottom, -1);
        public int Right => SearchAreaCorner(x => x.Right, -1);
        public int AreaWidth => Right - Left;
        public int AreaHeight => Bottom - Top;
        protected abstract int SearchAreaCorner(Func<ExItem, int> func, int sign);

        // 有効・無効
        public bool EnabledUpper
        {
            set => ActOnArray(x => x.EnabledUpper = value);
        }
        public bool EnabledSelf
        {
            set => ActOnArray(x => x.EnabledSelf = value);
        }

        // 表示・非表示
        public bool VisibleUpper
        {
            set => ActOnArray(x => x.VisibleUpper = value);
        }
        public bool VisibleSelf
        {
            set => ActOnArray(x => x.VisibleSelf = value);
        }

        // フォント
        public Font Font
        {
            set => ActOnArray(x => x.Font = value);
        }

        // 前景色・背景色
        public Color ForeColor
        {
            set => ActOnArray(x => x.ForeColor = value);
        }
        public Color BackColor
        {
            set => ActOnArray(x => x.BackColor = value);
        }

        protected abstract void ActOnArray(Action<ExItem> action);

    }
}
