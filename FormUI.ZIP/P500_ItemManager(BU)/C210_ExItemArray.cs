﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Drawing;


namespace FormUI
{
    public class ExItemArray : ExItemArrayAbstract
    {
        public ExItem[][] Array { get; protected set; }
        public ExItemCol[] ColArray { get; protected set; }

        public void CreateArray(int row, int col)
        {
            Array = new ExItem[row][];
            for (var i = 0; i < row; i++) Array[i] = new ExItem[col];

            //ActOnArray(x => x = new ExItem());
            for (var i = 0; i < row; i++)
                for (var j = 0; j < col; j++) Array[i][j] = new ExItem();


            ColArray = new ExItemCol[col];
            for (var i = 0; i < col; i++)
            {
                ColArray[i] = new ExItemCol();
                ColArray[i].ImportArray(Array, i);
            }
        }



        // エリア
        protected override int SearchAreaCorner(Func<ExItem, int> func, int sign)
        {
            var cur = func(Array[0][0]);
            foreach (var rowOfArray in Array)
                foreach (var element in rowOfArray) if (sign * func(element) < sign * cur) cur = func(element);
            return cur;
        }

        protected override void ActOnArray(Action<ExItem> action)
        {
            foreach (var rowOfArray in Array)
                foreach (var element in rowOfArray) action(element);
        }
    }


    public class ExItemCol : ExItemArrayAbstract
    {
        public ExItem[] Array { get; protected set; }

        public void ImportArray(ExItem[][] array, int col)
        {
            var length = array.Length;
            Array = new ExItem[length];
            for (var i = 0; i < length; i++) Array[i] = array[i][col];
        }

        public void CreateItem(ExControlType type) => ActOnArray(x => x.CreateBody(type));

        public int Length => Array.Length;

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => (Top, Left, Bottom, Right);
        protected override int SearchAreaCorner(Func<ExItem, int> func, int sign)
        {
            var cur = func(Array[0]);
            foreach (var element in Array) if (sign * func(element) < sign * cur) cur = func(element);
            return cur;
        }


        protected override void ActOnArray(Action<ExItem> action)
        {
            foreach (var element in Array) action(element);
        }
    }
}
