﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Test();
        }

        public ExLabel exLabel = new ExLabel();
        public ExTextBox exTextBox = new ExTextBox();
        public ExButton exButton = new ExButton();
        public ExGroupBoxSp exGroupBoxSp = new ExGroupBoxSp();
        public ExItem[] exItem = new ExItem[5];

        public void Test()
        {
            if (false)
            {
                for (var i = 0; i < exItem.Length; i++) exItem[i] = new ExItem();

                ExItem ei;
                ExControl ec;

                ei = exItem[0];
                ei.CreateBody(ExControlType.ExLabel);
                ei.Parent = this;
                ei.LocationSelf = (10, 0);
                ei.Size = (100, 20);
                ei.Text = "ABC";


                ei = exItem[1];
                ec = exTextBox;
                ei.ImportBody(ec);
                ei.Parent = this;
                ei.LocationSelf = (10, 50);
                ei.Size = (100, 20);
                ec.Text = "DEF";



                ec = exButton;
                ec.Parent = this;
                ec.Location = (10, 100);
                ec.Size = (100, 20);
                ec.Text = "GHI";

                ei = exItem[2];
                ei.ImportBody(exGroupBoxSp);
                ei.Parent = this;
                ei.LocationSelf = (10, 150);
                ei.Size = (100, 150);
                ei.Text = "JKL";
                exGroupBoxSp.CreateExRadioButtonArray(3);
                ExControl[] array = exGroupBoxSp.Item;

                array[0].Location = (10, 10);
                array[0].Text = "Item 1";
                array[1].Location = (10, 30);
                array[1].Text = "Item 2";
                array[2].Location = (10, 50);
                array[2].Text = "Item 3";

                ExRadioButton[] array2 = new ExRadioButton[2];
                array2[0] = new ExRadioButton();
                array2[1] = new ExRadioButton();
                array2[0].Location = (10, 70);
                array2[0].Text = "Item A";
                array2[1].Location = (10, 90);
                array2[1].Text = "Item A";
                //exGroupBoxSp.ImportArray(array2);
            }

            ExItemArray x = new ExItemArray();
            x.CreateArray(5, 2);
            x.ColArray[0].CreateItem(ExControlType.ExLabel);
            x.ColArray[1].CreateItem(ExControlType.ExTextBox);
            x.ColArray[0].Parent = this;
            x.ColArray[1].Parent = this;
            x.ColArray[0].Size = (80, 20);
            x.ColArray[1].Size = (80, 20);
            //x.ColArray[0].VisibleUpper = true;
            //x.ColArray[0].VisibleSelf = true;
            for (var i=0; i<5; i++)
            {
                x.Array[i][0].Text = "Label-" + i.ToString();
                x.Array[i][1].Text ="TextBox - "+i.ToString();
                x.Array[i][0].LocationSelf=(10, i * 20 + 10);
                x.Array[i][1].LocationSelf = (110, i * 20 + 10);
            }

            var e = exTextBox;
            e.Parent = this;
            e.Location = (10, 160);
            e.Size = (100, 20);
            e.Text = "DEF";

        }


    }

}
