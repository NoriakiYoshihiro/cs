﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public enum ExItemType { Null = 0, ExLabel = 1, ExTextBox = 2, ExButton = 3, ExRadioButton = 4, ExCheckBox = 5, ExGroupBox = 6, ExPanel = 7, ExBody = 99 }

    interface IExItem
    {
        // ペアレント
        Control Parent { get; set; }

        // 位置
        (int X, int Y) Location { get; set; }
        int X { get; set; }
        int Y { get; set; }


        // サイズ
        (int Width, int Height) Size { get; set; }
        int Width { get; set; }
        int Height { get; set; }

        // エリア
        (int Top, int Left, int Bottom, int Right) Area { get; }
        int Top { get; }
        int Left { get; }
        int Bottom { get; }
        int Right { get; }

        // 有効・無効
        bool Enabled { get; set; }

        // 表示・非表示
        bool Visible { get; set; }

        // 名前
        string Name { get; set; }

        // タブインデックス
        int TabIndex { get; set; }

        // フォント
        (string Family, float Size) Font { get; set; }

        // フォントファミリー
        string FontFamily { get; set; }

        // フォントサイズ
        float FontSize { get; set; }

        // フォントスタイル
        FontStyle FontStyle { get; set; }

        bool Bold { get; set; }
        bool Italic { get; set; }
        bool Underline { get; set; }
        bool Strikeout { get; set; }

        // 前景色・背景色
        Color ForeColor { get; set; }
        Color BackColor { get; set; }

        // テキスト
        string Text { get; set; }

        // クリック
        Action Click { get; set; }
    }
}
