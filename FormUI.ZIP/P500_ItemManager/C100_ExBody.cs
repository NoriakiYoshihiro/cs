﻿using System;
using System.Windows.Forms;
using System.Drawing;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.ComponentModel.Design;

namespace FormUI
{
    public partial class ExBody : IExItem
    {
        // ======== コンストラクタ ========

        public ExBody() => Create();


        // ======== 実体の確定 ========

        public Control Body { get; protected set; }

        // 実体の生成
        public virtual void Create() { }

        // 実体の取込
        public void Import(Control body) => Set(body);

        // 実体の廃棄
        public void Dispose() => Body?.Dispose();


        // 実体処理
        protected void Set(Control body)
        {
            Dispose();
            Body = body;
        }


        // ======== 実体の制御 ========

        // ペアレント
        public Control Parent
        {
            get => Body.Parent;
            set => Body.Parent = value;
        }

        // 位置
        public (int X, int Y) Location
        {
            get => (X, Y);
            set => Body.Location = new Point(value.X, value.Y);
        }
        public int X
        {
            get => Body.Location.X;
            set => Body.Location = new Point(value, Y);
        }
        public int Y
        {
            get => Body.Location.Y;
            set => Body.Location = new Point(X, value);
        }

        // サイズ
        public (int Width, int Height) Size
        {
            get => (Width, Height);
            set => Body.Size = new Size(value.Width, value.Height);
        }
        public int Width
        {
            get => Body.Width;
            set => Body.Width = value;
        }
        public int Height
        {
            get => Body.Height;
            set => Body.Height = value;
        }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => (Top, Left, Bottom, Right);
        public int Top => Y;
        public int Left => X;
        public int Bottom => Y + Height;
        public int Right => X + Width;

        // 有効・無効
        public bool Enabled
        {
            get => Body.Enabled;
            set => Body.Enabled = value;
        }

        // 表示・非表示
        public bool Visible
        {
            get => Body.Visible;
            set => Body.Visible = value;
        }

        // 名前
        public string Name
        {
            get => Body.Name;
            set => Body.Name = value;
        }

        // タブインデックス
        public int TabIndex
        {
            get => Body.TabIndex;
            set => Body.TabIndex = value;
        }


        // フォント
        public (string Family, float Size) Font
        {
            get => (FontFamily, FontSize);
            set => Body.Font = new Font(value.Family, value.Size);
        }
        // フォントファミリー
        public string FontFamily
        {
            get => Body.Font.FontFamily.Name;
            set => Body.Font = new Font(value, FontSize);
        }
        // フォントサイズ
        public float FontSize
        {
            get => Body.Font.Size;
            set => Body.Font = new Font(FontFamily, value);
        }
        // フォントスタイル
        public FontStyle FontStyle
        {
            get => Body.Font.Style;
            set => Body.Font = new Font(Body.Font, value);
        }

        public bool Bold
        {
            get => OperandGet(FontStyle.Bold);
            set => OperandSet(FontStyle.Bold, value);
        }
        public bool Italic
        {
            get => OperandGet(FontStyle.Italic);
            set => OperandSet(FontStyle.Italic, value);
        }
        public bool Underline
        {
            get => OperandGet(FontStyle.Underline);
            set => OperandSet(FontStyle.Underline, value);
        }
        public bool Strikeout
        {
            get => OperandGet(FontStyle.Strikeout);
            set => OperandSet(FontStyle.Strikeout, value);
        }

        protected FontStyle FontStyleFullBit = (FontStyle.Bold | FontStyle.Italic | FontStyle.Underline | FontStyle.Strikeout);
        protected bool OperandGet(FontStyle style) => (FontStyle & style) != FontStyle.Regular;
        protected void OperandSet(FontStyle style, bool b)
        {
            if (b)
            {
                FontStyle |= style;
            }
            else
            {
                var fontStyle = FontStyle.Regular;
                if (OperandGet(FontStyle.Bold) && style != FontStyle.Bold) fontStyle |= FontStyle.Bold;
                if (OperandGet(FontStyle.Italic) && style != FontStyle.Italic) fontStyle |= FontStyle.Italic;
                if (OperandGet(FontStyle.Underline) && style != FontStyle.Underline) fontStyle |= FontStyle.Underline;
                if (OperandGet(FontStyle.Strikeout) && style != FontStyle.Strikeout) fontStyle |= FontStyle.Strikeout;
                
                FontStyle=fontStyle;
            }
        }


        // 前景色・背景色
        public Color ForeColor
        {
            get => Body.ForeColor;
            set => Body.ForeColor = value;
        }
        public Color BackColor
        {

            get => Body.BackColor;
            set => Body.BackColor = value;
        }

        // テキスト
        public string Text
        {
            get => Body.Text;
            set => Body.Text = value;
        }

        // イベント
        protected Action _clickAction;
        public Action Click
        {
            get => _clickAction;
            set
            {
                if (_clickAction != null) Body.Click -= (s,e)=>_clickAction();
                _clickAction = value;
                Body.Click += (s,e) => _clickAction();
            }
        }

 

    }


    public class FontStyleManagerClass
    {
        public FontStyleManagerClass(Control body) => Import(body);

        protected Control Body { get; set; }

        public void Import(Control body)
        {
            Body = body;
            Initialize();
        }

        protected void Initialize() => Style = (false, false, false, false);

        protected bool _bold = false, _italic = false, _underline = false, _strikeout = false;

        public (bool Bold, bool Italic, bool Underline, bool Strikeout) Style
        {
            get => (Bold, Italic, Underline, Strikeout);
            set
            {
                _bold = value.Bold;
                _italic = value.Italic;
                _underline = value.Underline;
                _strikeout = value.Strikeout;
                Refresh();
            }
        }

        public bool Bold
        {
            get => _bold;
            set
            {
                _bold = value;
                Refresh();
            }
        }

        public bool Italic
        {
            get => _italic;
            set
            {
                _italic = value;
                Refresh();
            }
        }

        public bool Underline
        {
            get => _underline;
            set
            {
                _underline = value;
                Refresh();
            }
        }

        public bool Strikeout
        {
            get => _strikeout;
            set
            {
                _strikeout = value;
                Refresh();
            }
        }

        public FontStyle Value
        {
            get
            {
                var f = FontStyle.Regular;
                if (Bold) f |= FontStyle.Bold;
                if (Italic) f |= FontStyle.Italic;
                if (Underline) f |= FontStyle.Underline;
                if (Strikeout) f |= FontStyle.Strikeout;
                return f;
            }
        }

        protected void Refresh() => Body.Font = new Font(Body.Font, Value);
    }

}
