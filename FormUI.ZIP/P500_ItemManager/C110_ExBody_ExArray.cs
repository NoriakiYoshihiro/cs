﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class ExBody
    {
        public ExRadioButton[] ExRadioButtonArray { get; protected set; }
        public ExCheckBox[] ExCheckBoxArray { get; protected set; }
        public ExBody[] Array { get; protected set; }

        public ExItemType ExArrayType { get; protected set; } = ExItemType.Null;

        public int Length
        {
            get
            {
                if (ExArrayType == ExItemType.ExRadioButton) return ExRadioButtonArray.Length;
                if (ExArrayType == ExItemType.ExCheckBox) return ExCheckBoxArray.Length;
                if (ExArrayType == ExItemType.ExBody) return Array.Length;
                return -1;
            }
        }

        // ExRadioButtonArray
        public void CreateExRadioButtonArray(int length)
        {
            DefineExRadioButtonArray(() =>
            {
                ExRadioButtonArray = new ExRadioButton[length];
                ActForLength(x => ExRadioButtonArray[x] = new ExRadioButton());
            });
        }

        public void ImportExRadioButtonArray(ExRadioButton[] array)
        {
            DefineExRadioButtonArray(() => ExRadioButtonArray = array);
        }

        protected void DefineExRadioButtonArray(Action action)
        {
            DisposeExArray();
            ExArrayType = ExItemType.ExRadioButton;
            action();
            Array = ExRadioButtonArray;
            ConnectParent();
        }


        // ExCheckBoxArray
        public void CreateExCheckBoxArray(int length)
        {
            DefineExCheckBoxArray(() =>
            {
                ExCheckBoxArray = new ExCheckBox[length];
                ActForLength(x => ExCheckBoxArray[x] = new ExCheckBox());
            });
        }

        public void ImportExCheckBoxArray(ExCheckBox[] array)
        {
            DefineExCheckBoxArray(() => ExCheckBoxArray = array);
        }

        protected void DefineExCheckBoxArray(Action action)
        {
            DisposeExArray();
            ExArrayType = ExItemType.ExCheckBox;
            action();
            Array = ExCheckBoxArray;
            ConnectParent();
        }


        // 廃棄
        public void DisposeExArray()
        {
            if (ExArrayType == ExItemType.Null) return;
            for (var i = 0; i < Length; i++)
            {
                ExRadioButtonArray[i]?.Dispose();
                ExCheckBoxArray[i]?.Dispose();
                Array[i]?.Dispose();
            }
            ExRadioButtonArray = null;
            ExCheckBoxArray = null;
            Array = null;
            ExArrayType= ExItemType.Null;
        }


        protected void ConnectParent()
        {
            ActForLength(x => Array[x].Parent = Body);
        }

        protected void ActForLength(Action<int> action)
        {
            for (var i = 0; i < Length; i++) action(i);
        }
    }
}
