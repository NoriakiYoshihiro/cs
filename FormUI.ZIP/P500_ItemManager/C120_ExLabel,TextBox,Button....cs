﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{

    public class ExLabel : ExBody
    {
        // ボディ
        public Label Label { get; protected set; }

        // 実体の生成
        public override void Create() => Set(new Label());

        // 実体の取込
        public void Import(Label label) => Set(label);

        // 実体処理
        protected void Set(Label label)
        {
            Dispose();
            Label = label;
            Body = Label;
        }
    }

    public class ExTextBox : ExBody
    {
        // ボディ
        public TextBox TextBox { get; protected set; }

        // 実体の生成
        public override void Create() => Set(new TextBox());

        // 実体の取込
        public void Import(TextBox textBox) => Set(textBox);

        // 実体処理
        protected void Set(TextBox textBox)
        {
            Dispose();
            TextBox = textBox;
            Body = TextBox;
        }
    }

    public class ExButton : ExBody
    {
        // ボディ
        public Button Button { get; protected set; }

        // 実体の生成
        public override void Create() => Set(new Button());

        // 実体の取込
        public void Import(Button button) => Set(button);

        // 実体処理
        protected void Set(Button button)
        {
            Dispose();
            Button = button;
            Body = Button;
        }
    }

    public class ExRadioButton : ExBody
    {
        // ボディ
        public RadioButton RadioButton { get; protected set; }

        // 実体の生成
        public override void Create() => Set(new RadioButton());

        // 実体の取込
        public void Import(RadioButton radioButton) => Set(radioButton);

        // 実体処理
        protected void Set(RadioButton radioButton)
        {
            Dispose();
            RadioButton = radioButton;
            Body = RadioButton;
        }
    }

    public class ExCheckBox : ExBody
    {
        // ボディ
        public CheckBox CheckBox { get; protected set; }

        // 実体の生成
        public override void Create() => Set(new CheckBox());

        // 実体の取込
        public void Import(CheckBox checkBox) => Set(checkBox);

        // 実体処理
        protected void Set(CheckBox checkBox)
        {
            Dispose();
            CheckBox = checkBox;
            Body = CheckBox;
        }
    }

    public class ExGroupBox : ExBody
    {
        // ボディ
        public GroupBox GroupBox { get; protected set; }

        // 実体の生成
        public override void Create() => Set(new GroupBox());

        // 実体の取込
        public void Import(GroupBox groupBox) => Set(groupBox);

        // 実体処理
        protected void Set(GroupBox groupBox)
        {
            Dispose();
            GroupBox = groupBox;
            Body = GroupBox;
        }
    }

    public class ExPanel : ExBody
    {
        // ボディ
        public Panel Panel { get; protected set; }

        // 実体の生成
        public override void Create() => Set(new Panel());

        // 実体の取込
        public void Import(Panel panel) => Set(panel);

        // 実体処理
        protected void Set(Panel panel)
        {
            Dispose();
            Panel = panel;
            Body = Panel;
        }
    }
}
