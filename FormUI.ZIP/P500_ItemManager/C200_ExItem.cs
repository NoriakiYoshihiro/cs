﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace FormUI
{
    public partial class ExItem : IExItem
    {
        public ExLabel ExLabel { get; protected set; }
        public ExTextBox ExTextBox { get; protected set; }
        public ExButton ExButton { get; protected set; }
        public ExRadioButton ExRadioButton { get; protected set; }
        public ExCheckBox ExCheckBox { get; protected set; }
        public ExGroupBox ExGroupBox { get; protected set; }
        public ExPanel ExPanel { get; protected set; }
        public ExBody ExBody { get; protected set; }

        public ExItemType Type { get; protected set; }

        // 実体の生成
        public void Create(ExItemType type)
        {
            switch (type)
            {
                case ExItemType.ExLabel: Set(new ExLabel()); break;
                case ExItemType.ExTextBox: Set(new ExTextBox()); break;
                case ExItemType.ExButton: Set(new ExButton()); break;
                case ExItemType.ExRadioButton: Set(new ExRadioButton()); break;
                case ExItemType.ExCheckBox: Set(new ExCheckBox()); break;
                case ExItemType.ExGroupBox: Set(new ExGroupBox()); break;
                case ExItemType.ExPanel: Set(new ExPanel()); break;
            }
        }

        // 実体の取込
        public void Import(ExLabel exLabel) => Set(exLabel);
        public void Import(ExTextBox exTextBox) => Set(exTextBox);
        public void Import(ExButton exButton) => Set(exButton);
        public void Import(ExRadioButton exRadioButton) => Set(exRadioButton);
        public void Import(ExCheckBox exCheckBox) => Set(exCheckBox);
        public void Import(ExGroupBox exGroupBox) => Set(exGroupBox);
        public void Import(ExPanel exPanel) => Set(exPanel);
        public void Import(ExBody exBody) => Set(exBody);

        // 実体の廃棄
        public void Dispose()
        {
            ExBody?.Dispose();
            Type = ExItemType.Null;
        }

        // 実体処理
        protected void Set(ExLabel exLabel)
        {
            Dispose();
            ExLabel = exLabel;
            ExBody = ExLabel;
            Type = ExItemType.ExLabel;
        }
        protected void Set(ExTextBox exTextBox)
        {
            Dispose();
            ExTextBox = exTextBox;
            ExBody = ExTextBox;
            Type = ExItemType.ExTextBox;
        }
        protected void Set(ExButton exButton)
        {
            Dispose();
            ExButton = exButton;
            ExBody = ExButton;
            Type = ExItemType.ExButton;
        }
        protected void Set(ExRadioButton exRadioButton)
        {
            Dispose();
            ExRadioButton = exRadioButton;
            ExBody = ExRadioButton;
            Type = ExItemType.ExRadioButton;
        }
        protected void Set(ExCheckBox exCheckBox)
        {
            Dispose();
            ExCheckBox = exCheckBox;
            ExBody = ExCheckBox;
            Type = ExItemType.ExCheckBox;
        }
        protected void Set(ExGroupBox exGroupBox)
        {
            Dispose();
            ExGroupBox = exGroupBox;
            ExBody = ExGroupBox;
            Type = ExItemType.ExGroupBox;
        }
        protected void Set(ExPanel exPanel)
        {
            Dispose();
            ExPanel = exPanel;
            ExBody = ExPanel;
            Type = ExItemType.ExPanel;
        }
        protected void Set(ExBody exBody)
        {
            Dispose();
            ExBody = exBody;
            Type = ExItemType.ExBody;
        }


        // ペアレント
        public Control Parent
        {
            get => ExBody.Parent;
            set => ExBody.Parent = value;
        }

        // 位置
        public (int X, int Y) Location
        {
            get => ExBody.Location;
            set => ExBody.Location = value;
        }
        public int X
        {
            get => ExBody.X;
            set => ExBody.X = value;
        }
        public int Y
        {
            get => ExBody.Y;
            set => ExBody.Y = value;
        }


        // サイズ
        public (int Width, int Height) Size
        {
            get => ExBody.Size;
            set => ExBody.Size = value;
        }
        public int Width
        {
            get => ExBody.Width;
            set => ExBody.Width = value;
        }
        public int Height
        {
            get => ExBody.Height;
            set => ExBody.Height = value;
        }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => ExBody.Area;
        public int Top => ExBody.Top;
        public int Left => ExBody.Left;
        public int Bottom => ExBody.Bottom;
        public int Right => ExBody.Right;

        // 有効・無効
        public bool Enabled
        {
            get => ExBody.Enabled;
            set => ExBody.Enabled = value;
        }

        // 表示・非表示
        public bool Visible
        {
            get => ExBody.Visible;
            set => ExBody.Visible = value;
        }

        // 名前
        public string Name
        {
            get => ExBody.Name;
            set => ExBody.Name = value;
        }

        // タブインデックス
        public int TabIndex
        {
            get => ExBody.TabIndex;
            set => ExBody.TabIndex = value;
        }

        // フォント
        public (string Family, float Size) Font
        {
            get => ExBody.Font;
            set => ExBody.Font = value;
        }

        // フォントファミリー
        public string FontFamily
        {
            get => ExBody.FontFamily;
            set => ExBody.FontFamily = value;
        }

        // フォントサイズ
        public float FontSize
        {
            get => ExBody.FontSize;
            set => ExBody.FontSize = value;
        }

        // フォントスタイル
        public FontStyle FontStyle
        {
            get => ExBody.FontStyle;
            set => ExBody.FontStyle = value;
        }

        public bool Bold
        {
            get => ExBody.Bold;
            set => ExBody.Bold = value;
        }
        public bool Italic
        {
            get => ExBody.Italic;
            set => ExBody.Italic = value;
        }
        public bool Underline
        {
            get => ExBody.Underline;
            set => ExBody.Underline = value;
        }
        public bool Strikeout
        {
            get => ExBody.Strikeout;
            set => ExBody.Strikeout = value;
        }

        // 前景色・背景色
        public Color ForeColor
        {
            get => ExBody.ForeColor;
            set => ExBody.ForeColor = value;
        }
        public Color BackColor
        {
            get => ExBody.ForeColor;
            set => ExBody.BackColor = value;
        }

        // テキスト
        public string Text
        {
            get => ExBody.Text;
            set => ExBody.Text = value;
        }

        // クリック
        public Action Click
        {
            get => ExBody.Click;
            set => ExBody.Click = value;
        }
    }
}
