﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public partial class ExItem
    {
        public ExRadioButton[] ExRadioButtonArray => ExBody.ExRadioButtonArray;
        public ExCheckBox[] ExCheckBoxArray  => ExBody.ExCheckBoxArray;
        public ExBody[] Array => ExBody.Array;

        public ExItemType ExArrayType => ExBody.ExArrayType;

        public int Length => ExBody.Length;

        // ExRadioButtonArray
        public void CreateExRadioButtonArray(int length) => ExBody.CreateExRadioButtonArray(length);

        public void ImportExRadioButtonArray(ExRadioButton[] array) => ExBody.ImportExRadioButtonArray(array);

        // ExCheckBoxArray
        public void CreateExCheckBoxArray(int length) => ExBody.CreateExCheckBoxArray(length);

        public void ImportExCheckBoxArray(ExCheckBox[] array) => ExBody.ImportExCheckBoxArray(array);

        // 廃棄
        public void DisposeExArray() => ExBody.DisposeExArray();
    }
}
