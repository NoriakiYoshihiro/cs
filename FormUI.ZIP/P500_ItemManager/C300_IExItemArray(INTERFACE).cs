﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace FormUI
{
    public interface IExItemArray
    {
        // ペアレント
        Control Parent { set; }

        // 位置
        int X { set; }
        int Y { set; }

        // サイズ
        (int Width, int Height) Size { set; }
        int Width { set ; }
        int Height { set ; }

        // エリア
        (int Top, int Left, int Bottom, int Right) Area { get; }
        int Top { get; }
        int Left { get;}
        int Bottom { get;}
        int Right { get;}

        // 有効・無効
        bool Enabled { set; }

        // 表示・非表示
        bool Visible { set; }

        // フォント
        (string FontFamily, float FontSize) Font { set; }

        // フォントファミリー
        string FontFamily { set; }

        // フォントサイズ
        float FontSize { set; }

        // フォントスタイル
        FontStyle FontStyle { set; }

        bool Bold { set; }
        bool Italic { set; }
        bool Underline { set; }
        bool Strikeout { set; }

        // 前景色・背景色
        Color ForeColor { set; }
        Color BackColor { set; }
    }
}
