﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    // 全ての配列要素に同じアクションを実施
    public class ExItemArraySingle : IExItemArray
    {
        public ExItem[] Array { get; protected set; }

        public virtual int Length => Array.Length;

        public void Import(ExItem[] array) => Array = array;

        // 創成
        public void Create(ExItemType type) => ActOnArray(x => x.Create(type));


        // ペアレント
        public Control Parent
        {
            set => ActOnArray(x => x.Parent = value);
        }

        // 位置
        public int X { set => ActOnArray(x => x.X = value); }
        public int Y { set => ActOnArray(x => x.Y = value); }

        // サイズ
        public (int Width, int Height) Size { set => ActOnArray(x => x.Size = value); }
        public int Width { set => ActOnArray(x => x.Width = value); }
        public int Height { set => ActOnArray(x => x.Height = value); }

        // エリア
        public (int Top, int Left, int Bottom, int Right) Area => (Top, Left, Bottom, Right);
        public int Top => SearchAreaCorner(x => x.Top, 1);
        public int Left => SearchAreaCorner(x => x.Left, 1);
        public int Bottom => SearchAreaCorner(x => x.Bottom, -1);
        public int Right => SearchAreaCorner(x => x.Right, -1);
        protected int SearchAreaCorner(Func<ExItem, int> func, int sign)
        {
            var cur = func(Array[0]);
            foreach (var e in Array) if (sign * func(e) < sign * cur) cur = sign * func(e);
            return cur;
        }

        // 有効・無効
        public bool Enabled { set => ActOnArray(x => x.Enabled = value); }

        // 表示・非表示
        public bool Visible { set => ActOnArray(x => x.Visible = value); }

        // フォント
        public (string FontFamily, float FontSize) Font { set => ActOnArray(x => x.Font = value); }

        // フォントファミリー
        public string FontFamily { set => ActOnArray(x => x.FontFamily = value); }

        // フォントサイズ
        public float FontSize { set => ActOnArray(x => x.FontSize = value); }

        // フォントスタイル
        public FontStyle FontStyle { set => ActOnArray(x => x.FontStyle = value); }

        public bool Bold { set => ActOnArray(x => x.Bold = value); }
        public bool Italic { set => ActOnArray(x => x.Italic = value); }
        public bool Underline { set => ActOnArray(x => x.Underline = value); }
        public bool Strikeout { set => ActOnArray(x => x.Strikeout = value); }


        // 前景色・背景色
        public Color ForeColor { set => ActOnArray(x => x.ForeColor = value); }
        public Color BackColor { set => ActOnArray(x => x.BackColor = value); }

        protected void ActOnArray(Action<ExItem> action) { foreach (var e in Array) action(e); }
    }
}
