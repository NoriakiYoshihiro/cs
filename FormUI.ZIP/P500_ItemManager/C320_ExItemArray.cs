﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Drawing;


namespace FormUI
{
    public class ExItemArray : ExItemArraySingle
    {
        public ExItem[,] Cell { get; protected set; }
        //public ExItemArraySingle All { get; protected set; } 継承したArrayをAllに利用する
        public ExItemArraySingle[] Row { get; protected set; }
        public ExItemArraySingle[] Col { get; protected set; }

        public int LengthOfRow => Cell.GetLength(0);
        public int LengthOfCol => Cell.GetLength(1);
        public override int Length => Cell.Length;


        public void DefineArraySize(int row, int col)
        {
            CreateArray(row, col);
            CreateAll();
            CreateRow();
            CreateCol();
        }

        protected void CreateArray(int row, int col)
        {
            Cell = new ExItem[row, col];
            for (var i = 0; i < LengthOfRow; i++)
                for (var j = 0; j < LengthOfCol; j++) Cell[i, j] = new ExItem();
        }

        // 2次元配列を1次元配列に変換して格納
        protected void CreateAll()
        {
            var exArray = new ExItem[Length];
            for (var i = 0; i < LengthOfRow; i++)
                for (var j = 0; j < LengthOfCol; j++)
                {
                    var index = i * LengthOfCol + j;
                    exArray[index] = new ExItem();
                    exArray[index] = Cell[i, j];
                }
            Import(exArray);
        }

        // Row
        protected void CreateRow()
        {
            Row = new ExItemArraySingle[LengthOfRow];

            for (var i = 0; i < LengthOfRow; i++)
            {
                Row[i] = new ExItemArraySingle();
                var exArray = new ExItem[LengthOfCol];

                for (var j = 0; j < LengthOfCol; j++) exArray[j] = Cell[i, j];
                Row[i].Import(exArray);
            }
        }

        // Col
        protected void CreateCol()
        {
            Col = new ExItemArraySingle[LengthOfCol];

            for (var i = 0; i < LengthOfCol; i++)
            {
                Col[i] = new ExItemArraySingle();
                var exArray = new ExItem[LengthOfRow];

                for (var j = 0; j < LengthOfRow; j++) exArray[j] = Cell[j, i];
                Col[i].Import(exArray);
            }
        }
    }
}
