﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    public class AutoLocater 
    {
        protected ExItemArraySingle[] Row;
        protected ExItemArraySingle[] Col;

        // ======== コンストラクタ ========
        public AutoLocater(ExItemArraySingle[] row, ExItemArraySingle[] col)
        {
            Row = row;
            Col = col;
        }

        // ======== プロパティ ========
        protected (int Top, int Left, int Bottom, int Right) _margin = (10, 10, 20, 20);
        public virtual (int Top, int Left, int Bottom, int Right) Margin
        {
            get => _margin;
            set
            {
                _margin = value;
                Relocate();
            }
        }
        public virtual int MarginTop
        {
            get => _margin.Top;
            set { _margin.Top = value; Relocate(); }
        }
        public virtual int MarginLeft
        {
            get => _margin.Left;
            set { _margin.Left = value; Relocate(); }
        }
        public virtual int MarginBottom
        {
            get => _margin.Bottom;
            set { _margin.Bottom = value; Relocate(); }
        }
        public int MarginRight
        {
            get => _margin.Right;
            set { _margin.Right = value; Relocate(); }
        }

        protected (int Horizontal, int Vertical) _padding = (10, 10);
        public virtual (int Horizontal, int Vertical) Padding
        {
            get => _padding;
            set
            {
                _padding = value;
                Relocate();
            }
        }
        public virtual int PaddingHorizontal
        {
            get => _padding.Horizontal;
            set { _padding.Horizontal = value; Relocate(); }
        }
        public virtual int PaddingVertical
        {
            get => _padding.Vertical;
            set { _padding.Vertical = value; Relocate(); }
        }

        protected (int Width, int Height) _size = (80, 10);
        public virtual (int Width, int Height) Size
        {
            get => _size;
            set
            {
                _size = value;
                Relocate();
            }
        }
        public virtual int Width
        {
            get => _size.Width;
            set { _size.Height = value; Relocate(); }
        }
        public virtual int Height
        {
            get => _size.Width;
            set { _size.Height = value; Relocate(); }
        }

        public abstract void Refresh();
        public void Relocate() { }
    }

    public class AutoLocaterFixedSize






}
