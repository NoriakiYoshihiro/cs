﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Test();
        }

        public ExGroupBox ExGroupBox = new ExGroupBox();

        public ExItem ExItem = new ExItem();

        public ExItemArray Array = new ExItemArray();

        public void Test()
        {
            var mode = 2;
            switch (mode)
            {
                case 0:
                    {
                        var e3 = Array;
                        e3.DefineArraySize(5, 3);
                        e3.Create(ExItemType.ExTextBox);
                        e3.Col[0].Create(ExItemType.ExLabel);
                        e3.Parent = this;
                        e3.Size = (150, 24);
                        e3.FontFamily = "MS UI Gothic";
                        e3.FontSize = 12;
                        e3.ForeColor = Color.Red;

                        for (var i = 0; i < e3.LengthOfRow; i++)
                        {

                            for (var j = 0; j < e3.LengthOfCol; j++)
                            {
                                var e = e3.Cell[i, j];
                                e.Parent = this;
                                e.Location = (10 + j * 160, 10 + i * 32);
                                e.Text = "[" + i.ToString() + "," + j.ToString() + "]=" + e.Size.ToString();
                            }
                        }

                        e3.Col[0].Bold = true;
                        e3.Row[1].Italic = true;
                        e3.Row[3].ForeColor = Color.Blue;


                        var b = new ExItemArray();

                        b.DefineArraySize(1, 6);
                        b.Create(ExItemType.ExButton);
                        b.Parent = this;
                        {
                            var size = (Width - 10) / b.LengthOfCol - 10;

                            b.Size = (size, 40);
                            for (var i = 0; i < b.LengthOfCol; i++)
                            {
                                b.Cell[0, i].Location = (10 + (size + 10) * i, Height - 80);
                            }
                        }
                        b.Cell[0, 0].Text = "Change [0,1]";
                        b.Cell[0, 0].Click = (() => e3.Cell[0, 1].Text = "Changed!");

                        b.Cell[0, 1].Text = "DisEnabled";
                        b.Cell[0, 1].Click = (() => b.Cell[0, 1].Enabled = false);

                        b.Cell[0, 2].Text = "DisVisible";
                        b.Cell[0, 2].Click = (() => e3.Col[2].Visible = false);

                        b.Cell[0, 3].Text = "Visible";
                        b.Cell[0, 3].Click = (() => e3.Col[2].Visible = true);

                        b.Cell[0, 4].Text = "DisEnabled";
                        b.Cell[0, 4].Click = (() => e3.Cell[3, 1].Enabled = false);


                        b.Cell[0, 5].Text = "Close";
                        b.Cell[0, 5].Click = (() => this.Close());
                        break;
                    }
                case 1:
                    {
                        var e = new ExGroupBox
                        {
                            Parent = this,
                            Location = (50, 50),
                            Size = (200, 100),
                            Text = "GroupBox"
                        };
                        e.CreateExCheckBoxArray(2);
                        var a = e.ExCheckBoxArray;
                        a[0].Location = (10, 10);
                        a[0].Size = (100, 20);
                        a[0].Text = "Item 0";
                        a[1].Location = (10, 30);
                        a[1].Size = (100, 20);
                        a[1].Text = "Item 1";
                        break;
                    }
                case 2:
                    {
                        var e = new ExItemArray();
                        e.DefineArraySize(1, 2);
                        e.Cell[0, 0].Create(ExItemType.ExGroupBox);
                        e.Cell[0, 0].Parent = this;
                        e.Cell[0, 0].Location = (50, 50);
                        e.Cell[0, 0].Size = (200, 100);
                        e.Cell[0, 0].Text = "GroupBox1";
                        e.Cell[0, 0].CreateExCheckBoxArray(2);
                        var a = e.Cell[0, 0].ExCheckBoxArray;
                        a[0].Location = (10, 10);
                        a[0].Size = (100, 20);
                        a[0].Text = "Item 0";
                        a[1].Location = (10, 30);
                        a[1].Size = (100, 20);
                        a[1].Text = "Item 1";

                        e.Cell[0, 1].Create(ExItemType.ExGroupBox);
                        e.Cell[0, 1].Parent = this;
                        e.Cell[0, 1].Location = (250, 50);
                        e.Cell[0, 1].Size = (200, 100);
                        e.Cell[0, 1].Text = "GroupBox2";
                        e.Cell[0, 1].CreateExCheckBoxArray(2);
                        a = e.Cell[0, 1].ExCheckBoxArray;
                        a[0].Location = (10, 10);
                        a[0].Size = (100, 20);
                        a[0].Text = "Item 0";
                        a[1].Location = (10, 30);
                        a[1].Size = (100, 20);
                        a[1].Text = "Item 1";
                        break;
                    }
            } // switch
        } // メソッド
    } // class
}
