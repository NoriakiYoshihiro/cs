﻿using Library;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace Gearmetry
{
    public partial class SummaryManager
    {

        protected TextList RawOriginal { get; set; } = new TextList();

        protected TextList[] RawSection { get; set; }

        public string RawText { get => RawOriginal.Text; protected set => RawOriginal.Text = value; }

        public SpecSection0 Sec0 { get; set; }
        public SpecSection1 Sec1 { get; set; }
        public SpecSection2 Sec2 { get; set; }
        public SpecSection3 Sec3 { get; set; }
        public SpecSection4 Sec4 { get; set; }
        public SpecSection5 Sec5 { get; set; }
        public SpecSection6 Sec6 { get; set; }
        public SpecSection7 Sec7 { get; set; }

        // ======== セクション情報配列 ========
        private (string TopKey, string LastKey, int TopAdjustor, int LastAdjustor)[] partition =
        {
            ("CALCULATION OF HELICAL GEAR" , "NOTE :" , 0, 0),
            ("1. GEAR DIMENSIONS" , "(OUTSIDE DIA.)" , 0, 0),
            ("2. ENGAGED GEAR DIMENSIONS" , "TRANSVERSE TOOTH THICKNESS" , 0, 0),
            ("3. CHARACTERISTICS OF ENGAGEMENT" , "SPECIFIC SLIDING AT ROOT" ,0, 0),
            ("4. STRENGTH OF TOOTH" , "SQUARE ROOT OF RELATIVE CURVATURE" , 0, 0),
            ("5. OTHERS" , "CALCULATION OF HELICAL GEAR" , 0, -1),
            ("1. CUTTING DATA" , "2. ROUGHING CUTTER SPECIFICATIONS" , 0, -1),
            ("2. ROUGHING CUTTER SPECIFICATIONS" , "TOOL NO." , 0, 0),
            ("3. SHAVING CUTTER SPECIFICATIONS" , "TOOL NO." , 0, 0),
            ("4. OTHERS" , "GRINDING STOCK" , 0, 0),
            ("5. INPUT DATA" , "SUMMARY NO." , 0, -1)
        };
    }
}