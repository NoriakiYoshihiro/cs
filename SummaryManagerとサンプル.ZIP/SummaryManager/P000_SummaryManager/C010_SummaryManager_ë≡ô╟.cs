﻿using Library;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Library.StringListDataTableConverter;

namespace Gearmetry
{
    public partial class SummaryManager
    {
        public void Run(string rawText)
        {
            SetRawText(rawText);
            DecodeRawText();
        }


        // RawTextをセット、セクション分割、セクション生成
        public void SetRawText(string rawText)
        {
            RawText = rawText;
        }


        // 
        public void DecodeRawText()
        {
            SeparateToRawSection();     // Step 2
            CreateAllSpecSection();     // Step 3
        }

        // ======== Step 1. RawText→RawEntire.Textに代入 ========




        // ======== Step 2. RawEntire→RawSectionに分割 ========
        // セクション分けをする Raw -> RawSection[]
        protected void SeparateToRawSection() => RawSection = RawOriginal.Separate(partition);



        // ======== Step 3. 各Sectionの生成とコンストラクタによる完成 ========
        protected void CreateAllSpecSection()
        {
            Sec0 = new SpecSection0(RawSection[0]);
            Sec1 = new SpecSection1(RawSection[1]);
            Sec2 = new SpecSection2(RawSection[2]);
            Sec3 = new SpecSection3(RawSection[3]);
            Sec4 = new SpecSection4(RawSection[4]);
            Sec5 = new SpecSection5(RawSection[5]);
            Sec6 = new SpecSection6(RawSection[6]);
            Sec7 = new SpecSection7(RawSection[7]);
        }


        public List<List<string>> GetAllSectionAllSpecRecord()
        {
            var result = new List<List<string>>();

            result.AddRange(Sec0.GetAllSpecRecord());
            result.AddRange(Sec1.GetAllSpecRecord());
            result.AddRange(Sec2.GetAllSpecRecord());
            result.AddRange(Sec3.GetAllSpecRecord());
            result.AddRange(Sec4.GetAllSpecRecord());
            result.AddRange(Sec5.GetAllSpecRecord());
            result.AddRange(Sec6.GetAllSpecRecord());
            result.AddRange(Sec7.GetAllSpecRecord());

            return result;
        }

        public string DecodedText => ListListToString(GetAllSectionAllSpecRecord());
    }
}
