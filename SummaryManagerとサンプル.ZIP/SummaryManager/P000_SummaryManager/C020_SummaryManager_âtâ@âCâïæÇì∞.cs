﻿using Library;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Library.StringListDataTableConverter;

namespace Gearmetry
{
    public partial class SummaryManager
    {
        // 生サマリ読み込み／ダイアログから
        public bool SelectAndReadRawTextFile()
        {
            using (var f = new OpenFileDialog())
            {
                f.FileName = "Raw*.txt";
                var result = f.ShowDialog();
                if (result != DialogResult.OK) return false;
                return ReadRawTextFile(f.FileName);
            }
        }


        // 生サマリ読み込み／ファイル名指定
        public bool ReadRawTextFile(string fileName)
        {
            try
            {
                using (var sr = new StreamReader(fileName)) SetRawText(sr.ReadToEnd());
                return true;
            }
            catch
            {
                return false;
            }
        }

        // 生サマリ保存／ダイアログから
        public bool SelectAndSaveRawTextFile()
        {
            using (var f = new SaveFileDialog())
            {
                f.FileName = RawTextDefaultFileName;
                var result = f.ShowDialog();
                if (result != DialogResult.OK) return false;
                return SaveRawTextFile(f.FileName);
            }
        }

        // 生サマリ保存／ファイル名指定
        public bool SaveRawTextFile(string fileName)
        {
            try
            {
                using (var sw = new StreamWriter(fileName, false, Encoding.GetEncoding("shift⁠-⁠jis"))) sw.Write(RawText);
                return true;
            }
            catch
            {
                return false;
            }
        }

        // 解読サマリ保存／ダイアログから
        public bool SelectAndSaveDecodedTextFile()
        {
            using (var f = new SaveFileDialog())
            {
                f.FileName = DecodedTextDefaultFileName;
                var result = f.ShowDialog();
                if (result != DialogResult.OK) return false;
                return SaveDecodedTextFile(f.FileName);
            }
        }

        // 解読サマリ保存／ファイル名指定
        public bool SaveDecodedTextFile(string fileName)
        {
            try
            {
                using (var sw = new StreamWriter(fileName, false, Encoding.GetEncoding("shift⁠-⁠jis"))) sw.Write(RawText);
                return true;
            }
            catch
            {
                return false;
            }
        }

        protected string RawTextDefaultFileName => "Raw_" + Sec0.SummaryNo.G1 + ".txt";
        protected string DecodedTextDefaultFileName => "Dec_" + Sec0.SummaryNo.G1 + ".csv";
    }
}
