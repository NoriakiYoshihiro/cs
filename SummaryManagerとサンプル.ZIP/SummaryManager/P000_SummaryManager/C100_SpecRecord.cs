﻿using Library;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Gearmetry
{
    public class SpecRecord
    {
        public string Section { get; internal set; }
        public string ID { get; internal set; }
        public string NameJ { get; internal set; }
        public string NameE { get; internal set; }

        public string G1 { get; internal set; }
        public string G2 { get; internal set; }

        public (string G1, string G2) Pair
        {
            get => (G1, G2);
            internal set
            {
                G1 = value.G1;
                G2 = value.G2;
            }
        }

        public (double G1, double G2) Double
        {
            get
            {
                try
                {
                    return (Convert.ToDouble(G1), Convert.ToDouble(G2));
                }
                catch
                {
                    return (-9999.9999, -9999.9999);
                }
            }
        }
        public (int G1, int G2) Int
        {
            get
            {
                try
                {
                    return (Convert.ToInt32(G1), Convert.ToInt32(G2));
                }
                catch
                {
                    return (-99999999, -99999999);
                }
            }
        }

        internal void SetCommon(string common) => Pair = (common, common);

        internal void SetValue(string section, string iD, string nameJ, string nameE)
        {
            Section = section;
            ID = iD;
            NameJ = nameJ;
            NameE = nameE;
        }
    }
}