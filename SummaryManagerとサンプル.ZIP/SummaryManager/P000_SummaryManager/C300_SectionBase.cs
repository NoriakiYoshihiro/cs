﻿using Library;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public enum Target { Number = 0, Signed = 1 }

    public partial class SpecSectionBase
    {
        // ======== コンストラクタ ========
        public SpecSectionBase(TextList rawSection)
        {
            Section = rawSection;
        }

        internal int SectionNumber { get; set; }

        internal TextList Section { get; set; }

        internal SpecRecord[] SpecRecordArray { get; set; }


        // 任意に使ってよい 
        // クラス内スコープ

        internal int Index { get => Section.Index; set => Section.Index = value; }
        internal int Pos { get => Section.Pos; set => Section.Pos = value; }

        // ショートカット的な利用
        internal (int Index, int Pos) IndexPos
        {
            get => (Index, Pos);
            set
            {
                Index = value.Index;
                Pos = value.Pos;
            }
        }
        internal List<string> List => Section.List;
        internal int ListSize => Section.Size;
        internal string Line => List[Index];
        internal string Char => Line.Substring(Pos, 1);
        internal int LineLength => Line.Length;

        public List<List<string>> GetAllSpecRecord()
        {
            var result = new List<List<string>>();
            result.Add(new List<string>() { SectionName[SectionNumber] });
            for (var i = 0; i < SpecRecordArray.Length; i++)
            {
                var l = new List<string> { SpecRecordArray[i].NameJ, SpecRecordArray[i].G1, SpecRecordArray[i].G2 };
                result.Add(l);
            }
            return result;
        }

        private string[] SectionName =
        {
            "******** Section 0 : INFORMATION ********",
            "******** Section 1 : DIMENSIONS ********",
            "******** Section 2 : ENGAGED GEAR DIMENSIONS ********",
            "******** Section 3 : CHARACTERISTICS OF ENGAGEMENT ********",
            "******** Section 4 : STRENGTH OF TOOTH ********",
            "******** Section 5 : OTHERS ********",
            "******** Section 6 : CUTTING DATA ********",
            "******** Section 7 : ROUGHING CUTTER SPECIFICATIONS ********"
        };


        internal string TrimString()
        {
            Section.SkipSpace();
            var result = "";
            while (Pos < LineLength && Char != " ")
            {
                result += Char;
                Pos++;
            }
            return result;
        }

        internal string TrimTarget(Target target)
        {
            if (target == Target.Signed) return TrimSignedNumber();
            if (target == Target.Number) return TrimUnsignedNumber();
            return "";
        }

        internal string TrimSignedNumber()
        {
            while (Pos < LineLength - 1 && !IsSign(Char)) Pos++; // 最後の一次が符号はダメ
            if (Pos >= LineLength - 1) return "";
            var result0 = Char;
            Pos++;
            var result1 = TrimDirectUnsignedNumber();
            if (result1 == "") return "";
            return result0 + result1;

        }

        internal string TrimUnsignedNumber()
        {
            while (Pos < LineLength && !IsNumber(Char)) Pos++;
            if (Pos >= LineLength) return "";
            return TrimDirectUnsignedNumber();
        }

        internal string TrimDirectUnsignedNumber()
        {
            var numberCount = 0;
            var commaCount = 0;
            var result = "";
            while (Pos < LineLength)
            {
                if (IsNumber(Char))
                {
                    numberCount++;
                    result += Char;
                    Pos++;
                    continue;
                }
                else if (IsComma(Char))
                {
                    if (commaCount > 0) break;
                    commaCount++;
                    result += Char;
                    Pos++;
                    continue;
                }
                break;
            }
            if (numberCount == 0) return "";
            if (result.Substring(result.Length - 1, 1) == ".") return result.Substring(0, result.Length - 1);
            return result;
        }

        internal string GetOne(params string[] argKey) => GetOne(Target.Number, argKey);
        internal string GetOne(Target target, params string[] argKey)
        {
            if (!Section.SeekIndexPosition(argKey)) return "";
            return TrimTarget(target);
        }


        internal (string G1, string G2) GetOneCopied(params string[] argKey) => GetOneCopied(Target.Number, argKey);
        internal (string G1, string G2) GetOneCopied(Target target, params string[] argKey)
        {
            var result = GetOne(target, argKey);
            return (result, result);
        }

        internal (string G1, string G2) GetTwo(params string[] argKey) => GetTwo(Target.Number, argKey);
        internal (string G1, string G2) GetTwo(Target target, params string[] argKey)
        {
            var G1 = GetOne(target, argKey);
            var G2 = TrimTarget(target);
            return (G1, G2);
        }

        private bool IsNumber(string c) => "0123456789".IndexOf(c) > -1;
        private bool IsSign(string c) => "+-".IndexOf(c) > -1;
        private bool IsComma(string c) => c == ".";
    }
}
