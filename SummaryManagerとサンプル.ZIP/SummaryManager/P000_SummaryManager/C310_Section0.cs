﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public class SpecSection0 : SpecSectionBase
    {
        public SpecRecord Version = new SpecRecord();
        public SpecRecord SummaryNo = new SpecRecord();
        public SpecRecord Date = new SpecRecord();
        public SpecRecord Name = new SpecRecord();
        public SpecRecord Note = new SpecRecord();
        public SpecRecord ExtInt = new SpecRecord();

        public SpecSection0(TextList rawSection) : base(rawSection)
        {
            DistributeArray();
            StoreSpec();
        }

        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                Version,
                SummaryNo,
                Date,
                Name,
                Note,
                ExtInt
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 0;
            var secName = "Section 0";

            s = Version;
            s.SetValue(secName, "Version", "バージョン", "VersionCenter");
            s.Pair = GetOneCopied("VERSION");

            s = SummaryNo;
            s.SetValue(secName, "SummaryNo", "サマリ番号", "Summary Number");
            {
                Section.SeekIndexPosition("SUMMARY NO.");
                s.SetCommon(TrimString());
            }

            s = Date;
            s.SetValue(secName, "Date", "作成日", "Date");
            s.Pair = GetOneCopied("DATE");

            s = Name;
            s.SetValue(secName, "Name", "名前", "Name");
            {
                Section.SeekIndexPosition("NAME :");
                s.SetCommon(TrimString());
            };

            s = Note;
            s.SetValue(secName, "Note", "ノート", "Note");
            {
                Section.SeekIndexPosition("NOTE :");
                s.SetCommon(TrimString());
            };

            s = ExtInt;
            s.SetValue(secName, "E", "外歯・内歯", "External/Internal");
            {
                Section.SeekIndexPosition("CALCULATION OF HELICAL GEAR");
                Index++;
                Pos = 0;
                Section.SeekPosition("(");
                var G1 = TrimString();
                G1 = G1.Substring(0, G1.Length);
                Section.SeekPosition("* ");
                var G2 = TrimString();
                G2 = G2.Substring(0, G2.Length - 1);
                s.Pair = (G1, G2);
            };

        }
    }
}
