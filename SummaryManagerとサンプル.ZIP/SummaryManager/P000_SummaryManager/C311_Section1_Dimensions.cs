﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public class SpecSection1 : SpecSectionBase
    {
        public SpecRecord CenterDistance = new SpecRecord();
        public SpecRecord CenterDistance_Upper = new SpecRecord();
        public SpecRecord CenterDistance_Lower = new SpecRecord();
        public SpecRecord NumberOfTeeth = new SpecRecord();
        public SpecRecord NormalModule = new SpecRecord();
        public SpecRecord NormalPressureAngle = new SpecRecord();
        public SpecRecord HelixAngle = new SpecRecord();
        public SpecRecord HelixHand = new SpecRecord();
        public SpecRecord PitchCircleDiameter = new SpecRecord();
        public SpecRecord BaseCircleDiameter = new SpecRecord();
        public SpecRecord OutsideDiameter = new SpecRecord();
        public SpecRecord OutsideDiameter_Upper = new SpecRecord();
        public SpecRecord OutsideDiameter_Lower = new SpecRecord();
        public SpecRecord WorkingOutsideDiameter = new SpecRecord();
        public SpecRecord RootCircleDiameter = new SpecRecord();
        public SpecRecord WholeDepth = new SpecRecord();
        public SpecRecord Addendum = new SpecRecord();
        public SpecRecord Dedendum = new SpecRecord();
        public SpecRecord SemiTopping = new SpecRecord();
        public SpecRecord TrueInvoluteFormDiameter = new SpecRecord();
        public SpecRecord Lead = new SpecRecord();
        public SpecRecord TransverseModule = new SpecRecord();
        public SpecRecord TransversePressureAngle = new SpecRecord();
        public SpecRecord TransverseCircularPitch = new SpecRecord();
        public SpecRecord TransverseBasePitch = new SpecRecord();
        public SpecRecord HelixAngleOnBaseCircle = new SpecRecord();
        public SpecRecord TransverseBacklash = new SpecRecord();
        public SpecRecord AddendumModificationCoeff = new SpecRecord();
        public SpecRecord NormalToothThickness = new SpecRecord();
        public SpecRecord TransverseToothThickness = new SpecRecord();
        public SpecRecord BallSize = new SpecRecord();
        public SpecRecord XBD = new SpecRecord();
        public SpecRecord XBD_Upper = new SpecRecord();
        public SpecRecord XBD_Lower = new SpecRecord();
        public SpecRecord Clearance = new SpecRecord();
        public SpecRecord TransverseTopland = new SpecRecord();
        public SpecRecord NormalTopland = new SpecRecord();
        public SpecRecord NormalToplandOnOutside = new SpecRecord();

        public SpecSection1(TextList rawSpecSection) : base(rawSpecSection)
        {
            DistributeArray();
            StoreSpec();
        }


        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                CenterDistance,
                CenterDistance_Upper,
                CenterDistance_Lower,
                NumberOfTeeth,
                NormalModule,
                NormalPressureAngle,
                HelixAngle,
                HelixHand,
                PitchCircleDiameter,
                BaseCircleDiameter,
                OutsideDiameter,
                OutsideDiameter_Upper,
                OutsideDiameter_Lower,
                WorkingOutsideDiameter,
                RootCircleDiameter,
                WholeDepth,
                Addendum,
                Dedendum,
                SemiTopping,
                TrueInvoluteFormDiameter,
                Lead,
                TransverseModule,
                TransversePressureAngle,
                TransverseCircularPitch,
                TransverseBasePitch,
                HelixAngleOnBaseCircle,
                TransverseBacklash,
                AddendumModificationCoeff,
                NormalToothThickness,
                TransverseToothThickness,
                BallSize,
                XBD,
                XBD_Upper,
                XBD_Lower,
                Clearance,
                TransverseTopland,
                NormalTopland,
                NormalToplandOnOutside
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 1;
            var secName = "SpecSection 1";

            s = CenterDistance;
            s.SetValue(secName, "D", "中心距離", "Center Distance");
            s.Pair = GetOneCopied("CENTER DISTANCE");

            s = CenterDistance_Upper;
            s.SetValue(secName, "D_Upper", "中心距離 公差上限", "Center Distance Upper");
            s.Pair = GetOneCopied(Target.Signed, "CENTER DISTANCE");

            s = CenterDistance_Lower;
            s.SetValue(secName, "D_Lower", "中心距離 公差下限", "Center Distance Lower");
            {
                Section.SeekIndexPosition("CENTER DISTANCE");
                Index++;
                Pos = 0;
                s.SetCommon(TrimSignedNumber());
            }

            s = NumberOfTeeth;
            s.SetValue(secName, "Z", "歯数", "Number Of Teeth");
            s.Pair = GetTwo("NUMBER OF TEETH");

            s = NormalModule;
            s.SetValue(secName, "M", "歯直角モジュール", "Normal Module");
            s.Pair = GetOneCopied("NORMAL MODULE");

            s = NormalPressureAngle;
            s.SetValue(secName, "Alpn", "歯直角圧力角", "NormalPressureAngle");
            s.Pair = GetOneCopied("NORMAL PRESSURE ANGLE");

            s = HelixAngle;
            s.SetValue(secName, "Bet", "ねじれ角", "Helix Angle");
            s.Pair = GetOneCopied("HELIX ANGLE", ")");

            s = HelixHand;
            s.SetValue(secName, "H", "ねじれ方向", "Helix Hand");
            {
                Section.SeekIndexPosition("HELIX ANGLE (HAND) ( ");

                switch (Char)
                {
                    case "R": s.Pair = ("RH", "LH"); break;
                    case "L": s.Pair = ("LH", "RH"); break;
                    default: s.Pair = ("Spur", "Spur"); break;
                }
            };

            s = PitchCircleDiameter;
            s.SetValue(secName, "Dp", "ピッチ円径", "Pitch Circle Diameter");
            s.Pair = GetTwo("PITCH CIRCLE DIAMETER");

            s = BaseCircleDiameter;
            s.SetValue(secName, "Db", "基礎円径", "Base Circle Diameter");
            s.Pair = GetTwo("BASE CIRCLE DIAMETER");

            s = OutsideDiameter;
            s.SetValue(secName, "Do", "歯先径", "Outside Diameter");
            {
                s.G1 = GetOne("OUTSIDE DIAMETER");
                s.G2 = GetOne("OUTSIDE DIAMETER", ".", " ");
            }

            s = OutsideDiameter_Upper;
            s.SetValue(secName, "Do_Upper", "歯先径 公差上限", "Outside Diameter Upper");
            {
                s.G1 = GetOne(Target.Signed, "OUTSIDE DIAMETER");
                s.G2 = GetOne(Target.Signed, "OUTSIDE DIAMETER", "+", ".");
            }

            s = OutsideDiameter_Lower;
            s.SetValue(secName, "Do_Lower", "歯先径 公差下限", "Outside Diameter Lower");
            {
                Section.SeekIndexPosition("OUTSIDE DIAMETER");
                Index++;
                Pos = 0;
                s.G1 = TrimSignedNumber();
                s.G2 = TrimSignedNumber();
            }

            s = WorkingOutsideDiameter;
            s.SetValue(secName, "Dwo", "有効歯先径", "Working Outside Diameter");
            s.Pair = GetTwo("WORKING OUTSIDE DIAMETER");

            s = RootCircleDiameter;
            s.SetValue(secName, "Droot", "歯底円径", "Root Circle Diameter");
            s.Pair = GetTwo("ROOT CIRCLE DIAMETER");

            s = WholeDepth;
            s.SetValue(secName, "Had", "全歯丈", "Whole Depth");
            s.Pair = GetTwo("WHOLE DEPTH");

            s = Addendum;
            s.SetValue(secName, "Ha", "アデンダム", "Addendum");
            s.Pair = GetTwo("ADDENDUM");

            s = Dedendum;
            s.SetValue(secName, "Hd", "デデンダム", "Dedendum");
            s.Pair = GetTwo("DEDENDUM");

            s = SemiTopping;
            s.SetValue(secName, "St", "セミトッピング", "Semi topping");
            s.Pair = GetTwo("SEMI-TOPPING");

            s = TrueInvoluteFormDiameter;
            s.SetValue(secName, "Dtif", "歯形管理径", "True Involute Form Diameter");
            s.Pair = GetTwo("TRUE INVOLUTE FORM DIAMETER");

            s = Lead;
            s.SetValue(secName, "", "リード", "Lead");
            s.Pair = GetTwo("LEAD");

            s = TransverseModule;
            s.SetValue(secName, "Mt", "軸直角モジュール", "Transverse Module");
            s.Pair = GetOneCopied("TRANSVERSE MODULE");

            s = TransversePressureAngle;
            s.SetValue(secName, "Alpt", "軸直角圧力角", "Transverse Pressure Angle");
            s.Pair = GetOneCopied("TRANSVERSE PRESSURE ANGLE");

            s = TransverseCircularPitch;
            s.SetValue(secName, "", "軸直角円弧ピッチ", "Transverse Circular Pitch");
            s.Pair = GetOneCopied("TRANSVERSE CIRCULAR PITCH");

            s = TransverseBasePitch;
            s.SetValue(secName, "", "軸直角基礎ピッチ", "Transverse Base Pitch");
            s.Pair = GetOneCopied("TRANSVERSE BASE PITCH");

            s = HelixAngleOnBaseCircle;
            s.SetValue(secName, "Betb", "基礎円筒上ねじれ角", "Helix Angle On Base Circle");
            s.Pair = GetOneCopied("HELIX ANGLE ON BASE CIRCLE");

            s = TransverseBacklash;
            s.SetValue(secName, "BLt", "軸直角バックラッシ", "Transverse Backlash");
            s.Pair = GetOneCopied("TRANSVERSE BACKLASH");

            s = AddendumModificationCoeff;
            s.SetValue(secName, "X", "転位係数", "Addendum Modification Coefficient");
            s.Pair = GetTwo("DDENDUM MODIFICATION COEFF.");

            s = NormalToothThickness;
            s.SetValue(secName, "Sn", "歯直角歯厚", "Normal Tooth Thickness");
            s.Pair = GetTwo("NORMAL TOOTH THICKNESS");

            s = TransverseToothThickness;
            s.SetValue(secName, "St", "軸直角歯厚", "Transverse Tooth Thickness");
            s.Pair = GetTwo("TRANSVERSE TOOTH THICKNESS");

            s = BallSize;
            s.SetValue(secName, "Dball", "測定ボール径", "Ball Sizer");
            s.Pair = GetTwo("BALL SIZE");

            s = XBD;
            s.SetValue(secName, "Dm", "XBD", "XBD");
            {
                s.G1 = GetOne("OVER BALL DIAMETER");
                s.G2 = GetOne("OVER BALL DIAMETER", ".", " ");
            }

            s = XBD_Upper;
            s.SetValue(secName, "Dm_Upper", "XBD 公差上限", "XBD Upper");
            s.Pair = GetTwo(Target.Signed, "OVER BALL DIAMETER");

            s = XBD_Lower;
            s.SetValue(secName, "Dm_Lower", "XBD 公差下限", "XBD Lower");
            {
                Section.SeekIndexPosition("OVER BALL DIAMETER");
                Index++;
                Pos = 0;
                s.G1 = TrimSignedNumber();
                s.G2 = TrimSignedNumber();
            }

            s = Clearance;
            s.SetValue(secName, "Ct", "歯先クリアランス", "Clearance");
            s.Pair = GetTwo("CLEARANCE");

            s = TransverseTopland;
            s.SetValue(secName, "TLt", "軸直角トップランド", "Transverse Topland");
            s.Pair = GetTwo("TRANSVERSE TOPLAND");

            s = NormalTopland;
            s.SetValue(secName, "TLn", "歯直角トップランド", "Normal Topland");
            s.Pair = GetTwo("NORMAL TOPLAND");

            s = NormalToplandOnOutside;
            s.SetValue(secName, "TLnDo", "歯直角トップランド(歯先径)", "Normal Topland On Do");
            s.Pair = GetTwo("(OUTSIDE DIA.)");
        }
    }

}
