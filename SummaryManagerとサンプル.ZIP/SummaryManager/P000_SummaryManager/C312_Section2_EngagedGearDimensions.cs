﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Gearmetry
{
    public class SpecSection2 : SpecSectionBase
    {
        public SpecRecord NormalModule = new SpecRecord();
        public SpecRecord NormalPressureAngle = new SpecRecord();
        public SpecRecord HelixAngle = new SpecRecord();
        public SpecRecord TransversePressureAngle = new SpecRecord();
        public SpecRecord PitchCircleDiameter = new SpecRecord();
        public SpecRecord TransverseModule = new SpecRecord();
        public SpecRecord Addendum = new SpecRecord();
        public SpecRecord Dedendum = new SpecRecord();
        public SpecRecord NormalToothThickness = new SpecRecord();
        public SpecRecord TransverseToothThickness = new SpecRecord();

        public SpecSection2(TextList rawSpecSection) : base(rawSpecSection)
        {
            DistributeArray();
            StoreSpec();
        }


        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                NormalModule,
                NormalPressureAngle,
                HelixAngle,
                TransversePressureAngle,
                PitchCircleDiameter,
                TransverseModule,
                Addendum,
                Dedendum,
                NormalToothThickness,
                TransverseToothThickness
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 2;
            var secName = "SpecSection 2";

            s = NormalModule;
            s.SetValue(secName, "ME", "歯直角モジュール", "Normal Module");
            s.Pair = GetOneCopied("NORMAL MODULE");

            s = NormalPressureAngle;
            s.SetValue(secName, "AlpnE", "歯直角圧力角", "NormalPressureAngle");
            s.Pair = GetOneCopied("NORMAL PRESSURE ANGLE");

            s = HelixAngle;
            s.SetValue(secName, "BetE", "ねじれ角", "Helix Angle");
            s.Pair = GetOneCopied("HELIX ANGLE");

            s = PitchCircleDiameter;
            s.SetValue(secName, "DpE", "ピッチ円径", "Pitch Circle Diameter");
            s.Pair = GetTwo("PITCH CIRCLE DIAMETER");

            s = Addendum;
            s.SetValue(secName, "Ha", "アデンダム", "Addendum");
            s.Pair = GetTwo("ADDENDUM");

            s = Dedendum;
            s.SetValue(secName, "Hd", "デデンダム", "Dedendum");
            s.Pair = GetTwo("DEDENDUM");

            s = TransverseModule;
            s.SetValue(secName, "MtE", "軸直角モジュール", "Transverse Module");
            s.Pair = GetOneCopied("TRANSVERSE MODULE");

            s = TransversePressureAngle;
            s.SetValue(secName, "AlptE", "軸直角圧力角", "Transverse Pressure Angle");
            s.Pair = GetOneCopied("TRANSVERSE PRESUURE ANGLE"); // サマリにスペルミス PRESSURE->PRESUURE (SがU)

            s = NormalToothThickness;
            s.SetValue(secName, "Sn", "歯直角歯厚", "Normal Tooth Thickness");
            s.Pair = GetTwo("NORMAL TOOTH THICKNESS");

            s = TransverseToothThickness;
            s.SetValue(secName, "St", "軸直角歯厚", "Transverse Tooth Thickness");
            s.Pair = GetTwo("TRANSVERSE TOOTH THICKNESS");
        }
    }

}
