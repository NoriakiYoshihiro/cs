﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public class SpecSection3 : SpecSectionBase
    {
        public SpecRecord FaceWidth = new SpecRecord();
        public SpecRecord EffectiveFaceWidth = new SpecRecord();
        public SpecRecord ContactRatioOfRecess = new SpecRecord();
        public SpecRecord ContactRatioOfApproach = new SpecRecord();
        public SpecRecord ProfileContactRatio = new SpecRecord();
        public SpecRecord FaceContactRatio = new SpecRecord();
        public SpecRecord TotalContactRatio = new SpecRecord();
        public SpecRecord SlidVelAtTip = new SpecRecord();
        public SpecRecord SpecificSlidingAtTip = new SpecRecord();
        public SpecRecord SpecificSlidingAtRoot = new SpecRecord();

        public SpecSection3(TextList rawSpecSection) : base(rawSpecSection)
        {
            DistributeArray();
            StoreSpec();
        }


        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                FaceWidth,
                EffectiveFaceWidth,
                ContactRatioOfRecess,
                ContactRatioOfApproach,
                ProfileContactRatio,
                FaceContactRatio,
                TotalContactRatio,
                SlidVelAtTip,
                SpecificSlidingAtTip,
                SpecificSlidingAtRoot
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 3;
            var secName = "Section 3";

            s = FaceWidth;
            s.SetValue(secName, "B", "歯幅", "Face Width");
            s.Pair = GetTwo("FACE WIDTH");

            s = EffectiveFaceWidth;
            s.SetValue(secName, "Be", "有効歯幅", "Effective Face Width");
            s.Pair = GetOneCopied("EFFECTIVE FACE WIDTH");

            s = ContactRatioOfRecess;
            s.SetValue(secName, "", "遠のき正面噛合率", "Contact Ratio Of Recess");
            s.Pair = GetOneCopied("CONTACT RATIO OF RECESS");

            s = ContactRatioOfApproach;
            s.SetValue(secName, "", "近づき正面噛合率", "Contact Ratio Of Approach");
            s.Pair = GetOneCopied("CONTACT RATIO OF APPROACH");

            s = ProfileContactRatio;
            s.SetValue(secName, "EpsAlp", "正面噛合率", "Profile Contact Ratio");
            s.Pair = GetOneCopied("PROFILE CONTACT RATIO");

            s = FaceContactRatio;
            s.SetValue(secName, "EpsBet", "重なり噛合率", "Face Contact Ratio");
            s.Pair = GetOneCopied("FACE CONTACT RATIO");

            s = TotalContactRatio;
            s.SetValue(secName, "Eps", "全噛合率", "Total Contact Ratio");
            s.Pair = GetOneCopied("TOTAL CONTACT RATIO");

            s = SlidVelAtTip;
            s.SetValue(secName, "", "歯先滑り速度", "Sliding Velocity At Tip");
            s.Pair = GetTwo("(DRIVER:1RPM)");

            s = SpecificSlidingAtTip;
            s.SetValue(secName, "", "歯先滑り率", "Sliding Velocity At Tip");
            s.Pair = GetTwo("SPECIFIC SLIDING AT TIP");

            s = SpecificSlidingAtRoot;
            s.SetValue(secName, "", "歯元滑り率", "Sliding Velocity At Root");
            s.Pair = GetTwo("SPECIFIC SLIDING AT ROOT");
        }
    }

}
