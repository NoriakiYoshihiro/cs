﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public class SpecSection4 : SpecSectionBase
    {
        public SpecRecord Torque = new SpecRecord();
        public SpecRecord TangentialForce = new SpecRecord();

        public SpecRecord NormalBendingStressISO = new SpecRecord();
        public SpecRecord ToothFormFactorISO = new SpecRecord();
        public SpecRecord LengthOfBeamISO = new SpecRecord();
        public SpecRecord WidthOfBeamISO = new SpecRecord();
        public SpecRecord LoadActingAngleISO = new SpecRecord();
        public SpecRecord StressCorrectionFactorISO = new SpecRecord();
        public SpecRecord HelixFactorISO = new SpecRecord();

        public SpecRecord NormalBendingStressConv = new SpecRecord();
        public SpecRecord ToothFormFactorConv = new SpecRecord();
        public SpecRecord LengthOfBeamConv = new SpecRecord();
        public SpecRecord WidthOfBeamConv = new SpecRecord();
        public SpecRecord LoadActingAngleConv = new SpecRecord();
        public SpecRecord StressConcentrationFactorConv = new SpecRecord();
        public SpecRecord ContactStress = new SpecRecord();
        public SpecRecord SquareRootOfRelativeCurvature = new SpecRecord();


        public SpecSection4 (TextList rawSpecSection) : base(rawSpecSection)
        {
            DistributeArray();
            StoreSpec();
        }


        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                Torque,
                TangentialForce,
                NormalBendingStressISO,
                ToothFormFactorISO,
                LengthOfBeamISO,
                WidthOfBeamISO,
                LoadActingAngleISO,
                StressCorrectionFactorISO,
                HelixFactorISO,
                NormalBendingStressConv,
                ToothFormFactorConv,
                LengthOfBeamConv,
                WidthOfBeamConv,
                LoadActingAngleConv,
                StressConcentrationFactorConv,
                ContactStress,
                SquareRootOfRelativeCurvature
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 4;
            var secName = "Section 4";

            s = Torque;
            s.SetValue(secName, "", "トルク", "Torque");
            s.Pair = GetTwo("TORQUE");

            s = TangentialForce;
            s.SetValue(secName, "", "噛合ピッチ円接線力", "Tangential Force");
            s.Pair = GetOneCopied("TANGENTIAL FORCE");

            s = NormalBendingStressISO;
            s.SetValue(secName, "", "歯元公称曲げ応力(ISO)", "Normal Bending Stress (ISO)");
            s.Pair = GetTwo("NOMINAL BENDING STRESS (ISO) -N/MM**2-");

            s = ToothFormFactorISO;
            s.SetValue(secName, "", "歯形係数(ISO)", "Tooth Form Factor (ISO)");
            s.Pair = GetTwo("TOOTH FORM FACTOR (ISO)");

            s = LengthOfBeamISO;
            s.SetValue(secName, "", "等応力はりの長さ(ISO)", "Length OF Beam (ISO)");
            s.Pair = GetTwo("LENGTH OF BEAM");

            s = WidthOfBeamISO;
            s.SetValue(secName, "", "等応力はりの幅(ISO)", "Width OF Beam (ISO)");
            s.Pair = GetTwo("WIDTH OF BEAM");

            s = LoadActingAngleISO;
            s.SetValue(secName, "", "荷重作用角(ISO)", "Load Actiong Angle (ISO)");
            s.Pair = GetTwo("LOAD ACTING ANGLE");

            s = StressCorrectionFactorISO;
            s.SetValue(secName, "", "????????", "Stress Correction Factor (ISO)");
            s.Pair = GetTwo("STRESS CORRECTION FACTOR (ISO)");

            s = HelixFactorISO;
            s.SetValue(secName, "", "????????", "Helix Factor (ISO)");
            s.Pair = GetTwo("HELIX FACTOR (ISO)");

            s = NormalBendingStressConv;
            s.SetValue(secName, "", "歯元公称曲げ応力(Conv)", "Normal Bending Stress (ISO)");
            s.Pair = GetTwo("NOMINAL BENDING STRESS (conv.) -N/MM**2-");

            s = ToothFormFactorConv;
            s.SetValue(secName, "", "歯形係数(Conv)", "Tooth Form Factor (Conv)");
            s.Pair = GetTwo("TOOTH FORM FACTOR (conv.)");

            s = LengthOfBeamConv;
            s.SetValue(secName, "", "等応力はりの長さ(Conv)", "Length OF Beam (Conv)");
            {
                Section.SeekIndexPosition("LENGTH OF BEAM");
                Section.SeekIndexPosition(Index + 1, "LENGTH OF BEAM");
                s.G1 = TrimUnsignedNumber();
                s.G2 = TrimUnsignedNumber();
            }

            s = WidthOfBeamConv;
            s.SetValue(secName, "", "等応力はりの幅(Conv)", "Width OF Beam (Conv)");
            {
                Section.SeekIndexPosition("WIDTH OF BEAM");
                Section.SeekIndexPosition(Index + 1, "WIDTH OF BEAM");
                s.G1 = TrimUnsignedNumber();
                s.G2 = TrimUnsignedNumber();
            }

            s = LoadActingAngleConv;
            s.SetValue(secName, "", "荷重作用角(Conv)", "Load Actiong Angle (Conv)");
            {
                Section.SeekIndexPosition("LOAD ACTING ANGLE");
                Section.SeekIndexPosition(Index + 1, "LOAD ACTING ANGLE");
                s.G1 = TrimUnsignedNumber();
                s.G2 = TrimUnsignedNumber();
            }

            s = StressConcentrationFactorConv;
            s.SetValue(secName, "", "応力集中係数(Conv)", "Stress Concentration Factor (Conv)");
            s.Pair = GetTwo("STRESS CONCENTRATION FACTOR (conv.)");

            s = ContactStress;
            s.SetValue(secName, "", "接触応力", "Contact Stress");
            s.Pair = GetOneCopied("CONTACT STRESS -N/MM**2-");

            s = SquareRootOfRelativeCurvature;
            s.SetValue(secName, "", "相対曲率の平方根", "Square Root Of Relative Vurvature");
            s.Pair = GetOneCopied("SQUARE ROOT OF RELATIVE CURVATURE");
        }
    }

}
