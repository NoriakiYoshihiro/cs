﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public class SpecSection5 : SpecSectionBase
    {
        public SpecRecord DistortionByHeatTreat = new SpecRecord();
        public SpecRecord ShavingStock = new SpecRecord();
        public SpecRecord GrindingStock = new SpecRecord();
        public SpecRecord XBDTransToothThickne = new SpecRecord();
        public SpecRecord MatingGearTipContactPoint = new SpecRecord();
        public SpecRecord MinimumFinishingStock = new SpecRecord();
        public SpecRecord FilletCurveStartingDiameter = new SpecRecord();

        public SpecSection5(TextList rawSpecSection) : base(rawSpecSection)
        {
            DistributeArray();
            StoreSpec();
        }


        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                DistortionByHeatTreat,
                ShavingStock,
                GrindingStock,
                XBDTransToothThickne,
                MatingGearTipContactPoint,
                MinimumFinishingStock,
                FilletCurveStartingDiameter
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 5;
            var secName = "Section 5";

            s = DistortionByHeatTreat;
            s.SetValue(secName, "DelHT", "焼歪量(XBD)", "Heat Distortion(XBD)");
            s.Pair = GetTwo("DISTORTION BY HEAT TREAT. (O.B.D.)");

            s = ShavingStock;
            s.SetValue(secName, "DelSV", "シェービング代(XBD)", "Shaving Stock(XBD)");
            s.Pair = GetTwo("SHAVING STOCK (O.B.D.)");

            s = GrindingStock;
            s.SetValue(secName, "DelGR", "歯研代(XBD)", "Grinding Stock(XBD)");
            s.Pair = GetTwo("GRINDING STOCK (O.B.D.)");

            s = XBDTransToothThickne;
            s.SetValue(secName, "Kxt", "XBD/歯厚換算計数", "XBD/Transverse Tooth Thickness Coefficient");
            s.Pair = GetTwo("O.B.D. / TRANS. TOOTH THICKNES");

            s = MatingGearTipContactPoint;
            s.SetValue(secName, "Dmgtc", "噛合開始径", "Mating Gear Tip Contact Point");
            s.Pair = GetTwo("MATING GEAR TIP(W.O.D.) CONTACT POINT");

            s = MinimumFinishingStock;
            s.SetValue(secName, "", "噛合開始形上最小仕上げ代", "Minimum Finishing Stock On Dmtgc (PP)");
            s.Pair = GetTwo("MINIMUM FINISHING STOCK (ON PP-HOB)");

            s = FilletCurveStartingDiameter;
            s.SetValue(secName, "Dfil", "フィレットカーブ開始径", "Fillet Curve Starting Diameter");
            s.Pair = GetTwo("FILLET CURVE STARTING DIAMETER");
        }
    }

}
