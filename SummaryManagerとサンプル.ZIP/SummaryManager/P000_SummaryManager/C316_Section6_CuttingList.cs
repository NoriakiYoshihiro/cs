﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public class SpecSection6 : SpecSectionBase
    {
        public SpecRecord NumberOfTeeth = new SpecRecord();
        public SpecRecord NormalModule = new SpecRecord();
        public SpecRecord NormalPressureAngle = new SpecRecord();
        public SpecRecord HelixAngle = new SpecRecord();
        public SpecRecord HelixHand = new SpecRecord();
        public SpecRecord BallSize = new SpecRecord();
        public SpecRecord XBD_C = new SpecRecord();
        public SpecRecord XBD_H = new SpecRecord();


        public SpecSection6(TextList rawSpecSection) : base(rawSpecSection)
        {
            DistributeArray();
            StoreSpec();
        }


        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                NumberOfTeeth,
                NormalModule,
                NormalPressureAngle,
                HelixAngle,
                HelixHand,
                BallSize,
                XBD_C,
                XBD_H
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 6;
            var secName = "Section 6";

            s = NumberOfTeeth;
            s.SetValue(secName, "", "歯数", "Number Of Teeth");
            s.Pair = GetTwo("NUMBER OF TEETH");

            s = NormalModule;
            s.SetValue(secName, "MC", "歯直角モジュール", "Normal Module");
            s.Pair = GetOneCopied("NORMAL MODULE");


            s = NormalPressureAngle;
            s.SetValue(secName, "AlpnC", "歯直角圧力角", "NormalPressureAngle");
            s.Pair = GetOneCopied("NORMAL PRESSURE ANGLE");

            s = HelixAngle;
            s.SetValue(secName, "BetC", "ねじれ角", "Helix Angle");
            s.Pair = GetOneCopied("HELIX ANGLE");

            s = HelixHand;
            s.SetValue(secName, "", "ねじれ方向", "Helix Hand");
            {
                Section.SeekIndexPosition("(HAND) ( ");

                switch (Char)
                {
                    case "R": s.Pair = ("RH", "LH"); break;
                    case "L": s.Pair = ("LH", "RH"); break;
                    default: s.Pair = ("Spur", "Spur"); break;
                }
            }


            s = BallSize;
            s.SetValue(secName, "", "測定ボール径", "Ball Size");
            s.Pair = GetTwo("BALL SIZE");

            s = XBD_C;
            s.SetValue(secName, "Dm_C", "XBD (歯切後)", "XBD (Cut)");
            {
                s.G1 = GetOne("OVER BALL DIA. AFTER CUT");
                s.G2 = GetOne("OVER BALL DIA. AFTER CUT", ".", " ");
            }
            s = XBD_H;
            s.SetValue(secName, "Dm_H", "XBD (焼後)", "XBD (HT)");
            {
                s.G1 = GetOne("OVER BALL DIA. BEFORE GRINDING");
                s.G2 = GetOne("OVER BALL DIA. BEFORE GRINDING", ".", " ");
            }
        }
    }

}
