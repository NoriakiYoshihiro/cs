﻿using Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public class SpecSection7 : SpecSectionBase
    {
        public SpecRecord NormalPressureAngle = new SpecRecord();
        public SpecRecord HobAddendum = new SpecRecord();
        public SpecRecord SemiToppingHobDedendum = new SpecRecord();
        public SpecRecord WholeDepth = new SpecRecord();
        public SpecRecord AddendumRatio = new SpecRecord();
        public SpecRecord SemiToppingHobPressAngle = new SpecRecord();
        public SpecRecord TipRadius = new SpecRecord();
        public SpecRecord AmountOfHighPoint = new SpecRecord();
        public SpecRecord HeightFromTip = new SpecRecord();
        public SpecRecord NormalTopland = new SpecRecord();

        public SpecSection7(TextList rawSpecSection) : base(rawSpecSection)
        {
            DistributeArray();
            StoreSpec();
        }


        internal void DistributeArray()
        {
            SpecRecordArray = new SpecRecord[]
            {
                NormalPressureAngle,
                HobAddendum,
                SemiToppingHobDedendum,
                WholeDepth,
                AddendumRatio,
                SemiToppingHobPressAngle,
                TipRadius,
                AmountOfHighPoint,
                HeightFromTip,
                NormalTopland
            };
        }

        internal void StoreSpec()
        {
            SpecRecord s;
            SectionNumber = 7;
            var secName = "Section 7";

            s = NormalPressureAngle;
            s.SetValue(secName, "AlpnC", "歯直角圧力角", "Normal Pressure Angle");
            s.Pair = GetTwo("NORMAL PRESSURE ANGLE");

            s = HobAddendum;
            s.SetValue(secName, "HaC", "アデンダム", "Addendum");
            s.Pair = GetTwo("HOB-ADDENDUM");

            s = SemiToppingHobDedendum;
            s.SetValue(secName, "HdC", "デデンダム", "Dedendum");
            s.Pair = GetTwo("SEMI-TOPPING-HOB-DEDENDUM");

            s = WholeDepth;
            s.SetValue(secName, "HadC", "全刃丈", "Whole Depth");
            s.Pair = GetTwo("WHOLE DEPTH");

            s = AddendumRatio;
            s.SetValue(secName, "", "アデンダムレシオ", "Addendum Ratio");
            s.Pair = GetTwo("ADDENDUM RATIO");

            s = SemiToppingHobPressAngle;
            s.SetValue(secName, "AlpnsC", "歯直角セミトップ圧力角", "Normal Semi Topping Pressure Angle");
            s.Pair = GetTwo("SEMI-TOPPING-HOB-PRESS.-ANGLE");

            s = TipRadius;
            s.SetValue(secName, "RtipC", "刃先丸み", "Tip Radius");
            s.Pair = GetTwo("TIP RADIUS");

            s = AmountOfHighPoint;
            s.SetValue(secName, "HpC", "コブ高さ", "Amount Of High Point");
            s.Pair = GetTwo("AMOUNT OF HIGH-POINT");

            s = HeightFromTip;
            s.SetValue(secName, "H2C", "コブ長さ", "Height From Tip");
            s.Pair = GetTwo("HEIGHT FROM TIP");

            s = NormalTopland;
            s.SetValue(secName, "TLnC", "刃直角トップランド", "Normal Topland");
            s.Pair = GetTwo("NORMAL TOPLAND");
        }
    }

}
