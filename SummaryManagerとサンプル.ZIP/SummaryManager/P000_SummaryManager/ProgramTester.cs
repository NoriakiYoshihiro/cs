﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

using Library;
using static Library.StringListDataTableConverter;
using FormUI;
using System.Runtime.Remoting.Channels;
using System.Net;
using System.Security.Cryptography.X509Certificates;

namespace Gearmetry
{
    internal static class ProgramTester
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            var mode = 2;

            if (mode == 1)
            {
                SummaryManager summaryManager = new SummaryManager();
                summaryManager.ReadRawTextFile("_PdfTextSample.txt");
                //summaryManager.DecodeRawText();

                Logger.Clear();

                Rec(summaryManager.Sec1.NumberOfTeeth);
                Rec(summaryManager.Sec1.NormalModule);
                Rec(summaryManager.Sec1.NormalPressureAngle);
                Rec(summaryManager.Sec1.HelixAngle);
                Rec(summaryManager.Sec4.NormalBendingStressISO);
                Rec(summaryManager.Sec1.BallSize);
                Rec(summaryManager.Sec1.XBD);

                Logger.Show();
            }
            else if (mode == 2)
            {
                var f = new TestFormSummaryManager();
                f.ShowDialog();
            }

            void Rec(SpecRecord specRecord)
            {
                Logger.Add(specRecord.NameJ, specRecord.G1, specRecord.G2);
            }

        }
    }
}
