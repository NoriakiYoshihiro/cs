﻿using Library;
using static Library.StringListDataTableConverter;

namespace Gearmetry
{
    partial class TestFormSummaryManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxRawSummary = new System.Windows.Forms.TextBox();
            this.textBoxSpecSection = new System.Windows.Forms.TextBox();
            this.buttonReadFile = new System.Windows.Forms.Button();
            this.buttonReadSampleFile = new System.Windows.Forms.Button();
            this.buttonClearAll = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.buttonDecode = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.buttonSaveRawText = new System.Windows.Forms.Button();
            this.buttonSaveDecodedText = new System.Windows.Forms.Button();
            this.labelSummaryNo = new System.Windows.Forms.Label();
            this.textBoxSummaryNo = new System.Windows.Forms.TextBox();
            this.labelNormalModule = new System.Windows.Forms.Label();
            this.textBoxNormalModule = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.labelNote = new System.Windows.Forms.Label();
            this.textBoxNote = new System.Windows.Forms.TextBox();
            this.labelNumberOfTeeth = new System.Windows.Forms.Label();
            this.textBoxNumberOfTeethG1 = new System.Windows.Forms.TextBox();
            this.textBoxNumberOfTeethG2 = new System.Windows.Forms.TextBox();
            this.labelNormalPressureAngle = new System.Windows.Forms.Label();
            this.labelHelixAngle = new System.Windows.Forms.Label();
            this.textBoxNormalPressureAngle = new System.Windows.Forms.TextBox();
            this.textBoxHelixAngle = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBoxRawSummary
            // 
            this.textBoxRawSummary.Location = new System.Drawing.Point(20, 50);
            this.textBoxRawSummary.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRawSummary.Multiline = true;
            this.textBoxRawSummary.Name = "textBoxRawSummary";
            this.textBoxRawSummary.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxRawSummary.Size = new System.Drawing.Size(760, 640);
            this.textBoxRawSummary.TabIndex = 0;
            // 
            // textBoxSpecSection
            // 
            this.textBoxSpecSection.Location = new System.Drawing.Point(820, 301);
            this.textBoxSpecSection.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSpecSection.Multiline = true;
            this.textBoxSpecSection.Name = "textBoxSpecSection";
            this.textBoxSpecSection.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSpecSection.Size = new System.Drawing.Size(760, 389);
            this.textBoxSpecSection.TabIndex = 1;
            // 
            // buttonReadFile
            // 
            this.buttonReadFile.Location = new System.Drawing.Point(220, 740);
            this.buttonReadFile.Name = "buttonReadFile";
            this.buttonReadFile.Size = new System.Drawing.Size(160, 100);
            this.buttonReadFile.TabIndex = 2;
            this.buttonReadFile.Text = "生サマリ\nファイル読込";
            this.buttonReadFile.UseVisualStyleBackColor = true;
            this.buttonReadFile.Click += new System.EventHandler(this.buttonReadFile_Click);
            // 
            // buttonReadSampleFile
            // 
            this.buttonReadSampleFile.Location = new System.Drawing.Point(420, 740);
            this.buttonReadSampleFile.Name = "buttonReadSampleFile";
            this.buttonReadSampleFile.Size = new System.Drawing.Size(160, 100);
            this.buttonReadSampleFile.TabIndex = 3;
            this.buttonReadSampleFile.Text = "生サマリ\nサンプルファイル読込";
            this.buttonReadSampleFile.UseVisualStyleBackColor = true;
            this.buttonReadSampleFile.Click += new System.EventHandler(this.buttonReadSampleFile_Click);
            // 
            // buttonClearAll
            // 
            this.buttonClearAll.Location = new System.Drawing.Point(20, 740);
            this.buttonClearAll.Name = "buttonClearAll";
            this.buttonClearAll.Size = new System.Drawing.Size(160, 100);
            this.buttonClearAll.TabIndex = 4;
            this.buttonClearAll.Text = "全クリア";
            this.buttonClearAll.UseVisualStyleBackColor = true;
            this.buttonClearAll.Click += new System.EventHandler(this.buttonClearAll_Click);
            // 
            // buttonDecode
            // 
            this.buttonDecode.Location = new System.Drawing.Point(820, 740);
            this.buttonDecode.Name = "buttonDecode";
            this.buttonDecode.Size = new System.Drawing.Size(160, 100);
            this.buttonDecode.TabIndex = 5;
            this.buttonDecode.Text = "解読実行";
            this.buttonDecode.UseVisualStyleBackColor = true;
            this.buttonDecode.Click += new System.EventHandler(this.buttonDecode_Click);
            // 
            // buttonSaveRawText
            // 
            this.buttonSaveRawText.Location = new System.Drawing.Point(620, 740);
            this.buttonSaveRawText.Name = "buttonSaveRawText";
            this.buttonSaveRawText.Size = new System.Drawing.Size(160, 100);
            this.buttonSaveRawText.TabIndex = 6;
            this.buttonSaveRawText.Text = "生サマリ\n保存";
            this.buttonSaveRawText.UseVisualStyleBackColor = true;
            this.buttonSaveRawText.Click += new System.EventHandler(this.buttonSaveRawText_Click);
            // 
            // buttonSaveDecodedText
            // 
            this.buttonSaveDecodedText.Location = new System.Drawing.Point(1020, 740);
            this.buttonSaveDecodedText.Name = "buttonSaveDecodedText";
            this.buttonSaveDecodedText.Size = new System.Drawing.Size(160, 100);
            this.buttonSaveDecodedText.TabIndex = 7;
            this.buttonSaveDecodedText.Text = "解読サマリ\n保存";
            this.buttonSaveDecodedText.UseVisualStyleBackColor = true;
            this.buttonSaveDecodedText.Click += new System.EventHandler(this.buttonSaveDecodedText_Click);
            // 
            // labelSummaryNo
            // 
            this.labelSummaryNo.AutoSize = true;
            this.labelSummaryNo.Location = new System.Drawing.Point(829, 50);
            this.labelSummaryNo.Name = "labelSummaryNo";
            this.labelSummaryNo.Size = new System.Drawing.Size(81, 22);
            this.labelSummaryNo.TabIndex = 8;
            this.labelSummaryNo.Text = "サマリ番号";
            // 
            // textBoxSummaryNo
            // 
            this.textBoxSummaryNo.Font = new System.Drawing.Font("Meiryo UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxSummaryNo.Location = new System.Drawing.Point(820, 76);
            this.textBoxSummaryNo.Name = "textBoxSummaryNo";
            this.textBoxSummaryNo.Size = new System.Drawing.Size(339, 67);
            this.textBoxSummaryNo.TabIndex = 9;
            // 
            // labelNormalModule
            // 
            this.labelNormalModule.AutoSize = true;
            this.labelNormalModule.Location = new System.Drawing.Point(1053, 202);
            this.labelNormalModule.Name = "labelNormalModule";
            this.labelNormalModule.Size = new System.Drawing.Size(127, 22);
            this.labelNormalModule.TabIndex = 10;
            this.labelNormalModule.Text = "歯直角モジュール";
            // 
            // textBoxNormalModule
            // 
            this.textBoxNormalModule.Font = new System.Drawing.Font("Meiryo UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxNormalModule.Location = new System.Drawing.Point(1055, 227);
            this.textBoxNormalModule.Name = "textBoxNormalModule";
            this.textBoxNormalModule.Size = new System.Drawing.Size(169, 58);
            this.textBoxNormalModule.TabIndex = 11;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(1177, 44);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(60, 22);
            this.labelName.TabIndex = 12;
            this.labelName.Text = "NAME";
            // 
            // textBoxName
            // 
            this.textBoxName.Font = new System.Drawing.Font("Meiryo UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxName.Location = new System.Drawing.Point(1181, 76);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(389, 33);
            this.textBoxName.TabIndex = 13;
            // 
            // labelNote
            // 
            this.labelNote.AutoSize = true;
            this.labelNote.Location = new System.Drawing.Point(1177, 117);
            this.labelNote.Name = "labelNote";
            this.labelNote.Size = new System.Drawing.Size(58, 22);
            this.labelNote.TabIndex = 14;
            this.labelNote.Text = "NOTE";
            // 
            // textBoxNote
            // 
            this.textBoxNote.Font = new System.Drawing.Font("Meiryo UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxNote.Location = new System.Drawing.Point(1181, 148);
            this.textBoxNote.Name = "textBoxNote";
            this.textBoxNote.Size = new System.Drawing.Size(389, 33);
            this.textBoxNote.TabIndex = 15;
            // 
            // labelNumberOfTeeth
            // 
            this.labelNumberOfTeeth.AutoSize = true;
            this.labelNumberOfTeeth.Location = new System.Drawing.Point(829, 202);
            this.labelNumberOfTeeth.Name = "labelNumberOfTeeth";
            this.labelNumberOfTeeth.Size = new System.Drawing.Size(135, 22);
            this.labelNumberOfTeeth.TabIndex = 16;
            this.labelNumberOfTeeth.Text = "歯数(駆動・従動)";
            // 
            // textBoxNumberOfTeethG1
            // 
            this.textBoxNumberOfTeethG1.Font = new System.Drawing.Font("Meiryo UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxNumberOfTeethG1.Location = new System.Drawing.Point(820, 227);
            this.textBoxNumberOfTeethG1.Name = "textBoxNumberOfTeethG1";
            this.textBoxNumberOfTeethG1.Size = new System.Drawing.Size(98, 58);
            this.textBoxNumberOfTeethG1.TabIndex = 17;
            // 
            // textBoxNumberOfTeethG2
            // 
            this.textBoxNumberOfTeethG2.Font = new System.Drawing.Font("Meiryo UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxNumberOfTeethG2.Location = new System.Drawing.Point(936, 227);
            this.textBoxNumberOfTeethG2.Name = "textBoxNumberOfTeethG2";
            this.textBoxNumberOfTeethG2.Size = new System.Drawing.Size(98, 58);
            this.textBoxNumberOfTeethG2.TabIndex = 18;
            // 
            // labelNormalPressureAngle
            // 
            this.labelNormalPressureAngle.AutoSize = true;
            this.labelNormalPressureAngle.Location = new System.Drawing.Point(1228, 202);
            this.labelNormalPressureAngle.Name = "labelNormalPressureAngle";
            this.labelNormalPressureAngle.Size = new System.Drawing.Size(112, 22);
            this.labelNormalPressureAngle.TabIndex = 19;
            this.labelNormalPressureAngle.Text = "歯直角圧力角";
            // 
            // labelHelixAngle
            // 
            this.labelHelixAngle.AutoSize = true;
            this.labelHelixAngle.Location = new System.Drawing.Point(1407, 202);
            this.labelHelixAngle.Name = "labelHelixAngle";
            this.labelHelixAngle.Size = new System.Drawing.Size(69, 22);
            this.labelHelixAngle.TabIndex = 20;
            this.labelHelixAngle.Text = "ねじれ角";
            // 
            // textBoxNormalPressureAngle
            // 
            this.textBoxNormalPressureAngle.Font = new System.Drawing.Font("Meiryo UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxNormalPressureAngle.Location = new System.Drawing.Point(1232, 227);
            this.textBoxNormalPressureAngle.Name = "textBoxNormalPressureAngle";
            this.textBoxNormalPressureAngle.Size = new System.Drawing.Size(169, 58);
            this.textBoxNormalPressureAngle.TabIndex = 21;
            // 
            // textBoxHelixAngle
            // 
            this.textBoxHelixAngle.Font = new System.Drawing.Font("Meiryo UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBoxHelixAngle.Location = new System.Drawing.Point(1411, 227);
            this.textBoxHelixAngle.Name = "textBoxHelixAngle";
            this.textBoxHelixAngle.Size = new System.Drawing.Size(169, 58);
            this.textBoxHelixAngle.TabIndex = 22;
            // 
            // TestFormSummaryManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1582, 853);
            this.Controls.Add(this.textBoxHelixAngle);
            this.Controls.Add(this.textBoxNormalPressureAngle);
            this.Controls.Add(this.labelHelixAngle);
            this.Controls.Add(this.labelNormalPressureAngle);
            this.Controls.Add(this.textBoxNumberOfTeethG2);
            this.Controls.Add(this.textBoxNumberOfTeethG1);
            this.Controls.Add(this.labelNumberOfTeeth);
            this.Controls.Add(this.textBoxNote);
            this.Controls.Add(this.labelNote);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.textBoxNormalModule);
            this.Controls.Add(this.labelNormalModule);
            this.Controls.Add(this.textBoxSummaryNo);
            this.Controls.Add(this.labelSummaryNo);
            this.Controls.Add(this.buttonSaveDecodedText);
            this.Controls.Add(this.buttonSaveRawText);
            this.Controls.Add(this.buttonDecode);
            this.Controls.Add(this.buttonClearAll);
            this.Controls.Add(this.buttonReadSampleFile);
            this.Controls.Add(this.buttonReadFile);
            this.Controls.Add(this.textBoxSpecSection);
            this.Controls.Add(this.textBoxRawSummary);
            this.Font = new System.Drawing.Font("Meiryo UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TestFormSummaryManager";
            this.Text = "Summary Manager Beta Version";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxRawSummary;
        private System.Windows.Forms.TextBox textBoxSpecSection;
        private System.Windows.Forms.Button buttonReadFile;
        private System.Windows.Forms.Button buttonReadSampleFile;
        private System.Windows.Forms.Button buttonClearAll;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Button buttonDecode;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.Button buttonSaveRawText;
        private System.Windows.Forms.Button buttonSaveDecodedText;
        private System.Windows.Forms.Label labelSummaryNo;
        private System.Windows.Forms.TextBox textBoxSummaryNo;
        private System.Windows.Forms.Label labelNormalModule;
        private System.Windows.Forms.TextBox textBoxNormalModule;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label labelNote;
        private System.Windows.Forms.TextBox textBoxNote;
        private System.Windows.Forms.Label labelNumberOfTeeth;
        private System.Windows.Forms.TextBox textBoxNumberOfTeethG1;
        private System.Windows.Forms.TextBox textBoxNumberOfTeethG2;
        private System.Windows.Forms.Label labelNormalPressureAngle;
        private System.Windows.Forms.Label labelHelixAngle;
        private System.Windows.Forms.TextBox textBoxNormalPressureAngle;
        private System.Windows.Forms.TextBox textBoxHelixAngle;
    }
}