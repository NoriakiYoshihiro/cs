﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Library.StringListDataTableConverter;

namespace Gearmetry
{
    public partial class TestFormSummaryManager : Form
    {
        SummaryManager summaryManager = new SummaryManager();

        public TestFormSummaryManager()
        {
            InitializeComponent();
        }

        private void buttonClearAll_Click(object sender, EventArgs e)
        {
            textBoxRawSummary.Text = "";
            textBoxSpecSection.Text = "";

            textBoxSummaryNo.Text = "";
            textBoxName.Text = "";
            textBoxNote.Text = "";
            textBoxNumberOfTeethG1.Text = "";
            textBoxNumberOfTeethG2.Text = "";
            textBoxNormalModule.Text = "";
            textBoxNormalPressureAngle.Text = "";
            textBoxHelixAngle.Text = "";
        }

        private void buttonReadFile_Click(object sender, EventArgs e)
        {
            if (!summaryManager.SelectAndReadRawTextFile()) return;
            textBoxRawSummary.Text = summaryManager.RawText;
            Decode();
        }

        private void Decode()
        {
            summaryManager.DecodeRawText();
            textBoxSpecSection.Text = summaryManager.DecodedText;
            textBoxSummaryNo.Text = summaryManager.Sec0.SummaryNo.G1;
            textBoxName.Text = summaryManager.Sec0.Name.G1;
            textBoxNote.Text = summaryManager.Sec0.Note.G1;
            textBoxNumberOfTeethG1.Text = summaryManager.Sec1.NumberOfTeeth.G1;
            textBoxNumberOfTeethG2.Text = summaryManager.Sec1.NumberOfTeeth.G2;
            textBoxNormalModule.Text = summaryManager.Sec1.NormalModule.G1;
            textBoxNormalPressureAngle.Text = summaryManager.Sec1.NormalPressureAngle.G1;
            textBoxHelixAngle.Text = summaryManager.Sec1.HelixAngle.G1;
        }

        private void buttonDecode_Click(object sender, EventArgs e)
        {
            summaryManager.SetRawText(textBoxRawSummary.Text);
            Decode();
        }

        private void buttonSaveRawText_Click(object sender, EventArgs e)
        {
            summaryManager.SelectAndSaveRawTextFile();
        }

        private void buttonSaveDecodedText_Click(object sender, EventArgs e)
        {
            summaryManager.SelectAndSaveDecodedTextFile();
        }


        private void buttonReadSampleFile_Click(object sender, EventArgs e)
        {
            if (!summaryManager.ReadRawTextFile("_PdfTextSample.txt")) return;
            textBoxRawSummary.Text = summaryManager.RawText;
            Decode();
        }
    }
}
