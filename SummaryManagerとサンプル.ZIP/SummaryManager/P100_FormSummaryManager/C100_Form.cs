﻿using FormUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Gearmetry
{
    public partial class FormSummaryManager  : FormQuickBox
    {

        public QuickBox Q { get; set; }
        public Selector S { get; set; }
        public Changer C { get; set; }

        public SummaryManager Summary { get; set; }

        public NameValueArray NV { get; set; }


        public FormSummaryManager(SummaryManager summaryManager)
        {
            Text = "Raw Summary Manager";
            Q = this.QuickBox;
            S = Q.Selector;
            C = Q.Changer;

            Summary = summaryManager;// new SummaryManager();

            SetComboKeyArray();
            SetNameValueArray();
        }
    }
}
