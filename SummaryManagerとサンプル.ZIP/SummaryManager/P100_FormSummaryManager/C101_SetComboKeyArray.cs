﻿using FormUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Library.StringListDataTableConverter;

namespace Gearmetry
{
    public partial class FormSummaryManager
    {
        protected void SetComboKeyArray()
        {
            ComboKeyCell cell;
            void SetCellNo(int n) => cell = S.Cell[n];


            Q.SetAreaDefault1(8, 8, 1,ChangerLayout.Horizontal2);
            Q.Changer.Visible= false;



            SetCellNo(0);
            cell.Text = "全クリア";
            cell.ClickEvent = (s, e) =>
            {
                for (var i = 0; i < NV.Length; i++) NV.NameValue[i].ExTextBox.Text = "";
            };


            SetCellNo(1);
            cell.Text = "生ファイル\r\n読込";
            cell.ClickEvent = (s, e) =>
            {
                if (!Summary.SelectAndReadRawTextFile()) return;
                Summary.DecodeRawText();
                ShowSummaryContents();
            };


            SetCellNo(2);
            cell.Text = "生ファイル\r\n保存";
            cell.ClickEvent = (s, e) => Summary.SelectAndSaveRawTextFile();

            SetCellNo(3);
            cell.Visible = false;

            SetCellNo(4);
            cell.Text = "解読実行";
            cell.ClickEvent = (s, e) =>
            {
                Summary.SetRawText(NV.NameValue[0].ExTextBox.Text);
                Summary.DecodeRawText();
                ShowSummaryContents();
            };

            SetCellNo(5);
            cell.Text = "解読サマリ\r\n保存";
            cell.ClickEvent = (s, e) => Summary.SelectAndSaveDecodedTextFile();

            SetCellNo(6);
            cell.Visible = false;

            SetCellNo(7);
            cell.Text = "閉じる";
            cell.ClickEvent = (s,e)=>this.Close();
        }
    }
}
