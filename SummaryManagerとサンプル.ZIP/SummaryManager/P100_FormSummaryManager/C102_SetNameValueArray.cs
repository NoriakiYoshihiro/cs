﻿using FormUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gearmetry
{
    public partial class FormSummaryManager
    {
        protected void SetNameValueArray()
        {
            NV = new NameValueArray(this);
            NV.Create(10);
            NV.CreateSameNumOfTextBox(1);
            
            NameValue nv;
            void SetIndex(int index) => nv = NV.NameValue[index];


            // ==== 生サマリ ====

            SetIndex(0);
            nv.Key = "RawSummary";
            nv.ParentLocation = (20, 20);
            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (160, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "生サマリ";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (600, 520);
            nv.ExTextBox.SetAlignLeft();
            nv.ExTextBox.Multiline = true;
            nv.ExTextBox.SetScrollBarsBoth();

            // ==== サマリ番号 ====
            SetIndex(1);
            nv.Key = "SummaryNo";
            nv.ParentLocation = (640, 20);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (160, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "サマリ番号";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (360, 80);
            nv.ExTextBox.FontSize = 42;
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignLeft();

            // ==== Name ====
            SetIndex(2);
            nv.Key = "Name";
            nv.ParentLocation = (NV.NameValue[1].Area.Right + 10, NV.NameValue[1].Area.Top);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (160, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "NAME";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (240, 30);
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignLeft();

            // ==== Note ====
            SetIndex(3);
            nv.Key = "Note";
            nv.ParentLocation = (NV.NameValue[2].Area.Left, NV.NameValue[2].Area.Bottom + 2);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (160, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "NOTE";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (240, 30);
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignLeft();

            // ==== 歯数(駆動) ====
            SetIndex(4);
            nv.Key = "NumberOfTeeth(Drive)";
            nv.ParentLocation = (NV.NameValue[1].Area.Left, NV.NameValue[1].Area.Bottom + 10);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (120, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "歯数 (駆動　従動)";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (60, 30);
            nv.ExTextBox.FontSize = 20;
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignCenter();

            // ==== 歯数(従動) ====
            SetIndex(5);
            nv.Key = "NumberOfTeeth(Driven)";
            nv.ParentLocation = (NV.NameValue[4].Area.Right - 50, NV.NameValue[4].Area.Top);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (60, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (60, 30);
            nv.ExTextBox.FontSize = 20;
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignCenter();

            // ==== 歯直角モジュール ====
            SetIndex(6);
            nv.Key = "NormalModule";
            nv.ParentLocation = (NV.NameValue[5].Area.Right + 20, NV.NameValue[5].Area.Top);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (140, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "歯直角モジュール";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (140, 30);
            nv.ExTextBox.FontSize = 20;
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignCenter();

            // ==== 歯直角圧力角 ====
            SetIndex(7);
            nv.Key = "NormalPressureAngle";
            nv.ParentLocation = (NV.NameValue[6].Area.Right + 20, NV.NameValue[6].Area.Top);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (140, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "歯直角圧力角";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (140, 30);
            nv.ExTextBox.FontSize = 20;
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignCenter();

            // ==== ねじれ角 ====
            SetIndex(8);
            nv.Key = "HelixAngle";
            nv.ParentLocation = (NV.NameValue[7].Area.Right + 20, NV.NameValue[7].Area.Top);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (140, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "ねじれ角";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (140, 30);
            nv.ExTextBox.FontSize = 20;
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignCenter();

            // ==== 解読サマリ ====
            SetIndex(9);
            nv.Key = "DecodedSummary";
            nv.ParentLocation = (NV.NameValue[4].Area.Left, NV.NameValue[4].Area.Bottom + 10);

            nv.ExLabel.LocalLocation = (0, 0);
            nv.ExLabel.Size = (140, 30);
            nv.ExLabel.SetAlignMiddleLeft();
            nv.ExLabel.Text = "解読サマリ";

            nv.ExTextBox.LocalLocation = (0, 30);
            nv.ExTextBox.Size = (NV.NameValue[8].Area.Right - NV.NameValue[4].Area.Left, NV.NameValue[0].Area.Bottom - nv.ExTextBox.Area.Top);
            nv.ExTextBox.ReadOnly = true;
            nv.ExTextBox.SetAlignLeft();
            nv.ExTextBox.Multiline = true;
            nv.ExTextBox.SetScrollBarsBoth();
        }

        protected void ShowSummaryContents()
        {
            NV.NameValue[0].ExTextBox.Text = Summary.RawText;
            NV.NameValue[1].ExTextBox.Text = Summary.Sec0.SummaryNo.G1;
            NV.NameValue[2].ExTextBox.Text = Summary.Sec0.Name.G1;
            NV.NameValue[3].ExTextBox.Text = Summary.Sec0.Note.G1;
            NV.NameValue[4].ExTextBox.Text = Summary.Sec1.NumberOfTeeth.G1;
            NV.NameValue[5].ExTextBox.Text = Summary.Sec1.NumberOfTeeth.G2;
            NV.NameValue[6].ExTextBox.Text = Summary.Sec1.NormalModule.G1;
            NV.NameValue[7].ExTextBox.Text = Summary.Sec1.NormalPressureAngle.G1;
            NV.NameValue[8].ExTextBox.Text = Summary.Sec1.HelixAngle.G1;
            NV.NameValue[9].ExTextBox.Text = Summary.DecodedText;
        }
    }
}
