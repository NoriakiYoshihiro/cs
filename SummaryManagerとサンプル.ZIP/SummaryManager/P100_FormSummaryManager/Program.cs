﻿using ApplicationManager;
using System;
using System.Collections.Generic;
using System.Linq;
using static System.Threading.Thread;
using System.Windows.Forms;
using FormUI;
using System.Threading.Tasks;

namespace Gearmetry
{
    internal static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);

            /*
            // ======== アプリケーションタイトルスクリーン ========
            ApplicationInfo.ProjectTitle = "GEARMETRY";
            ApplicationInfo.ProjectComment = "Dedicated to all gear engineers";
            ApplicationInfo.ApplicationTitle = "Summary Manager";
            ApplicationInfo.ApplicationSubtitle = "To decode raw summary text";
            ApplicationInfo.ApplicationVersion = "Ver.01.00.00";
            ApplicationInfo.ApplicationCopyright = "(C) Toyota Motor Corporation";
            ApplicationInfo.ApplicationHistory = "Ver.01.00.00 Nov.30 2023 : First Released.\r\n";
            */

            using (var fSW = new FormSplashWindow())
            {
                fSW.SetHowToShow(HowToShow.Dynamic);
                fSW.ShowSplash();
                Sleep(1200);
            }
            // ======== ======== ======== ======== ======== ========

            var summaryManager= new SummaryManager();
            var formSummaryManager = new FormSummaryManager(summaryManager);

            formSummaryManager.ShowDialog();

            //var circleReference = new CircleReference();
            var s = formSummaryManager.Summary;
            var z = Convert.ToInt32(s.Sec1.NumberOfTeeth.G1);
            var m = Convert.ToDouble(s.Sec1.NormalModule.G1);
            var alpN_Deg= Convert.ToDouble(s.Sec1.NormalPressureAngle.G1);
            var bet_Deg= Convert.ToDouble(s.Sec1.HelixAngle.G1);
            //circleReference.SetReference(z, m, alpN_Deg, bet_Deg);
        }
    }
}
